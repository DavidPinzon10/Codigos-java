
package ejercicio2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class ListaCantantesFamosos {
private ArrayList<CantanteFamoso> listaCantantesFamosos;

    public ListaCantantesFamosos() {
        listaCantantesFamosos = new ArrayList<CantanteFamoso>();
    }

    public void addCantanteFamoso(CantanteFamoso cantanteFamoso) {
        listaCantantesFamosos.add(cantanteFamoso);
    }

    public void removeCantanteFamoso(CantanteFamoso cantanteFamoso) {
        listaCantantesFamosos.remove(cantanteFamoso);
    }

    public void modifyCantanteFamoso(String nombre, String discoConMasVentas) {
        for (CantanteFamoso cantanteFamoso : listaCantantesFamosos) {
            if (cantanteFamoso.getNombre().equals(nombre)) {
                cantanteFamoso.setDiscoConMasVentas(discoConMasVentas);
                return;
            }
        }
        System.out.println("Cantante famoso no encontrado.");
    }

    public void sortCantantesFamosos() {
        Collections.sort(listaCantantesFamosos, new Comparator<CantanteFamoso>() {
            public int compare(CantanteFamoso cf1, CantanteFamoso cf2) {
                return cf2.getDiscoConMasVentas().compareTo(cf1.getDiscoConMasVentas());
            }
        });
    }

    public void printListaCantantesFamosos() {
        Iterator<CantanteFamoso> iterator = listaCantantesFamosos.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }

    Iterator<CantanteFamoso> iterator() {
        return iterator();
    }
}   