
/**
 * @author David Pinzón
 */
import java.util.Scanner;

public class MenuGaseosa {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        int PrecioBebida;
        int CantidadAzucar = 0;
        float TotalPagar;
        float Subtotal;
        byte opcion, cantidad;

        int Cantidad_Cocacola = 0;
        int Cantidad_Pepsi = 0;
        int Cantidad_Colombiana = 0;
        int Cantidad_Manzana = 0;

        int Precio_Cocacola = 2000;
        int Precio_Pepsi = 1500;
        int Precio_Colombiana = 1000;
        int Precio_Manzana = 1800;

        int Subtotal_Cocacola = 0;
        int Subtotal_Pepsi = 0;
        int Subtotal_Colombiana = 0;
        int Subtotal_Manzana = 0;

        System.out.println("A=====================================A");
        System.out.println("Digite el número de la bebida que desea");
        System.out.println("A=====================================A");

        while (true) {
            System.out.println("-----------------------------------");
            System.out.println("1. Coca cola");
            System.out.println("2. Pepsi");
            System.out.println("3. Colombiana");
            System.out.println("4. Manzana");
            System.out.println("5. Terminar pedido");
            System.out.println("-----------------------------------");
            opcion = leer.nextByte();

            switch (opcion) {
                case 1:
                    System.out.println("Con cuantos gramos de azúcar la desea");
                    cantidad = leer.nextByte();
                    Cantidad_Cocacola = Cantidad_Cocacola + cantidad;
                    break;
                case 2:
                    System.out.println("Con cuantos gramos de azúcar la desea");
                    cantidad = leer.nextByte();
                    Cantidad_Pepsi = Cantidad_Pepsi + cantidad;
                    break;
                case 3:
                    System.out.println("Con cuantos gramos de azúcar la desea");
                    cantidad = leer.nextByte();
                    Cantidad_Colombiana = Cantidad_Colombiana + cantidad;
                    break;
                case 4:
                    System.out.println("Con cuantos gramos de azúcar la desea");
                    cantidad = leer.nextByte();
                    Cantidad_Manzana = Cantidad_Manzana + cantidad;
                    break;
                case 5:
                    System.out.println("Gaseosas Don Antonio");
                   
                    if (Cantidad_Cocacola > 0) {
                        Subtotal_Cocacola = Cantidad_Cocacola * Precio_Cocacola;
                        System.out.println("Cocacola.......... " + Cantidad_Cocacola + "$" + Subtotal_Cocacola);
                    }
                    if (Cantidad_Pepsi > 0) {
                        Subtotal_Pepsi = Cantidad_Pepsi * Precio_Pepsi;
                        System.out.println("Pepsi............. " + Cantidad_Pepsi + "$" + Subtotal_Pepsi);
                    }
                    if (Cantidad_Colombiana > 0) {
                        Subtotal_Colombiana = Cantidad_Colombiana * Precio_Colombiana;
                        System.out.println("Colombiana........ " + Cantidad_Colombiana + "$" + Subtotal_Colombiana);
                    }
                    if (Cantidad_Manzana > 0) {
                        Subtotal_Manzana = Cantidad_Manzana * Precio_Manzana;
                        System.out.println("Manzana........... " + Cantidad_Manzana + "$" + Subtotal_Manzana);
                    }
                    Subtotal = Subtotal_Cocacola + Subtotal_Pepsi + Subtotal_Colombiana + Subtotal_Manzana;
                    System.out.println("----------------------------------------------------------");
                    System.out.println("Subtotal = " + Subtotal);
                    TotalPagar = Subtotal;
                    System.out.println("Total a pagar es = " + TotalPagar);
                    System.out.println("----------------------------------------------------------");
                    break;
            }

        }

    }

}
