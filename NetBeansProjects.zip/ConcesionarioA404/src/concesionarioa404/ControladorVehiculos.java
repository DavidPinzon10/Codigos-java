
package concesionarioa404;
import java.util.ArrayList;

public class ControladorVehiculos implements IControladorVehiculos{
    public ArrayList array = new ArrayList();
    
    public ControladorVehiculos(){    
        
    }
    
    @Override
    public void registrarVehiculo(String cod, String mar, String nom, String tip, String pre){
        //Instancio al manejador
        AdministradorVehiculo av = AdministradorVehiculo.getinstance();
        //Creo el elemento
        Vehiculo v = new Vehiculo(cod, mar, nom, tip, pre);
        //Lo agrego a la colección global
        av.addVehiculo(v);
    }
    
    @Override
    public DataVehiculo verInfoVehiculo(String cod){
        AdministradorVehiculo av = AdministradorVehiculo.getinstance();
        Vehiculo v = av.obtenerVehiculo(cod);
        if (v!= null)
            return new DataVehiculo(v.getCodigo(),v.getMarca(),v.getNombre(),v.getTipo(), v.getPrecio());
        else
            return new DataVehiculo("---------","---------","---------","---------","---------");
    }
    
    @Override
    public void eliminarVehiculo(String cod){
        //Instancio al manejador
        AdministradorVehiculo av = AdministradorVehiculo.getinstance();
        //Lo elimino
        av.eliminarVehiculo(cod);
    }
    
    @Override
    public ArrayList Inventario(){
        AdministradorVehiculo av = AdministradorVehiculo.getinstance();
        
        array.add(av.inventario());        
        
        return array;
            
    }
}
