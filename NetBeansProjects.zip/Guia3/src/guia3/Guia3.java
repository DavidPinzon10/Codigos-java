package guia3;

import java.lang.*;
import javax.swing.JOptionPane;
import java.util.Random;
    
public class Guia3 {

    
    int ArregloNum[], tam = 1000000; //para la cantidad de numeros que se desea
    String aux;

    public Guia3() {
        ArregloNum = new int[tam];
        LeerArreglo();
        //OrdenamientoBurbuja();
        //ordenamientoInsercion();
        quicksort(ArregloNum, 0, tam - 1);
        //Seleccion(ArregloNum);
        //Shell(ArregloNum);
        ImprimirArreglo();
    }

    public void LeerArreglo() {
        Random aleatorio = new Random();
        for (int i = 0; i < tam; i++) {
        ArregloNum[i] = (int)(Math.random()*1000+1);
        }
    }

    public void ImprimirArreglo() {
        aux = "";
        for (int i = 0; i < tam; i++) {
            aux = aux + ArregloNum[i] + ", ";
        }
        JOptionPane.showMessageDialog(null, "arreglo Leido= " + aux);
    }

    public void OrdenamientoBurbuja() {
        int NAux;
        for (int i = 0; i < tam - 1; i++) {
            for (int j = 0; j < (tam - i - 1); j++) {
                if (ArregloNum[j] > ArregloNum[j + 1]) {
                    NAux = ArregloNum[j];
                    ArregloNum[j] = ArregloNum[j + 1];
                    ArregloNum[j + 1] = NAux;
                }
            }
        }

    }

    public void ordenamientoInsercion() {
        int i, j;
        int aux;
        for (i = 1; i < ArregloNum.length; i++) {
            /* indice j es para explorar la sublista a[i-1]..a[0] 
            buscando la posicion correcta del elemento destino*/
            j = i;
            aux = ArregloNum[i];// se localiza el punto de inserción explorando hacia abajo
            while (j > 0 && aux < ArregloNum[j - 1]) {// desplazar elementos hacia arriba para hacer espacio
                ArregloNum[j] = ArregloNum[j - 1];
                j--;
            }
            ArregloNum[j] = aux;
        }
    }

    private static void quicksort(int a[], int primero, int ultimo) {
        int i, j, central;
        int pivote;
        central = (primero + ultimo) / 2;
        pivote = a[central];
        i = primero;
        j = ultimo;
        do {
            while (a[i] < pivote) {
                i++;
            }
            while (a[j] > pivote) {
                j--;
            }
            if (i <= j) {
                intercambiar(a, i, j);
                i++;
                j--;
            }
        } while (i <= j);
        if (primero < j) {
            quicksort(a, primero, j); // mismo proceso con sublista izqda
        }
        if (i < ultimo) {
            quicksort(a, i, ultimo); // mismo proceso con sublista drcha
        }
    }

    public static void intercambiar(int[] a, int i, int j) {
        int aux = a[i];
        a[i] = a[j];
        a[j] = aux;
    }
    
    public static void Seleccion(int a[]){
        int indiceMenor, i, j, n;
        n = a.length;	
        for (i = 0; i < n-1; i++)
        {
             // comienzo de la exploración en índice i
             indiceMenor = i;
             // j explora la sublista a[i+1]..a[n-1]
             for (j = i+1; j < n; j++)
                  if (a[j] < a[indiceMenor])
                       indiceMenor = j;
                       // sitúa el elemento mas pequeño en a[i]
	 	               if (i != indiceMenor)
                       intercambiar(a, i, indiceMenor);
    }
    }

    public static void Shell(int a[]){
       int intervalo, i, j, k;
	 int n= a.length;
	 intervalo = n / 2;
	 while (intervalo > 0)
	 {
	 	 for (i = intervalo; i < n; i++)
	 	 {
	 	 	 j = i - intervalo;
	 	 	 while (j >= 0)
	 	 	 {
	 	 	 	 k = j + intervalo;
	 	 	 	 if (a[j] <= a[k])
	 	 	 	 	 j = -1; // par de elementos ordenado
	 	 	 	 else
	 	 	 	 {
	 	 	 	 	 intercambiar(a, j, j+1);
	 	 	 	 	 j -= intervalo;
	 	 	 	 }
	 	 	 }
	 	 }
	 	 intervalo = intervalo / 2;
                
	 }  
    }
    
    public static void main(String[] args) {
        Guia3 solucion = new Guia3();
        
        System.out.print("Current Time in milliseconds = ");
        System.out.println(System.currentTimeMillis());
    }
}
