/**
 * @author David Pinzón
 */
import java.util.Scanner;
public class Enteros_a_letras {
    public static void main(String[] args) {
       
        Scanner string = new Scanner(System.in);
        
        System.out.println("teclea un numero: ");
        
        int num = string.nextInt();
        
        switch (num) {
            case 1:
                System.out.println("uno");
                break;
            case 2:
                System.out.println("dos");
                break;
            case 3:
                System.out.println("tres");
                break;
            case 4:
                System.out.println("cuatro");
                break;
            case 5:
                System.out.println("cinco");
                break;
            case 6:
                System.out.println("seis");
                break;
            case 7:
                System.out.println("siete");
                break;
            case 8:
                System.out.println("ocho");
                break;
            case 9:
                System.out.println("nueve");
                break;
            case 10:
                System.out.println("diez");
                break;
            default:
                System.out.println("Más de 10 no se puede");
        }
    }
}
        
    
    

