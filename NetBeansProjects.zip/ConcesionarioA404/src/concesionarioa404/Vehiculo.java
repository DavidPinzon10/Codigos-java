
package concesionarioa404;

public class Vehiculo {
    
    private String codigo;
    private String marca;
    private String nombre;
    private String tipo;
    private String precio;
    
    public Vehiculo(String cod, String mar, String nom, String tip, String pre){
        this.codigo = cod;
        this.marca = mar;
        this.nombre = nom;
        this.tipo = tip;
        this.precio = pre;
    }

    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPrecio() {
        return precio;
    }
    public void setPrecio(String precio) {
        this.precio = precio;
    }
 
    @Override
    public String toString(){
        return "Vehiculo: \n[ Codigo: "+codigo+" Marca: "+marca+" Nombre:"+nombre+" Tipo: "+tipo+"]";
    }
}
