
package cinemax;

import javax.swing.JOptionPane;

public class Cinemax {
    public static void main(String[] args) {
        // Matriz para almacenar el total de personas que han asistido a ver cada película en cada sala
        int[][] asistencia = new int[7][15];
        
        // Ciclo para solicitar el total de personas que han asistido a ver cada película en cada sala
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 15; j++) {
                String mensaje = "Ingrese el total de personas que han asistido a ver la pelicula " + (j+1) + " en la sala " + (i+1) + ":";
                int totalPersonas = Integer.parseInt(JOptionPane.showInputDialog(mensaje));
                asistencia[i][j] = totalPersonas;
            }
        }
        
        // Cálculo de las estadísticas
        int peliculaMasVista = 0;
        int peliculaMenosVista = 0;
        int totalAsistentes = 0;
        
        for (int j = 0; j < 15; j++) {
            int totalPelicula = 0;
            for (int i = 0; i < 7; i++) {
                totalPelicula += asistencia[i][j];
                totalAsistentes += asistencia[i][j];
            }
            if (totalPelicula > asistencia[peliculaMasVista][j]) {
                peliculaMasVista = j;
            }
            if (totalPelicula < asistencia[peliculaMenosVista][j]) {
                peliculaMenosVista = j;
            }
        }
        
        String mensaje = "La pelicula mas vista es la " + (peliculaMasVista+1) + " con un total de " + asistencia[0][peliculaMasVista] + " personas asistentes.\n"
                + "La pelicula menos vista es la " + (peliculaMenosVista+1) + " con un total de " + asistencia[0][peliculaMenosVista] + " personas asistentes.\n"
                + "El total de asistentes es " + totalAsistentes + ".";
        JOptionPane.showMessageDialog(null, mensaje);
    }
}