package Ejpolimorfo;
public class Universidad {

    private String NIT;
    private String Nombre;
    private String Direccion;

    public Universidad(String NIT, String Nombre, String Direccion) {
        this.NIT = NIT;
        this.Nombre = Nombre;
        this.Direccion = Direccion;
    }

    public String getNIT() {
        return NIT;
    }

    public void setNIT(String NIT) {
        this.NIT = NIT;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }
}
