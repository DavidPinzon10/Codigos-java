package factorial;
import java.util.Scanner;
/**
 * @author David Pinzón
 */
public class FactorialFactorial {
    public static void main(String[] args) {
       Scanner leer = new Scanner(System.in);
        
       int Factorial = 1;//Porque al multiplicar hasta cero no se cumple el factorial
       int Numero = 0;
       
       System.out.println("Ingrese el número el cual desea hallar su factorial");
       Numero = leer.nextInt();
       System.out.println("---------------------------------------------------");
       int Numero_Digitado = Numero;
       
        while (Numero != 0) { //Diferente a 0 para qque no lo multiplique
              Factorial = Factorial * Numero;
              Numero --;  //Tiene que descender, "Decrementar" 7,6,5,4.. etc 
                
        }
        System.out.println("El factorial del numero "+Numero_Digitado+ " es = "+Factorial);
    }
    
}
