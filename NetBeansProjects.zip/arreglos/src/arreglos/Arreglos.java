package arreglos;

import javax.swing.JOptionPane;

public class Arreglos {

    public static void main(String[] args) {

        int[] numeros = new int[5];    //arreglo unidimensional que registra numeros enteros y los almacena
        for (int i = 0; i < numeros.length; i++) {
            String entrada = JOptionPane.showInputDialog("Ingrese el número " + (i + 1) + ":");
            numeros[i] = Integer.parseInt(entrada);
        }
        JOptionPane.showMessageDialog(null, "Los números son: "
                + numeros[0] + ", " + numeros[1] + ", " + numeros[2] + ", " + numeros[3] + ", " + numeros[4]);


        //arreglo bidimensional para registrar nombres
        String[][] nombres = new String[2][3];
        for (int i = 0; i < nombres.length; i++) {
            for (int j = 0; j < nombres[i].length; j++) {
                nombres[i][j] = JOptionPane.showInputDialog("Ingrese el nombre en la posición [" + i + "][" + j + "]:");
            }
        }
        JOptionPane.showMessageDialog(null, "Los nombres son:\n"
                + nombres[0][0] + " | " + nombres[0][1] + " | " + nombres[0][2] + "\n"
                + nombres[1][0] + " | " + nombres[1][1] + " | " + nombres[1][2]);
    }

}
