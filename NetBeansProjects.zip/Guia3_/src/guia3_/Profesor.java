
package guia3_;

import javax.swing.JOptionPane;


public class Profesor extends Persona {
    protected String escalafon;
    private Profesor[] lista;
    
    public Profesor(int numID,  String nombres, String apellidos, int edad,  String direccion,String escalafon, String nombreU, String direccionU) {
        super(numID, nombres, apellidos, edad, direccion, nombreU, direccionU);
        this.escalafon = escalafon;
    }

    
    public Profesor(){
        this.escalafon = "";
    }

    public String getEscalafon() {
        return escalafon;
    }

    public void setEscalafon(String escalafon) {
        this.escalafon = escalafon;
    }

    public void InsertarDatos() {
      lista = new Profesor[2];
      
      for (int i = 0; i < 2; i++) {
        
       numID = Integer.parseInt(JOptionPane.showInputDialog("Digite el numero de documento del Profesor: "));
       getNumID();
       nombres = JOptionPane.showInputDialog("Digite los nombres del Profesor: ");
       getNombres();
       apellidos = JOptionPane.showInputDialog("Digite los apellidos del Profesor: ");
       getApellidos();
       edad = Integer.parseInt(JOptionPane.showInputDialog("Digite la edad del Profesor: "));
       getEdad();
       direccion = JOptionPane.showInputDialog("Digite la dirección del Profesor: ");
       getDireccionU();
       escalafon = JOptionPane.showInputDialog("Digite el escalafón del Profesor: ");
       getEscalafon();
       nombreU = JOptionPane.showInputDialog("Digite la universidad en la que esta: ");
       getNombreU();
       direccionU = JOptionPane.showInputDialog("Digite la direccion de la universidad del Docente: ");
       getDireccionU();
               
                       
      
       lista[i] = new Profesor(numID, nombres, apellidos, edad, direccion, escalafon, nombreU, direccionU); 
      
      }
      }
    @Override
    public void mostrarDatos(){
        String registrados;
        registrados = "-Nro.Documento    - Nombres    - Apellidos    - Edad    - Direccion Docente -    Escalafón -   Universidad -   Dirección Universidad\n";
        for (int i = 0; i < 2; i++) {
        registrados = registrados + lista[i].getNumID()+"  -  "+lista[i].getNombres()+"  -  "+lista[i].getApellidos()+"  -  "+lista[i].getEdad()+"  -  "+lista[i].getDireccion()+"  -  "+
                     lista[i].getEscalafon()+ "  -  " +lista[i].getNombreU()+"  -  "+lista[i].getDireccionU()+"\n";     
       }
    JOptionPane.showMessageDialog(null, registrados,
            "Docentes Registrados", JOptionPane.INFORMATION_MESSAGE);  
       }
       
}