package EjPolimorfo;
import java.util.Scanner;

public class Administrativo extends Persona {
Estudiante est = new Estudiante();
    protected int salarioA;
    protected int edad;
  
    public void generarListadoEstudiantes() {
        est.MostrarDatos();
    }

    @Override
    public void consultarInfoPersonal() {
    }
public Administrativo (){
    this.salarioA = 0;
    this.edad = 0;
}
    public Administrativo(int NroID, int tipoID, String nombres, String apellidos, String direccion, int salarioA, int edad) {
        this.salarioA = salarioA;
        this.edad = edad;
    }
    public int getSalario() {
        return salarioA;
    }
    public void setSalario(int salario) {
        this.salarioA = salario;
    }
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    
    public void InsertarDatosAdm (){
        Scanner leer = new Scanner(System.in);
        System.out.println("Cuantos docentes desea ingresar");
        int Nadm = 0;
        Nadm = leer.nextInt();
        for (int i = 0; i < Nadm; i++) {
         System.out.println("Digite su nombre");
        this.setNombres(nombres);
        System.out.println("Digite su apellido");
        this.setApellidos(apellidos);
        System.out.println("Digite su edad");
        this.setEdad(edad);
        System.out.println("Digite su direccion");
        this.setDireccion(direccion);
        System.out.println("Digite su salario");
        this.setSalario(salarioA);
        System.out.println("---------------------------");
    }
    }
    @Override
    public void MostrarDatosAdm (){
        System.out.println("Nombre:      "+this.nombres);
        System.out.println("Apellido:    "+this.apellidos);
        System.out.println("Edad:        "+this.edad);
        System.out.println("Dirección:   "+this.direccion);
        System.out.println("Salario:     "+this.salarioA);
    }
}
