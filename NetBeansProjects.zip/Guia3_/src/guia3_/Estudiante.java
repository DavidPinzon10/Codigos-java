
package guia3_;

import java.util.Hashtable;
import javax.swing.JOptionPane;

/**
 *
 * @author userr
 */
public class Estudiante extends Persona {

    protected int grado;
    protected float notafinal;
    private Estudiante[] lista;
    
    public Estudiante(int numID,  String nombres, String apellidos, int edad,  String direccion, int grado, float notafinal, String nombreU, String direccionU) {
        super(numID, nombres, apellidos, edad, direccion, nombreU, direccionU);
        this.grado = grado;
        this.notafinal = notafinal;
    }

    
    public Estudiante(){
        this.grado = 0;
        this.notafinal = 0;
    }
    
    
    public int getGrado() {
        return grado;
    }

    public float getNotafinal() {
        return notafinal;
    }

    public void setGrado(int grado) {
        this.grado = grado;
    }

    public void setNotafinal(float notafinal) {
        this.notafinal = notafinal;
    }
    public void InsertarDatos() {
      lista = new Estudiante[5];
      
      for (int i = 0; i < 5; i++) {
        
       numID = Integer.parseInt(JOptionPane.showInputDialog("Digite el numero de documento del estudiante: "));
       getNumID();
       nombres = JOptionPane.showInputDialog("Digite los nombres del estudiante: ");
       getNombres();
       apellidos = JOptionPane.showInputDialog("Digite los apellidos del estudiante: ");
       getApellidos();
       edad = Integer.parseInt(JOptionPane.showInputDialog("Digite la edad del estudiante: "));
       getEdad();
       direccion = JOptionPane.showInputDialog("Digite la dirección del estudiante: ");
       getDireccionU();
       grado = Integer.parseInt(JOptionPane.showInputDialog("Digite el semestre del estudiante: "));
       getGrado();
       notafinal = Float.parseFloat(JOptionPane.showInputDialog("Escriba su nota final"));
       getNotafinal();  
       nombreU = JOptionPane.showInputDialog("Digite la universidad en la que esta: ");
       getNombreU();
       direccionU = JOptionPane.showInputDialog("Digite la direccion de la universidad del estudiante: ");
       getDireccionU();
               
                       
      
       lista[i] = new Estudiante(numID, nombres, apellidos, edad, direccion, grado, notafinal, nombreU, direccionU); 
      
      }
      }
    @Override
    public void mostrarDatos(){
        String registrados;
        registrados = "-Nro.Documento    - Nombres    - Apellidos    - Edad    - Direccion Estudiante -    Semestre -    Nota Final -    Universidad -   Dirección Universidad\n";
        for (int i = 0; i < 5; i++) {
        registrados = registrados + lista[i].getNumID()+"  -  "+lista[i].getNombres()+"  -  "+lista[i].getApellidos()+"  -  "+lista[i].getEdad()+"  -  "+lista[i].getDireccion()+"  -  "+lista[i].getGrado()+"  -  " +
                      lista[i].getNotafinal()+"  -  " +lista[i].getNombreU()+"  -  "+lista[i].getDireccionU()+"\n";     
       }
    JOptionPane.showMessageDialog(null, registrados,
            "Estudiantes Registrados", JOptionPane.INFORMATION_MESSAGE);  
       }
       
}

