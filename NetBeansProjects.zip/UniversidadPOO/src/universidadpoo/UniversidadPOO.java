
package universidadpoo;

public class UniversidadPOO {

    public static void main(String[] args) {
        
     EstudiantesPOO estud = new EstudiantesPOO () ;

     System.out.println("----------------------------------------------------------------------------------");
     estud.getNombre(); estud.getApellido(); estud.getNdocumento(); estud.getEdad();
   
    }
    
}
