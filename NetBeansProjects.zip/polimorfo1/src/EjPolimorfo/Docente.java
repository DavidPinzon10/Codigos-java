package EjPolimorfo;

import java.util.Scanner;

public class Docente extends Persona {

    protected int codigoDoc;
    protected int edad;
    protected float salario;
    @Override
    public void consultarInfoPersonal() {
    }

     public Docente() {
        this.codigoDoc = 0;
        this.salario = 0;
        this.edad = 0;}
     
    public Docente(int NroID, int tipoID, String nombres, String apellidos, String direccion, int codigoDoc, float salario, int edad) {
        super(NroID, tipoID, nombres, apellidos, direccion);
        this.codigoDoc = codigoDoc;
        this.salario = salario;
        this.edad = edad;
    }

    public int getcodigoDoc() {
        return codigoDoc;
    }

    public void setcodigoDoc(int codigoDoc) {
        this.codigoDoc = codigoDoc;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    @Override
    public void InsertarDatosDoc(){
        Scanner leer = new Scanner(System.in);
        System.out.println("Cuantos docentes desea ingresar");
        int Ndoc = 0;
        Ndoc = leer.nextInt();
        for (int i = 0; i < Ndoc; i++) {
         System.out.println("Digite su nombre");
        this.setNombres(nombres);
        System.out.println("Digite su apellido");
        this.setApellidos(apellidos);
        System.out.println("Digite su edad");
        this.setEdad(edad);
        System.out.println("Digite su codigo");
        this.setcodigoDoc(codigoDoc);
        System.out.println("Digite su direccion");
        this.setDireccion(direccion);
        System.out.println("Digite su salario");
        this.setSalario(salario);
        System.out.println("---------------------------");
        }
        
    }
    @Override
    public void MostrarDatosDoc(){
        System.out.println("Nombre:      "+nombres);
        System.out.println("Apellido:    "+apellidos);
        System.out.println("Edad:        "+edad);
        System.out.println("Codigo :     "+codigoDoc);
        System.out.println("Dirección:   "+direccion);
        System.out.println("Salario:  "+salario);
    }
}
