package consencionarióproyecto;
import java.util.Scanner;

public class Consultar {
    // Variables que se utilizan en los switch
    byte opConsulta;
    byte opAutomoviles;
    byte opCamionetas;
    
    public void Consulta(int a){
        Scanner Csc = new Scanner(System.in);
        Camioneta_4x4 camion = new Camioneta_4x4();
        Automovil auto = new Automovil();
        // Menú de consulta
        System.out.println("---------------------");
        System.out.println("I     CONSULTAR     I");
        System.out.println("---------------------");
        System.out.println(" 1. Automóviles      ");
        System.out.println(" 2. Camionetas 4x4   ");
        System.out.println(" 3. Salir            ");
        System.out.println("---------------------");
        System.out.println("");
        
        opConsulta = Csc.nextByte();
        
        switch(opConsulta){
            case 1:
                // Menú de automoviles
                System.out.println("-------------------");
                System.out.println("I   Automóviles   I");
                System.out.println("-------------------");
                System.out.println(" 1. Ford           ");
                System.out.println(" 2. VolksWagen     ");
                System.out.println(" 3. Salir          ");
                System.out.println("-------------------");
                System.out.println("");
                
                opAutomoviles = Csc.nextByte();
                switch(opAutomoviles){
                    case 1:
                        if(a == 1){
                            auto.Ford_ventaA();
                        }else if(a == 0){
                            break;
                        }else{
                            auto.Ford_preventaA();
                        }
                        break;
                    case 2:
                        if(a == 1){
                            auto.Ford_ventaA();
                        }else if(a == 0){
                            break;
                        }else{
                            auto.Ford_preventaA();
                        }
                        break;
                    case 3:
                        break;
                    default:
                        System.out.println("Ese opción no existe, intente nuevamente");
                        break;
                        
                }
                break;
            case 2:
                // Menú de automoviles
                System.out.println("-------------------");
                System.out.println("I   CAMIONES 4x4  I");
                System.out.println("-------------------");
                System.out.println(" 1. Ford           ");
                System.out.println(" 2. VolksWagen     ");
                System.out.println(" 3. Salir          ");
                System.out.println("-------------------");
                System.out.println("");
                
                opCamionetas = Csc.nextByte();
                switch(opCamionetas){
                    case 1:
                        if(a == 1){
                            camion.Ford_ventaC();
                        }else if(a == 0){
                            break;
                        }else{
                            camion.Ford_preventaC();
                        }
                        break;
                    case 2:
                        if(a == 1){
                            camion.Ford_ventaC();
                        }else if(a == 0){
                            break;
                        }else{
                            camion.Ford_preventaC();
                        }
                        break;
                    case 3:
                        break;
                    default:                        
                        System.out.println("Ese opción no existe, intente nuevamente");
                        break;
                }
                break;
            case 3:
                break;
            default:
                System.out.println("Esa opción no existe, intente nuevamente");
                break;
        }
    }
}
