
package concesionarioa404;
import java.util.ArrayList;

public interface IControladorVehiculos {   
    public ArrayList array = new ArrayList();
    
    public abstract void registrarVehiculo(String cod, String mar, String nom, String tip, String  pre);
    public abstract DataVehiculo verInfoVehiculo(String cod);
    public abstract void eliminarVehiculo(String cod);
    public abstract ArrayList Inventario();
}
