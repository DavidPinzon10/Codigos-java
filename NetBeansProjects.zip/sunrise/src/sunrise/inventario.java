
package sunrise;
public class inventario {
   
int cl1=20220, cl2=20220, cl3=20222, cl4=20222, cl5=20223, cl6=20224, cl7=20226, cl8=20227, cl9=20228, cl10=20229;
String cs[] = {"GA10"+"SV10"+"GA10"+"CE10"+"LV10"+"LV10"+"CH01"+"CH01"+"SV10"+"LE70"+"LE70"};
int cantS=2, cantS2=5, cantS3=10, cantS4=6,cantS5=3, cantS6=2, cantS7=2, cantS8=1, cantS9=7, cantS10=18, cantS11=15;
    
    int cliente;
    String CodigoS;
    String descrip;
    int cantidad;
    int costo;
    int subtotal;
    double descuento;
    int iva;
    double total;
    String tabla2;

    public inventario(int cliente, String CodigoS, String descrip, int cantidad, int costo, int subtotal, double descuento, int iva, double total, String tabla2) {
        this.cliente = cliente;
        this.CodigoS = CodigoS;
        this.descrip = descrip;
        this.cantidad = cantidad;
        this.costo = costo;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.iva = iva;
        this.total = total;
        this.tabla2 = tabla2;
    }
    public int getCliente() {
       
        return cliente;
    }

    public String getCodigoS() {
        return CodigoS;
    }

    public String getDescrip() {
        return descrip;
    }

    public int getCantidad() {
        return cantidad;
    }

    public int getCosto() {
        return costo;
    }

    public int getSubtotal() {
        
        return subtotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public int getIva() {
        return iva;
    }

    public double getTotal() {
        return total;
    }
    public String getTabla2(){
        return tabla2;
    }
    
}
