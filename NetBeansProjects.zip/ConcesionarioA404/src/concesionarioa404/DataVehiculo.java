
package concesionarioa404;

public class DataVehiculo {
    private String codigo;
    private String marca;
    private String nombre;
    private String tipo;
    private String precio;
    
    public DataVehiculo(){
        this.codigo = "";
        this.marca = "";
        this.nombre = "";
        this.tipo = "";
        this.precio = "";
    }    
    public DataVehiculo(String cod, String mar, String nom, String tip, String pre){
        this.codigo = cod;
        this.marca = mar;
        this.nombre = nom;
        this.tipo = tip;
        this.precio = pre;
    }
    
    // Los getter

    public String getCodigo() {
        return codigo;
    }
    public String getMarca() {
        return marca;
    }
    public String getNombre() {
        return nombre;
    }
    public String getTipo() {
        return tipo;
    }
    public String getPrecio() {
        return precio;
    }
    
}
