
package concesionarioa404;

public class ControladorCliente implements IControladorCliente {
    
    public ControladorCliente(){
        
    }
    
    @Override
    public void registrarCliente(String nom, String ape, String num, String ced, String tar){
        //Instancio al manejador
        AdministradorCliente ac = AdministradorCliente.getinstance();
        //Creo el elemento
        Cliente c = new Cliente(nom, ape, num, ced, tar);
        //Lo agrego a la colección global
        ac.addCliente(c);
    }
    
    @Override
    public DataCliente verInfoCliente(String nom){
        AdministradorCliente ac = AdministradorCliente.getinstance();
        Cliente c = ac.obtenerCliente(nom);
        if (c!= null)
            return new DataCliente(c.getNombre(),c.getApellido(),c.getNumero(),c.getCedula(), c.getTarjeta());
        else
            return new DataCliente("---------","---------","---------","---------","---------");
    }
    
    @Override
    public void eliminarCliente(String nom){
        //Instancio al manejador
        AdministradorCliente ac = AdministradorCliente.getinstance();
        //Lo elimino
        ac.eliminarCliente(nom);
    }
}
