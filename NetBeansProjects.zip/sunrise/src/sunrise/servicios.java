package sunrise;
import java.util.Scanner;
public class servicios {
   Scanner leer = new Scanner(System.in); 
   
    int s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11;
    
    String total;
    String codigo;
    String tabla2;
    String descripcion;
    
    int cos1=0, cos2=0, cos3=0, cos4=0, cos5=0, cos6=0, cos7=0,
        cos8=0, cos9=0, cos10=0, cos11=0;
    
    int iva, iva2, iva3, iva4, iva5, iva6, iva7, iva8, iva9, iva10, iva11;
    
    double des, des1, des2, des3, des4, des5, des6, des7, des8, des9, des10, des11;
    
    double tot, tot2, tot3, tot4, tot5, tot6, tot7, tot8, tot9, tot10, tot11;
    
    public void servicios(String codigo,String total, String tabla2) {
        this.codigo = codigo;
        this.total = total;
        this.tabla2 = tabla2;
        this.descripcion = descripcion;
    }
    public String getCodigo() {
     System.out.println("<--------------------------------------------------------------------------------->");
     System.out.println("<                              TABLA DE REFERENCIA                                >");
     System.out.println("<--------------------------------------------------------------------------------->");
     System.out.println(" CODIGO       ||        DESCRIPCION      ||       COSTO     ||       DESCUENTO     ");
     System.out.println("<--------------------------------------------------------------------------------->");
        return codigo;
    }
    public String getTotal(){
        
        String Nombres[] = {"  CE10        |"+"|       Cena especial     |"+"|     $150.000    |"+"|         1.5% "};
        String Nombres2[] ={"  CH01        |"+"|     Camara hiperbarica  |"+"|     $180.000    |"+"|         1.0% "};
        String Nombres3[] ={"  LV10        |"+"|      Cocteles varios    |"+"|     $17.000     |"+"|         2.5% "};
        String Nombres4[] ={"  GA10        |"+"|    Gaseosa varios tipos |"+"|     $3.500      |"+"|         2.0% "};
        String Nombres5[] ={"  LE70        |"+"|      Llamada exterior   |"+"|     $20.000     |"+"|         0.0% "};
        String Nombres6[] ={"  SV10        |"+"|     Servicio vehiculo   |"+"|     $50.000     |"+"|         3.0% "};

            System.out.println("" + Nombres [0]);
            System.out.println("" + Nombres2[0]);
            System.out.println("" + Nombres3[0]);
            System.out.println("" + Nombres4[0]);
            System.out.println("" + Nombres5[0]);
            System.out.println("" + Nombres6[0]);
       
        return total;
    }
    public String tabla2(){
        s1 = 17000;  s2 = 50000;  s3 = 3500;  s4 = 150000;  s5 = 17000;  s6 = 17000;
        s7 = 180000; s8 = 180000; s9 = 50000; s10 = 20000; s11 = 20000; 
        
        cos1 = s1*2; cos2 = s2*5; cos3 = s3*10; cos4  = s4*6;    cos5 = s5*3; cos6 = s6*2;
        cos7 = s7*2; cos8 = s8*1; cos9 = s9*7;  cos10 = s10*18; cos11 = s11*15;
        
        iva   = (cos1*16)/100;    iva2 = (cos2*16)/100;  iva3 = (cos3*16)/100;  iva4 = (cos4*16)/100;  iva5  = (cos5*16)/100;
        iva6  = (cos6*16)/100;    iva7 = (cos7*16)/100;  iva8 = (cos8*16)/100;  iva9 = (cos9*16)/100;  iva10 = (cos10*16)/100;
        iva11 = (cos11*16)/100;
        
        des = (cos1*2.5)/100;  des2 = (cos2*3.0)/100; des3 = (cos3*2.0)/100;  des4 = (cos4*1.5)/100;   des5 = (cos5*2.5)/100; des6 = (cos6*2.5)/100;
        des7 = (cos7*1.0)/100; des8 = (cos8*1.0)/100; des9 = (cos9*3.0)/100; des10 = (cos10*0.0)/100; des11 = (cos11*0.0)/100;
        
         tot = cos1-(des+iva);   tot2 = cos2-(des2+iva2); tot3 = cos3-(des3+iva3);  tot4 = cos4-(des4+iva4);     tot5 = cos5-(des5+iva5); tot6 = cos6-(des6+iva6);
        tot7 = cos7-(des7+iva7); tot8 = cos8-(des8+iva8); tot9 = cos9-(des9+iva9); tot10 = cos10-(des10+iva10); tot11 = cos11-(des11+iva11);
      
        String fila[]   ={"  20220   |"+"    GA10    |"+"  Cocteles Varios      |"+"     2    |"+"  $17.000 |  "+cos1+ "      |       "+des+  "    |     "+iva+  "     |   "+tot+  "    |    BAJO       |"};
        String fila2[]  ={"  20220   |"+"    SV10    |"+"  Servicio Vehículo    |"+"     5    |"+"  $50.000 |  "+cos2+ "     |      "+des2+ "    |     "+iva2+ "    |   "+tot2+ "   |    REGULAR    |"};
        String fila3[]  ={"  20222   |"+"    GA10    |"+"  Gaseosa Varios Tipos |"+"     10   |"+"   $3.500 |  "+cos3+ "      |       "+des3+ "    |     "+iva3+ "     |   "+tot3+ "    |    REGULAR    |"};
        String fila4[]  ={"  20222   |"+"    CE10    |"+"  Cena Especial        |"+"     6    |"+" $150.000 |  "+cos4+ "     |      "+des4+ "   |     "+iva4+ "   |   "+tot4+ "   |    REGULAR    |"};
        String fila5[]  ={"  20223   |"+"    LV10    |"+"  Cocteles Varios      |"+"     3    |"+"  $17.000 |  "+cos5+ "      |      "+des5+ "    |     "+iva5+ "     |   "+tot5+ "    |    REGULAR    |"};
        String fila6[]  ={"  20224   |"+"    LV10    |"+"  Cocteles Varios      |"+"     2    |"+"  $17.000 |  "+cos6+ "      |      "+des6+ "     |     "+iva6+ "     |   "+tot6+ "    |    BAJO       |"};
        String fila7[]  ={"  20225   |"+"    CH01    |"+"  Camara Hiperbarica   |"+"     2    |"+" $180.000 |  "+cos7+ "     |      "+des7+ "    |     "+iva7+ "    |   "+tot7+ "   |    BAJO       |"};
        String fila8[]  ={"  20226   |"+"    CH01    |"+"  Camara Hiperbarica   |"+"     1    |"+" $180.000 |  "+cos8+ "     |      "+des8+ "    |     "+iva8+ "    |   "+tot8+ "   |    BAJO       |"};
        String fila9[]  ={"  20227   |"+"    SV10    |"+"  Servicio Vehículo    |"+"     7    |"+"  $50.000 |  "+cos9+ "     |      "+des9+ "   |     "+iva9+ "    |   "+tot9+ "   |    REGULAR    |"};
        String fila10[] ={"  20228   |"+"    LE70    |"+"  Llamada Exterior     |"+"     18   |"+"  $20.000 |  "+cos10+"     |      "+des10+"       |     "+iva10+"    |   "+tot10+"   |    REGULAR    |"};
        String fila11[] ={"  20229   |"+"    LE70    |"+"  Llamada Exterior     |"+"     15   |"+"  $20.000 |  "+cos11+"     |      "+des11+"       |     "+iva11+"    |   "+tot11+"   |    REGULAR    |"};

            System.out.println("" + fila  [0]);
            System.out.println("" + fila2 [0]);
            System.out.println("" + fila3 [0]);
            System.out.println("" + fila4 [0]);
            System.out.println("" + fila5 [0]);
            System.out.println("" + fila6 [0]);
            System.out.println("" + fila7 [0]);
            System.out.println("" + fila8 [0]);
            System.out.println("" + fila9 [0]);
            System.out.println("" + fila10[0]);
            System.out.println("" + fila11[0]);
        
    return tabla2;
    }
    
}
