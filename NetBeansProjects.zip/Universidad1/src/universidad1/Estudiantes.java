package universidad1;
import java.util.Scanner;

public class Estudiantes {
    Scanner leer = new Scanner(System.in);
   
    private String estudiante1;
    private String estudiante2;
    private String estudiante3;
    private String estudiante4;
    private String estudiante5;
    private String admin;
   
     public Estudiantes() {
        this.estudiante1 = "";
        this.estudiante2 = "";
        this.estudiante3 = "";
        this.estudiante4 = "";
        this.estudiante5 = "";
        this.admin = "";
     }
    public Estudiantes(String estudiante1, String estudiante2, String estudiante3, String estudiante4, String estudiante5, String admin) {
        this.estudiante1 = estudiante1;
        this.estudiante2 = estudiante2;
        this.estudiante3 = estudiante3;
        this.estudiante4 = estudiante4;
        this.estudiante5 = estudiante5;
        this.admin = admin;
    }
    public String getEstudiante1() {
       
        double edad, codigo, d1=0, d2=0, d3=0, d4=0, d5=0, promedio;
        String nombre;
       
        System.out.println("Digite su nombre y apellido :");
        nombre = leer.nextLine();
        System.out.println("Digite su edad :");
        edad = leer.nextInt();
        System.out.println("Digite su codigo :");
        codigo = leer.nextInt();
       
          double matriz[][] = new double [5][3];
       
          //Llenar la matriz con datos registrados por usuario
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.println("Digite las notas en orden : "+i+" , "+j+"");
                matriz[i][j] = leer.nextDouble();
                System.out.println("");
            }
        }
        for (int i = 0; i < matriz.length; i++) {
            double suma = 0, sumaP = 0;
            
            for (int j = 0; j < matriz[0].length; j++) {

                System.out.println("Nota "+i+","+j+" = "+ matriz[i][j]);

                suma += matriz[i][j]/3;
            }
           System.out.println("La definitiva de su materia es : "+suma);
           System.out.println("--------");
           System.out.println("--------");
        }
        System.out.println("Estudiante "+nombre+" de codigo "+codigo+", sus notas fueron registradas.");
        System.out.println(".........");
        System.out.println("Ahora registre sus notas para conocer el promedio del semestre :");
        d1 = leer.nextDouble();d2 = leer.nextDouble();d3 = leer.nextDouble();
        d4 = leer.nextDouble();d5 = leer.nextDouble();
        promedio = (d1+d2+d3+d4+d5)/5;
        System.out.println("...");
        System.out.println("Su promedio semestral es de : "+promedio);
        
        if (promedio >= 3) {
            System.out.println("FELICIDADES, APROBASTE EL SEMESTRE");
        }else{
            if (promedio < 3) {
                System.out.println("LO SENTIMOS, SIGUE INTENTANDO");
            }
        }
        
        return estudiante1;
    }

    public void setEstudiante1(String estudiante1) {
        this.estudiante1 = estudiante1;
    }

    public String getEstudiante2() {
        double edad, codigo, d1=0, d2=0, d3=0, d4=0, d5=0, promedio;
        String nombre;
       
        System.out.println("Digite su nombre y apellido :");
        nombre = leer.nextLine();
        System.out.println("Digite su edad :");
        edad = leer.nextInt();
        System.out.println("Digite su codigo :");
        codigo = leer.nextInt();
       
          double matriz[][] = new double [5][3];
       
          //Llenar la matriz con datos registrados por usuario
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.println("Digite las notas en orden : "+i+" , "+j+"");
                matriz[i][j] = leer.nextDouble();
                System.out.println("");
            }
        }
        for (int i = 0; i < matriz.length; i++) {
            double suma = 0, sumaP = 0;
            
            for (int j = 0; j < matriz[0].length; j++) {

                System.out.println("Nota "+i+","+j+" = "+ matriz[i][j]);

                suma += matriz[i][j]/3;
            }
           System.out.println("La definitiva de su materia es : "+suma);
           System.out.println("--------");
           System.out.println("--------");
        }
        System.out.println("Estudiante "+nombre+" de codigo "+codigo+", sus notas fueron registradas.");
        System.out.println(".........");
        System.out.println("Ahora registre sus notas para conocer el promedio del semestre :");
        d1 = leer.nextDouble();d2 = leer.nextDouble();d3 = leer.nextDouble();
        d4 = leer.nextDouble();d5 = leer.nextDouble();
        promedio = (d1+d2+d3+d4+d5)/5;
        System.out.println("...");
        System.out.println("Su promedio semestral es de : "+promedio);
        
        if (promedio >= 3) {
            System.out.println("FELICIDADES, APROBASTE EL SEMESTRE");
        }else{
            if (promedio < 3) {
                System.out.println("LO SENTIMOS, SIGUE INTENTANDO");
            }
        }
        
        return estudiante2;
    }
   
    public void setEstudiante2(String estudiante2) {
        this.estudiante2 = estudiante2;
    }

    public String getEstudiante3() {
        double edad, codigo, d1=0, d2=0, d3=0, d4=0, d5=0, promedio;
        String nombre;
       
        System.out.println("Digite su nombre y apellido :");
        nombre = leer.nextLine();
        System.out.println("Digite su edad :");
        edad = leer.nextInt();
        System.out.println("Digite su codigo :");
        codigo = leer.nextInt();
       
          double matriz[][] = new double [5][3];
       
          //Llenar la matriz con datos registrados por usuario
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.println("Digite las notas en orden : "+i+" , "+j+"");
                matriz[i][j] = leer.nextDouble();
                System.out.println("");
            }
        }
        for (int i = 0; i < matriz.length; i++) {
            double suma = 0, sumaP = 0;
            
            for (int j = 0; j < matriz[0].length; j++) {

                System.out.println("Nota "+i+","+j+" = "+ matriz[i][j]);

                suma += matriz[i][j]/3;
            }
           System.out.println("La definitiva de su materia es : "+suma);
           System.out.println("--------");
           System.out.println("--------");
        }
        System.out.println("Estudiante "+nombre+" de codigo "+codigo+", sus notas fueron registradas.");
        System.out.println(".........");
        System.out.println("Ahora registre sus notas para conocer el promedio del semestre :");
        d1 = leer.nextDouble();d2 = leer.nextDouble();d3 = leer.nextDouble();
        d4 = leer.nextDouble();d5 = leer.nextDouble();
        promedio = (d1+d2+d3+d4+d5)/5;
        System.out.println("...");
        System.out.println("Su promedio semestral es de : "+promedio);
        
        if (promedio >= 3) {
            System.out.println("FELICIDADES, APROBASTE EL SEMESTRE");
        }else{
            if (promedio < 3) {
                System.out.println("LO SENTIMOS, SIGUE INTENTANDO");
            }
        }
        
        return estudiante3;
    }

    public void setEstudiante3(String estudiante3) {
        this.estudiante3 = estudiante3;
    }

    public String getEstudiante4() {
        double edad, codigo, d1=0, d2=0, d3=0, d4=0, d5=0, promedio;
        String nombre;
       
        System.out.println("Digite su nombre y apellido :");
        nombre = leer.nextLine();
        System.out.println("Digite su edad :");
        edad = leer.nextInt();
        System.out.println("Digite su codigo :");
        codigo = leer.nextInt();
       
          double matriz[][] = new double [5][3];
       
          //Llenar la matriz con datos registrados por usuario
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.println("Digite las notas en orden : "+i+" , "+j+"");
                matriz[i][j] = leer.nextDouble();
                System.out.println("");
            }
        }
        for (int i = 0; i < matriz.length; i++) {
            double suma = 0, sumaP = 0;
            
            for (int j = 0; j < matriz[0].length; j++) {

                System.out.println("Nota "+i+","+j+" = "+ matriz[i][j]);

                suma += matriz[i][j]/3;
            }
           System.out.println("La definitiva de su materia es : "+suma);
           System.out.println("--------");
           System.out.println("--------");
        }
        System.out.println("Estudiante "+nombre+" de codigo "+codigo+", sus notas fueron registradas.");
        System.out.println(".........");
        System.out.println("Ahora registre sus notas para conocer el promedio del semestre :");
        d1 = leer.nextDouble();d2 = leer.nextDouble();d3 = leer.nextDouble();
        d4 = leer.nextDouble();d5 = leer.nextDouble();
        promedio = (d1+d2+d3+d4+d5)/5;
        System.out.println("...");
        System.out.println("Su promedio semestral es de : "+promedio);
        
        if (promedio >= 3) {
            System.out.println("FELICIDADES, APROBASTE EL SEMESTRE");
        }else{
            if (promedio < 3) {
                System.out.println("LO SENTIMOS, SIGUE INTENTANDO");
            }
        }
        
        return estudiante4;
    }

    public void setEstudiante4(String estudiante4) {
        this.estudiante4 = estudiante4;
    }

    public String getEstudiante5() {
        double edad, codigo, d1=0, d2=0, d3=0, d4=0, d5=0, promedio;
        String nombre;
       
        System.out.println("Digite su nombre y apellido :");
        nombre = leer.nextLine();
        System.out.println("Digite su edad :");
        edad = leer.nextInt();
        System.out.println("Digite su codigo :");
        codigo = leer.nextInt();
       
          double matriz[][] = new double [5][3];
       
          //Llenar la matriz con datos registrados por usuario
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.println("Digite las notas en orden : "+i+" , "+j+"");
                matriz[i][j] = leer.nextDouble();
                System.out.println("");
            }
        }
        for (int i = 0; i < matriz.length; i++) {
            double suma = 0, sumaP = 0;
            
            for (int j = 0; j < matriz[0].length; j++) {

                System.out.println("Nota "+i+","+j+" = "+ matriz[i][j]);

                suma += matriz[i][j]/3;
            }
           System.out.println("La definitiva de su materia es : "+suma);
           System.out.println("--------");
           System.out.println("--------");
        }
        System.out.println("Estudiante "+nombre+" de codigo "+codigo+", sus notas fueron registradas.");
        System.out.println(".........");
        System.out.println("Ahora registre sus notas para conocer el promedio del semestre :");
        d1 = leer.nextDouble();d2 = leer.nextDouble();d3 = leer.nextDouble();
        d4 = leer.nextDouble();d5 = leer.nextDouble();
        promedio = (d1+d2+d3+d4+d5)/5;
        System.out.println("...");
        System.out.println("Su promedio semestral es de : "+promedio);
        
        if (promedio >= 3) {
            System.out.println("FELICIDADES, APROBASTE EL SEMESTRE");
        }else{
            if (promedio < 3) {
                System.out.println("LO SENTIMOS, SIGUE INTENTANDO");
            }
        }
        
        return estudiante5;
    }
    public void setEstudiante5(String estudiante5) {
        this.estudiante5 = estudiante5;
    }
    public String getAdmin (){
        double p1=0,p2=0,p3=0,p4=0,p5=0,promT=0;
        
        System.out.println("Digite el promedio de cada estudiante :");
        p1=leer.nextDouble();p2=leer.nextDouble();p3=leer.nextDouble();
        p4=leer.nextDouble();p5=leer.nextDouble();
        promT=(p1+p2+p3+p4+p5)/5;
        
        System.out.println("-------------------------------------------------------");
        System.out.println("Este es el promedio en total de todos los estudiosos: "+promT);
        return admin;
    }
}
