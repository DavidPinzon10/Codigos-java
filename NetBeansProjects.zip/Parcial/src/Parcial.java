
import java.util.Scanner;

/**
 * @author David Pinzon
 */
public class Parcial {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.println("Cliente 1");
        String nombre_1 = "";
        String nombre_2 = "";
        int clave, zona;
        int MinutosNA = 0, MinutosCA = 0, MinutosSA = 0, MinutosE = 0, MinutosAS = 0, MinutosAF = 0, MinutosO = 0;
        int MinutosNA2 = 0, MinutosCA2 = 0, MinutosSA2 = 0, MinutosE2 = 0, MinutosAS2 = 0, MinutosAF2 = 0, MinutosO2 = 0;
        int Siguiente_cliente = 0;

        float Subtotal;
        float Subtotal2;
        float SubtotalNA = 0;
        float SubtotalCA = 0;
        float SubtotalSA = 0;
        float SubtotalE = 0;
        float SubtotalAS = 0;
        float SubtotalAF = 0;
        float SubtotalO = 0;

        float PrecioNorteA = 2;
        float PrecioCentroA = 2.2f;
        float PrecioSurA = 4.5f;
        float PrecioEuropa = 3.5f;
        float PrecioAsia = 6;
        float PrecioAfrica = 6;
        float PrecioOceania = 5;
        
        float SubtotalNA2 = 0;
        float SubtotalCA2 = 0;
        float SubtotalSA2 = 0;
        float SubtotalE2 = 0;
        float SubtotalAS2 = 0;
        float SubtotalAF2 = 0;
        float SubtotalO2 = 0;

        float PrecioNorteA2 = 2;
        float PrecioCentroA2 = 2.2f;
        float PrecioSurA2 = 4.5f;
        float PrecioEuropa2 = 3.5f;
        float PrecioAsia2 = 6;
        float PrecioAfrica2 = 6;
        float PrecioOceania2 = 5;

        float Total_Pagar1 = 0;
        float Total_Pagar2 = 0;

        byte opcion = 0;

        System.out.println("Digite su nombre por favor");
        nombre_1 = leer.nextLine();

        System.out.println("Muchas gracias por entrar al programar sr " + nombre_1 + ", a continuación el menu ");

        while (true) {
            System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
            System.out.println("     Bienvenidos a Llamadas con David");
            System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
            System.out.println("CLAVE            ZONA              PRECIO");
            System.out.println(" 12.         Norte America          $ 2 ");
            System.out.println(" 15.         Centro America         $ 2.2 ");
            System.out.println(" 18.          Sur America           $ 4.5 ");
            System.out.println(" 19.            Europa              $ 3.5 ");
            System.out.println(" 25.             Asia               $ 6 ");
            System.out.println(" 26.            Africa              $ 6 ");
            System.out.println(" 29.           Oceania              $ 5 ");
            System.out.println(" 0.         Acabar llamada        Gracias");
            System.out.println(" 2.        Siguiente cliente              ");
            System.out.println(" 1.             Adiós                    ");
            System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
            System.out.println("Digite la clave de la zona a la que desea llamar");
            opcion = leer.nextByte();

            switch (opcion) {

                case 12:
                    System.out.println("Digite el numero de minutos que va a llamar ");
                    MinutosNA = leer.nextInt();
                    break;

                case 15:
                    System.out.println("Digite el numero de minutos que va a llamar ");
                    MinutosCA = leer.nextInt();
                    break;

                case 18:
                    System.out.println("Digite el numero de minutos que va a llamar ");
                    MinutosSA = leer.nextInt();
                    break;

                case 19:
                    System.out.println("Digite el numero de minutos que va a llamar ");
                    MinutosE = leer.nextInt();
                    break;

                case 25:
                    System.out.println("Digite el numero de minutos que va a llamar ");
                    MinutosAS = leer.nextInt();
                    break;

                case 26:
                    System.out.println("Digite el numero de minutos que va a llamar ");
                    MinutosAF = leer.nextInt();
                    break;

                case 29:
                    System.out.println("Digite el numero de minutos que va a llamar ");
                    MinutosO = leer.nextInt();
                    break;
                    
                case 2:
                    while (true) {
                        System.out.println("Digite su nombre por favor");
                        nombre_2 = leer.nextLine();

                        System.out.println("Muchas gracias por entrar al programar sr " + nombre_2 + ", a continuación el menu ");

                        System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
                        System.out.println("     Bienvenidos a Llamadas con David");
                        System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
                        System.out.println("CLAVE            ZONA              PRECIO");
                        System.out.println(" 12.         Norte America          $ 2 ");
                        System.out.println(" 15.         Centro America         $ 2.2 ");
                        System.out.println(" 18.          Sur America           $ 4.5 ");
                        System.out.println(" 19.            Europa              $ 3.5 ");
                        System.out.println(" 25.             Asia               $ 6 ");
                        System.out.println(" 26.            Africa              $ 6 ");
                        System.out.println(" 29.           Oceania              $ 5 ");
                        System.out.println(" 0.         Acabar llamada        Gracias");
                        System.out.println(" 2.        Siguiente cliente              ");
                        System.out.println(" 1.             Adiós                    ");
                        System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
                        System.out.println("Digite la clave de la zona a la que desea llamar");
                        opcion = leer.nextByte();

                        switch (opcion) {

                            case 12:
                                System.out.println("Digite el numero de minutos que va a llamar ");
                                MinutosNA2 = leer.nextInt();
                                break;

                            case 15:
                                System.out.println("Digite el numero de minutos que va a llamar ");
                                MinutosCA2 = leer.nextInt();
                                break;

                            case 18:
                                System.out.println("Digite el numero de minutos que va a llamar ");
                                MinutosSA2 = leer.nextInt();
                                break;

                            case 19:
                                System.out.println("Digite el numero de minutos que va a llamar ");
                                MinutosE2 = leer.nextInt();
                                break;

                            case 25:
                                System.out.println("Digite el numero de minutos que va a llamar ");
                                MinutosAS2 = leer.nextInt();
                                break;

                            case 26:
                                System.out.println("Digite el numero de minutos que va a llamar ");
                                MinutosAF2 = leer.nextInt();
                                break;

                            case 29:
                                System.out.println("Digite el numero de minutos que va a llamar ");
                                MinutosO2 = leer.nextInt();
                                break;

                            case 0:
                                System.out.println("Gracias por usar el programa, a continuacion el total a pagar");

                                if (MinutosNA2 > 0) {
                                    System.out.println("El precio a norte america es $" + PrecioNorteA2 + " y los minutos fueron " + MinutosNA2);
                                    SubtotalNA2 = PrecioNorteA2 * MinutosNA2;
                                    System.out.println("Por lo tanto, el costo a pagar es = $" + SubtotalNA2);
                                }
                                if (MinutosCA2 > 0) {
                                    System.out.println("El precio a centro america es $" + PrecioCentroA2 + " y los minutos fueron " + MinutosCA2);
                                    SubtotalCA = PrecioCentroA2 * MinutosCA2;
                                    System.out.println("Por lo tanto, el costo a pagar es = $" + SubtotalCA2);
                                }
                                if (MinutosSA2 > 0) {
                                    System.out.println("El precio a sur america es $" + PrecioSurA2 + " y los minutos fueron " + MinutosSA2);
                                    SubtotalSA2 = PrecioSurA2 * MinutosSA2;
                                    System.out.println("Por lo tanto, el costo a pagar es = $" + MinutosSA2);
                                }
                                if (MinutosE2 > 0) {
                                    System.out.println("El precio a europa es $" + PrecioEuropa2 + " y los minutos fueron " + MinutosE2);
                                    SubtotalE2 = PrecioEuropa2 * MinutosE2;
                                    System.out.println("Por lo tanto el costo a pagar es = $" + SubtotalE2);
                                }
                                if (MinutosAS2 > 0) {
                                    System.out.println("El precio a asia es $" + PrecioAsia2 + " y los minutos fueron " + MinutosAS2);
                                    SubtotalAS2 = PrecioAsia2 * MinutosAS2;
                                    System.out.println("Por lo tanto el costo a pagar es = $" + SubtotalAS2);
                                }
                                if (MinutosAF2 > 0) {
                                    System.out.println("El precio a africa es $" + PrecioAfrica2 + " y los minutos fueron " + MinutosAF2);
                                    SubtotalAF2 = PrecioAfrica2 * MinutosAF2;
                                    System.out.println("Por lo tanto, el costo a pagar es = $" + SubtotalAF2);
                                }
                                if (MinutosO2 > 0) {
                                    System.out.println("El precio a oceania es $" + PrecioOceania2 + " y los minutos fueron " + MinutosO2);
                                    SubtotalO = PrecioOceania2 * MinutosO2;
                                    System.out.println("Por lo tanto, el costo a pagar es = $" + SubtotalO2);
                                }

                                Subtotal = SubtotalNA + SubtotalCA + SubtotalSA + SubtotalE + SubtotalAS + SubtotalAF + SubtotalO;
                                
                                System.out.println("Cliente 1");
                                System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
                                System.out.println("...........Subtotal es = " + Subtotal);
                                System.out.println(".");

                                Total_Pagar1 = Subtotal;
                                System.out.println("...EL total a pagar es = " + Total_Pagar1);
                                System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
                                float cliente_1 = Total_Pagar1;

                                Subtotal2 = SubtotalNA2 + SubtotalCA2 + SubtotalSA2 + SubtotalE2 + SubtotalAS2 + SubtotalAF2 + SubtotalO2;
                                
                                System.out.println("Cliente 2");
                                System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
                                System.out.println("...........Subtotal es = " + Subtotal2);
                                System.out.println(".");

                                Total_Pagar2 = Subtotal2;
                                System.out.println("...EL total a pagar es = " + Total_Pagar2);
                                System.out.println("I-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-I");
                                float cliente_2 = Total_Pagar2;

                                float promedio = (Total_Pagar1 + Total_Pagar2) / 2;
                                cliente_1 = Total_Pagar1;
                                cliente_2 = Total_Pagar2;
                                float costo_llamadas = Total_Pagar1 + Total_Pagar2;

                                System.out.println("----------------------------------------------------------------------------");
                                System.out.println("                               RESUMEN LLAMADAS");
                                System.out.println("----------------------------------------------------------------------------");
                                System.out.println("El costo de todas las llamadas en total es = $" + costo_llamadas);
                                costo_llamadas = Total_Pagar1 + Total_Pagar2;
                                System.out.println("El promedio de las llamadas es = $" + promedio);
                                promedio = (cliente_1 + cliente_2) / 2;
                                System.out.println("----------------------------------------------------------------------------");

                                break;

                            case 1:
                                System.out.println("Hasta luego");

                                if (opcion == 1) {
                                    System.out.println("Gracias, ya puede retirarse");

                                    break;
                                }
                        }
                    }
                    case 1:
                                System.out.println("Hasta luego");

                                if (opcion == 1) {
                                    System.out.println("Gracias, ya puede retirarse");

                                    break;
            }
        }
    }
}
}
