
package Visual;
import concesionarioa404.Vehiculo;
import concesionarioa404.DataVehiculo;
import concesionarioa404.Fabrica;
import concesionarioa404.IControladorVehiculos;
import concesionarioa404.ArchivosVehiculos;
import javax.swing.JOptionPane;

public class Agregar extends javax.swing.JInternalFrame {        
    private IControladorVehiculos ICU;    
    
    public Agregar() {
        initComponents();
        this.setSize(270, 265);
        
        //Inicialización
        Fabrica fabrica = Fabrica.getInstance();
        ICU = fabrica.getIControladorVehiculos();        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LabelCrNo1 = new javax.swing.JLabel();
        TextFiedlCrNo1 = new javax.swing.JTextField();
        LabelCrCo = new javax.swing.JLabel();
        LabelCrNo = new javax.swing.JLabel();
        TextFieldAgrCod = new javax.swing.JTextField();
        TextFieldAgrMar = new javax.swing.JTextField();
        ButtonAgrAgr = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        TextFieldAgrNom = new javax.swing.JTextField();
        TextFieldAgrTip = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        TextFieldAgrPre = new javax.swing.JTextField();

        LabelCrNo1.setText("Elemento:");

        setClosable(true);
        setIconifiable(true);
        setTitle("Agregar");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        LabelCrCo.setText("Codigo:");

        LabelCrNo.setText("Marca:");

        ButtonAgrAgr.setText("Agregar");
        ButtonAgrAgr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonAgrAgrActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre:");

        jLabel2.setText("Tipo:");

        TextFieldAgrNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldAgrNomActionPerformed(evt);
            }
        });

        jLabel3.setText("Precio:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 158, Short.MAX_VALUE)
                        .addComponent(ButtonAgrAgr))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(LabelCrNo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(LabelCrCo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TextFieldAgrTip)
                            .addComponent(TextFieldAgrNom)
                            .addComponent(TextFieldAgrCod)
                            .addComponent(TextFieldAgrMar)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(16, 16, 16)
                        .addComponent(TextFieldAgrPre)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelCrCo)
                    .addComponent(TextFieldAgrCod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelCrNo)
                    .addComponent(TextFieldAgrMar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(TextFieldAgrNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(TextFieldAgrTip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(TextFieldAgrPre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonAgrAgr)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonAgrAgrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonAgrAgrActionPerformed
        // Obtenemos los datos escritos por el usuario
        String CodigoV = this.TextFieldAgrCod.getText();
        String MarcaV = this.TextFieldAgrMar.getText();
        String NombreV = this.TextFieldAgrNom.getText();
        String TipoV = this.TextFieldAgrTip.getText();
        String PrecioV = this.TextFieldAgrPre.getText();
        
        // Guardo los datos
        ICU.registrarVehiculo(CodigoV, MarcaV, NombreV, TipoV, PrecioV);                        
        
        //Ver en la consola
        System.out.println(CodigoV+" --- "+MarcaV+" --- "+NombreV+" --- "+TipoV+" --- "+PrecioV);
        
        // Limpiamos 
        this.TextFieldAgrCod.setText("");
        this.TextFieldAgrMar.setText("");
        this.TextFieldAgrNom.setText("");
        this.TextFieldAgrTip.setText("");
        this.TextFieldAgrPre.setText("");
        this.setVisible(false);
        
        // Archivamos
        ArchivosVehiculos ve = new ArchivosVehiculos();
        ve.CrearFichero(CodigoV, MarcaV, NombreV, TipoV, PrecioV);
        
        //Muestro éxito de la operación        
        JOptionPane.showMessageDialog(this, "El vehiculo se a creado exitosamente");
    }//GEN-LAST:event_ButtonAgrAgrActionPerformed

    private void TextFieldAgrNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldAgrNomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldAgrNomActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonAgrAgr;
    private javax.swing.JLabel LabelCrCo;
    private javax.swing.JLabel LabelCrNo;
    private javax.swing.JLabel LabelCrNo1;
    private javax.swing.JTextField TextFiedlCrNo1;
    private javax.swing.JTextField TextFieldAgrCod;
    private javax.swing.JTextField TextFieldAgrMar;
    private javax.swing.JTextField TextFieldAgrNom;
    private javax.swing.JTextField TextFieldAgrPre;
    private javax.swing.JTextField TextFieldAgrTip;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
