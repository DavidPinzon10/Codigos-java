import java.util.Scanner;
/**
 * @author David Pinzón
 */
public class ejercicio6 {
    public static void main(String[] args) {
      Scanner leer = new Scanner(System.in);
        
        int array[] = new int [8];
        int cPares = 0;
        int cImpares = 0;

        
        System.out.println("Digite 8 números enteros");
        for (int i = 0; i < 8; i++) {
            System.out.println(".");
            array[i] = leer.nextInt();
            
              if (array[i] % 2==0) { //Si arreglo es par, aumentar 1
            cPares++;
        }
        else {
            cImpares++;     //Si es impar aumenta 1
        }
        }
        
        int pares[] = new int [cPares]; //almacena los pares
        int impares[] = new int [cImpares]; //almacena los impares
        
        //Como ya tienen un dato específico entonces se van a usar como iteradores
        cPares = 0;     
        cImpares = 0;
        
        
        //Almacenar los datos en sus arreglos independientes
        for (int i = 0; i < 8; i++) {
            if (array[i] % 2==0) { 
                pares [cPares] = array[i]; //Despues de par esta en 0 y arreglo le da valor
                cPares++;
        }
            else {
                impares [cImpares] = array[i];
                cImpares++;
            }
        }
        
        System.out.println("Los pares son = ");
        for (int i = 0; i < cPares; i++) {
            System.out.println(pares[i]+""); 
        }
        System.out.println(""); //Para que haya un espacio entre par e impares.
        
        System.out.println("Los impares son = ");
        for (int i = 0; i < cImpares; i++) {
            System.out.println(impares[i]+""); 
        }
        System.out.println("");
    }
        
}
