
package concesionarioa404;

public class Fabrica {
private static Fabrica instancia;
private Fabrica(){};

    public static Fabrica getInstance(){
    if (instancia == null){
        instancia = new Fabrica();
    }
    return instancia;
}
    
public IControladorVehiculos getIControladorVehiculos() {
    IControladorVehiculos IG = new ControladorVehiculos();
    return IG;
}
public IControladorCliente getIControladorCliente() {
    IControladorCliente IC = new ControladorCliente();
    return IC;
}
}
