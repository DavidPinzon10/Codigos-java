
import java.util.Scanner;

/**
 * @author David Pinzón
 */
public class Ejercicio5 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        String UtilE = "", UtilE2 = "", UtilE3 = "", UtilE4 = "", UtilE5 = "", UtilE6 = "";
        int Precio1 = 0, Precio2 = 0, Precio3 = 0, Precio4 = 0, Precio5 = 0, Precio6 = 0;
        int PrecioCaro = 15000;

        System.out.println("Digite 6 utiles escolares");

        UtilE = leer.nextLine();
        UtilE2 = leer.nextLine();
        UtilE3 = leer.nextLine();
        UtilE4 = leer.nextLine();
        UtilE5 = leer.nextLine();
        UtilE6 = leer.nextLine();

        System.out.println("Estos son sus utiles");
        System.out.println("" + UtilE + "," + UtilE2 + "," + UtilE3 + "," + UtilE4 + "," + UtilE5 + "," + UtilE6);

        System.out.println("----------------------------------------------------------------");
        System.out.println("Ahora digite los precios de cada uno en su orden");

        Precio1 = leer.nextInt();
        Precio2 = leer.nextInt();
        Precio3 = leer.nextInt();
        Precio4 = leer.nextInt();
        Precio5 = leer.nextInt();
        Precio6 = leer.nextInt();

        System.out.println("Listado");
        System.out.println("----------------------------------------------------------------");
        System.out.println("1. " + UtilE + "............................." + Precio1);
        System.out.println("2. " + UtilE2 + "............................" + Precio2);
        System.out.println("3. " + UtilE3 + "............................" + Precio3);
        System.out.println("4. " + UtilE4 + "............................" + Precio4);
        System.out.println("5. " + UtilE5 + "............................" + Precio5);
        System.out.println("6. " + UtilE6 + "............................" + Precio6);
        System.out.println("----------------------------------------------------------------");
        System.out.println("----------------------------------------------------------------");
        System.out.println("Productos que valen más de $ 15.000");

        if (Precio1 >= PrecioCaro) {
            System.out.println("Este util es caro: " + UtilE);
        }
        if (Precio2 >= PrecioCaro) {
            System.out.println("Este util es caro: " + UtilE2);
        }
        if (Precio3 >= PrecioCaro) {
            System.out.println("Este util es caro: " + UtilE3);
        }
        if (Precio4 >= PrecioCaro) {
            System.out.println("Este util es caro: " + UtilE4);
        }
        if (Precio5 >= PrecioCaro) {
            System.out.println("Este util es caro: " + UtilE5);
        }
        if (Precio6 >= PrecioCaro) {
            System.out.println("Este util es caro: " + UtilE6);
        }
    }
}
