
package concesionarioa404;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;

public class AdministradorVehiculo {
    //Clase que conserva la colección global de los Usuarios del Sistema    
    
    private Map<String, Vehiculo> vehiculoCOD = new HashMap<String, Vehiculo>();
    private static AdministradorVehiculo instancia=null;
    public ArrayList array = new ArrayList();
    
    private AdministradorVehiculo(){
        vehiculoCOD = new HashMap();
    }
    
    public static AdministradorVehiculo getinstance(){
        if (instancia==null)
            instancia = new AdministradorVehiculo();
        return instancia;
    }
    
    public void addVehiculo(Vehiculo veh){
        String cod = veh.getCodigo();
        vehiculoCOD.put(cod,veh);
    }
    
    public void eliminarVehiculo(String veh){       
        vehiculoCOD.remove(veh);
    }
    
    public Vehiculo obtenerVehiculo(String cod){
        return ((Vehiculo) vehiculoCOD.get(cod));
    }
    
    public ArrayList inventario(){        
        array.add(" - - - - ");
        
        for (Map.Entry<String,Vehiculo> mapa: vehiculoCOD.entrySet()){
            array.add(mapa.getKey()+" - "+mapa.getValue());
            return array;
        }
        return array;
    }
}
