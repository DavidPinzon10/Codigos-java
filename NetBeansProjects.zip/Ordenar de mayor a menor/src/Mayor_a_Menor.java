import java.util.Scanner;
/*
 * @author David Pinzón
 */
public class Mayor_a_Menor {

    public static void main(String[] args) {
        Scanner String = new Scanner(System.in);

        int num1, num2, num3, num4, num5;

        System.out.println("Digite el valor del primer numero = ");
        num1 = String.nextInt();

        System.out.println("Digite el valor del segundo numero = ");
        num2 = String.nextInt();

        System.out.println("Digite el valor del tercer numero = ");
        num3 = String.nextInt();

        System.out.println("Digite el valor del cuarto numero = ");
        num4 = String.nextInt();

        System.out.println("Digite el valor del quinto numero = ");
        num5 = String.nextInt();

        System.out.println("Los números de mayor a menor son");

        if (num1 <= num2) {
            num1 += num2;
            num2 = num1 - num2;
            num1 -= num2;
        }
        if (num1 <= num3) {
            num1 += num3;
            num3 = num1 - num3;
            num1 -= num3;
        }
        if (num1 <= num4) {
            num1 += num4;
            num4 = num1 - num4;
            num1 -= num4;
        }
        if (num1 <= num5) {
            num1 += num5;
            num5 = num1 - num5;
            num1 -= num5;
        }
        if (num2 <= num3) {
            num2 += num3;
            num3 = num2 - num3;
            num2 -= num3;
        }
        if (num2 <= num4) {
            num2 += num4;
            num4 = num2 - num4;
            num2 -= num4;
        }
        if (num2 <= num5) {
            num2 += num5;
            num5 = num2 - num5;
            num2 -= num5;
        }
        if (num3 <= num4) {
            num3 += num4;
            num4 = num3 - num4;
            num3 -= num4;
        }
        if (num3 <= num5) {
            num3 += num5;
            num5 = num3 - num5;
            num3 -= num5;
        }
        if (num4 <= num5) {
            num4 += num5;
            num5 = num4 - num5;
            num4 -= num5;
        }

        System.out.print("El orden de mayor a menor es = " + " "
                + num1 + " " + num2 + " " + num3 + " " + num4 + " " + num5);
    }

}
