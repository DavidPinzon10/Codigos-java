/**
 * @author David Pinzón
 */
public class Ejercicio3 {
    public static void main(String[] args) {
      
        int TotalNumerosA = 0;
        int promedio = 0;
        int NumMayor = 0;
        int NumMenor = 0;
        int A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, I = 0, J = 0;
        
        for (int i = 1; i <= 1; i++) {

            A = (int) (0 + Math.random() *100 + 1);
            B = (int) (0 + Math.random() *100 + 1);
            C = (int) (0 + Math.random() *100 + 1);
            D = (int) (0 + Math.random() *100 + 1);
            E = (int) (0 + Math.random() *100 + 1);
            F = (int) (0 + Math.random() *100 + 1);
            G = (int) (0 + Math.random() *100 + 1);
            H = (int) (0 + Math.random() *100 + 1);
            I = (int) (0 + Math.random() *100 + 1);
            J = (int) (Math.random() *100 + 1);
            
            System.out.println("---------------------------------------------------");
            System.out.println("A = "+A);
            System.out.println("B = "+B);
            System.out.println("C = "+C);
            System.out.println("D = "+D);
            System.out.println("E = "+E);
            System.out.println("F = "+F);
            System.out.println("G = "+G);
            System.out.println("H = "+H);
            System.out.println("I = "+I);
            System.out.println("J = "+J);
            System.out.println("---------------------------------------------------");
            
            TotalNumerosA = A+B+C+D+E+F+G+H+I+J;
            
            if (A <= B && A<=C && A<=D && A<=E && A<=F && A<=G && A<=H && A<=I && A<=J) {
                A += B; B = A-B; A -= B;  A += C; B = A-C; A -= C;
                A += D; D = A-D; A -= D;  A += E; E = A-E; A -= E;
                A += F; F = A-F; A -= F;  A += G; G = A-G; A -= G;
                A += H; H = A-H; A -= H;  A += I; I = A-I; A -= I;
                A += J; J = A-J; A -= J; 
            }
            if (B <= C && B<=D && B<=E && B<=F && B<=G && B<=H && B<=I && B<=J) {
                B += C; C = B-C; B -= C;  B += D; D = B-D; B -= D;
                B += E; E = B-E; B -= E;  B += F; F = B-F; B -= F;
                B += G; G = B-G; B -= G;  B += H; H = B-H; B -= H;
                B += I; I = B-I; B -= I;  B += J; J = B-J; B -= J;
            }
            if (C <= D && C<=E && B<=F && B<=G && B<=H && B<=I && B<=J) {
                C += D; D = C-D; C -= D;  C += E; E = C-E; C -= E;
                C += F; F = C-F; C -= F;  C += G; G = C-G; C -= G;
                C += H; H = C-H; C -= H;  C += I; I = C-I; C -= I;
                C += J; J = C-J; C -= J;
            }
            if (D <= E && D<=F && D<=G && D<=H && D<=I && D<=J) {
                D += E; E = D-E; D -= E;  D += F; F = D-F; D -= F;
                D += G; G = D-G; D -= G;  D += H; H = D-H; D -= H;
                D += I; I = D-I; D -= I;  D += J; J = D-J; D -= J;
            }
            if (E <= F && E<=G && E<=H && E<=I && E<=J) {
                E += F; F = E-F; E -= F;  E += G; G = E-G; E -= G;
                E += H; H = E-H; E -= H;  E += I; I = E-I; E -= I;
                E += J; J = E-J; E -= J;
            }
            if (F <= G && F<=H && F<=I && F<=J) {
                F += G; G = F-G; F -= G;  F += H; H = F-H; F -= H;
                F += I; I = F-I; F -= I;  F += J; J = F-J; F -= J;
            }
            if (G <= H && G<=I && G<=J) {
                G += H; H = G-H; G -= H;  G += I; I = G-I; G -= I;
                G += J; J = G-J; G -= J;  
            }
            if (H <= I && H<=J ) {
                H += I; I = H-I; H -= I;  H += J; J = H-J; H -= J; 
            }
            if (I <= J) {
                I += J; J = I-J; I -= J;
            }
        }

        promedio = TotalNumerosA / 10;

        System.out.println("----------------------------------------------------------");
        System.out.println("El total es: " + TotalNumerosA);
        System.out.println("El promedio es: " + promedio);
        System.out.println("----------------------------------------------------------");
        System.out.println("ORDEN NUMEROS: El mayor es el primero y el menor el último = "
                + " "+A+" "+B+" "+C+" "+D+" "+E+" "+F+" "+G+" "+H+" "+I+" "+J);
        System.out.println("----------------------------------------------------------");
       
    }
  
}

