
package Presentacion;

import figuras.Punto2D;
import javax.swing.*;
import java.awt.*;

import static java.awt.Font.PLAIN;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class main_fig extends JFrame {

    JPanel panel;

    public main_fig(){

        initPanel();
        initPantalla();
    }
    void initPanel(){
        panel = new JPanel();
        add(panel); //Añado el panel al JFrame
        panel.setPreferredSize(new Dimension(80,80)); //Dimensiones del panel
    }
    @Override
    public void paint(Graphics g){
        super.paint(g);

        //Para poder modificar más propiedades con Graphics 2d
        Graphics2D g2d = (Graphics2D) g;

       
//Triangulo (3 lados) figura 1 (8,50)(8,4)(12,4)
        int [] triangulo_x1 = {800, 800, 1200};
        int [] triangulo_y1 = {50, 400, 400};
       
        g2d.setColor(Color.RED);
        g2d.fillPolygon (triangulo_x1, triangulo_y1, 3);
        g2d.setColor(Color.BLACK);
        g2d.drawPolygon (triangulo_x1, triangulo_y1, 3);

//Triangulo (3 lados) figura 2 (555,33)(6,6)(3,7)
        int [] triangulo_x2 = {555, 600, 300};
        int [] triangulo_y2 = {330, 600, 700};
       
        g2d.setColor(Color.BLUE);
        g2d.fillPolygon (triangulo_x2, triangulo_y2, 3);
        g2d.setColor(Color.BLACK);
        g2d.drawPolygon (triangulo_x2, triangulo_y2, 3);        
    
//CUADRADO (4 lados) figura 1 (8,8)(10,8)(8,10)(10,10)
        int [] cuadrado_x1 = {800, 1000, 800,  1000};
        int [] cuadrado_y1 = {800, 800,  1000, 1000} ;
        
        g2d.setColor(Color.YELLOW);
        g2d.fillPolygon (cuadrado_x1, cuadrado_y1, 4);
        g2d.setColor(Color.BLACK);
        g2d.drawPolygon (cuadrado_x1, cuadrado_y1, 4);      
        
//CUADRADO (4 lados) figura 2 (50,50)(4,50)(50,4)(4,4)
        int [] cuadrado_x2 = {50, 400, 50, 400};
        int [] cuadrado_y2 = {50, 50, 400, 400} ;
        
        g2d.setColor(Color.GREEN);
        g2d.fillPolygon (cuadrado_x2, cuadrado_y2, 4);
        g2d.setColor(Color.BLACK);
        g2d.drawPolygon (cuadrado_x2, cuadrado_y2, 4);        
    }

    private void initPantalla(){

        setTitle("Triangulo");
        setSize(80,80);
        setResizable(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

    }
   
    public static void main(String[] args) {
        new main_fig();
        double v1,v2,v3,v11,v22,v33,rt,vv1,vv2,vv3,vv11,vv12,vv13,rt2;
        double vc1,vc2,vc3,vc4,vc11,vc22,vc33,vc44,crt,vvc1,vvc2,vvc3,vvc4,vvc11,vvc12,vvc13,vvc14,crt2;
        int t1_11=800,t1_12=50,t1_21=800,t1_22=400,t1_31=1200,t1_32=400;
        int t2_11=555,t2_12=330,t2_21=600,t2_22=600,t2_31=300,t2_32=700;
        int c1_11=800,c1_12=800,c1_21=1000,c1_22=800,c1_31=800,c1_32=1000,c1_41=1000,c1_42=1000;
        int c2_11=50,c2_12=50,c2_21=400,c2_22=50,c2_31=50,c2_32=400,c2_41=400,c2_42=400;
        int p1=0,p2=0,p3=0,p4=0;
        int a1=0,a2=0,a3=0,a4=0;
        
       v1= (float)Math.sqrt((Math.pow((t1_11 ),2))+(Math.pow((t1_12),2)));v2= (float)Math.sqrt((Math.pow((t1_21 ),2))+(Math.pow((t1_22),2)));
       v3= (float)Math.sqrt((Math.pow((t1_31 ),2))+(Math.pow((t1_32),2))); 
       rt=(v1+v2+v3)/2; 
       a1= (int) Math.sqrt(rt*(rt-v1)*(rt-v2)*(rt-v3));
       
       vv1= (float)Math.sqrt((Math.pow((t2_11 ),2))+(Math.pow((t2_12),2)));vv2= (float)Math.sqrt((Math.pow((t2_21 ),2))+(Math.pow((t2_22),2)));
       vv3= (float)Math.sqrt((Math.pow((t2_31 ),2))+(Math.pow((t2_32),2))); 
       rt2=(vv1+vv2+vv3)/2; 
       a2= (int) Math.sqrt(rt*(rt-vv1)*(rt-vv2)*(rt-vv3));
       
       v11= (float)Math.sqrt((Math.pow((t1_11 ),2))+(Math.pow((t1_12),2)));v22= (float)Math.sqrt((Math.pow((t1_21 ),2))+(Math.pow((t1_22),2)));
       v33= (float)Math.sqrt((Math.pow((t1_31 ),2))+(Math.pow((t1_32),2))); 
       p1= (int)(v1+v2+v3);
       
       vv11= (float)Math.sqrt((Math.pow((t2_11 ),2))+(Math.pow((t2_12),2)));vv12= (float)Math.sqrt((Math.pow((t2_21 ),2))+(Math.pow((t2_22),2)));
       vv13= (float)Math.sqrt((Math.pow((t2_31 ),2))+(Math.pow((t2_32),2))); 
       p2= (int)(vv11+vv12+vv13); 
    //area y perimetro triangulos
       vc1= (float)Math.sqrt((Math.pow((c1_11 ),2))+(Math.pow((c1_12),2)));vc2= (float)Math.sqrt((Math.pow((c1_21 ),2))+(Math.pow((c1_22),2)));
       vc3= (float)Math.sqrt((Math.pow((c1_31 ),2))+(Math.pow((c1_32),2)));vc4= (float)Math.sqrt((Math.pow((c1_41 ),2))+(Math.pow((c1_42),2)));
       crt=(vc1+vc2+vc3+vc4)/2; 
       a3= (int) Math.sqrt(crt*(crt-vc1)*(crt-vc2)*(crt-vc3)*(crt-vc4));
       
       vvc1= (float)Math.sqrt((Math.pow((c2_11 ),2))+(Math.pow((c2_12),2)));vvc2= (float)Math.sqrt((Math.pow((c2_21 ),2))+(Math.pow((c2_22),2)));
       vvc3= (float)Math.sqrt((Math.pow((c2_31 ),2))+(Math.pow((c2_32),2)));vvc4= (float)Math.sqrt((Math.pow((c2_41 ),2))+(Math.pow((c1_42),2))); 
       crt2=(vc1+vc2+vc3+vc4)/2; 
       a4= (int) Math.sqrt(crt2*(crt2-vvc1)*(crt2-vvc2)*(crt2-vvc3)*(crt2-vvc4));
       
       vc11= (float)Math.sqrt((Math.pow((c1_11 ),2))+(Math.pow((t1_12),2)));vc22= (float)Math.sqrt((Math.pow((t1_21 ),2))+(Math.pow((t1_22),2)));
       vc33= (float)Math.sqrt((Math.pow((c1_31 ),2))+(Math.pow((t1_32),2)));vc44= (float)Math.sqrt((Math.pow((c1_41 ),2))+(Math.pow((c1_42),2))); 
       p3= (int)(vc11+vc22+vc33+vc44);
       
       vvc11= (float)Math.sqrt((Math.pow((c2_11 ),2))+(Math.pow((t2_12),2)));vvc12= (float)Math.sqrt((Math.pow((t2_21 ),2))+(Math.pow((t2_22),2)));
       vvc13= (float)Math.sqrt((Math.pow((c2_31 ),2))+(Math.pow((t2_32),2)));vvc14= (float)Math.sqrt((Math.pow((c1_41 ),2))+(Math.pow((c1_42),2))); 
       p4= (int)(vvc11+vvc12+vvc13+vvc14);
    //area y perimetro cuadrilateros
       
        System.out.println(".....Area Triangulo 1 = "+a1);
        System.out.println(".....Area Triangulo 2 = "+a2);
        System.out.println("Perimetro Triangulo 1 = "+p1);
        System.out.println("Perimetro Triangulo 2 = "+p2);
        System.out.println("--------------------------------------");
        System.out.println(".....Area Cuadrado 1 = "+a3);
        System.out.println(".....Area Cuadrado 2 = "+a4);
        System.out.println("Perimetro Cuadrado 1 = "+p3);
        System.out.println("Perimetro Cuadrado 2 = "+p4);
    }
}

