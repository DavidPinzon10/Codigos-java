package consencionarióproyecto;
import java.util.Scanner;

public class Venta extends Comprar{        
    float pagoInicial;
    private Venta[] vector;
    
    public Venta(){
        this.pagoInicial = 0;
    }
    public Venta(String nombreComp, String correoElec, double nroCelular, String pago, int vehiculo, float pagoInicial){
        super(nombreComp, correoElec, nroCelular, pago, vehiculo);
        this.pagoInicial = pagoInicial;
    }

    public float getPagoInicial() {
        return pagoInicial;
    }

    public void setPagoInicial(float pagoInicial) {
        this.pagoInicial = pagoInicial;
    }
    
    @Override
    public void pedirDatos() {
        int nr = 1;
        Consultar consV = new Consultar();
        Scanner Vsc = new Scanner(System.in);
        Scanner Str1 = new Scanner(System.in);
        Scanner Str2 = new Scanner(System.in);
        Scanner Str3 = new Scanner(System.in);
        vector = new Venta[1];
        
        for (int i = 0; i < nr; i++) {
            
        System.out.println("---------------------");
        System.out.println("I  DATOS PERSONALES  I");
        System.out.println("---------------------");
        System.out.println(" Nombre Completo     ");
        nombreComp = Str1.nextLine();
        System.out.println(" Correo Electonico   ");
        correoElec = Str2.nextLine();
        System.out.println(" Número de Celular   ");
        nroCelular = Vsc.nextDouble();
        System.out.println(" Método de Pago      ");
        pago = Str3.nextLine();       
        System.out.println(" Vehiculo            ");
        consV.Consulta(1);
        vehiculo = Vsc.nextInt();        
        System.out.println(" Pago Inicial        ");
        pagoInicial = Vsc.nextFloat();             
        
        vector[i]= new Venta(nombreComp, correoElec, nroCelular, pago, vehiculo, pagoInicial);
        }
    }
  /*  @Override
    public void MostrarDatos(){
        int nr = 1;
        for (int i = 0; i < nr; i++) {
            
        System.out.println("---------------------");
        System.out.println("I     SUS DATOS     I");     
        System.out.println("---------------------");
        System.out.println(" Nombre completo:    ")+vector[i].getNombreComp();
        System.out.println(" Correo electronico: ")+vector[i].getCorreoElec();
        System.out.println(" Numero celular:     ")+vector[i].getNroCelular();
        System.out.println(" Metodo pago:        ")+vector[i].getPago();
        System.out.println(" Vehículo:           ")+vector[i].getVehiculo();
        System.out.println(" Pago iniicial:      ")+vector[i].getPagoInicial();
    }
    }*/
    public void MetodoPago(){
        System.out.println(" Método de Pago      ");
    }
}
