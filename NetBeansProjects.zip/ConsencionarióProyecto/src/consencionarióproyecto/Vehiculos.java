package consencionarióproyecto;

public class Vehiculos{
    protected String nombre;
    protected String asientos;
    protected String motor;
    protected String color;    
    protected String precio;
    
    public Vehiculos(){
        this.nombre = "";
        this.asientos = "";
        this.motor = "";
        this.color = "";
        this.precio = "";
    }
    public Vehiculos(String nombre, String asientos, String motor, String color, String precio){
        this.nombre = nombre;
        this.asientos = asientos;
        this.motor = motor;
        this.color = color;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getAsientos() {
        return asientos;
    }
    public void setAsientos(String asientos) {
        this.asientos = asientos;
    }

    public String getMotor() {
        return motor;
    }
    public void setMotor(String motor) {
        this.motor = motor;
    }

    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }

    public String getPrecio() {
        return precio;
    }
    public void setPrecio(String precio) {
        this.precio = precio;
    }        
}
