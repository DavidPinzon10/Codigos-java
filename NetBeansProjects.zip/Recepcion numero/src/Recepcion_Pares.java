import java.util.Scanner;
/**
 * @author David Pinzón
 */
public class Recepcion_Pares {
    public static void main(String[] args) {
       Scanner leer = new Scanner(System.in);
       
       int numero = 0;
       int Par_1 = 2*1, Par_2 = 2*2, Par_3 = 2*3, Par_4 = 2*4, Par_5 = 2*5; 
       
        System.out.println("---------------------------------------------------------");
        System.out.println("-              Digite un numero del 1 al 5              -");
        System.out.println("---------------------------------------------------------");
        numero = leer.nextInt();
        
       
        if (numero == 1) {
            System.out.println("El numero par por la cantidad 1 es: "+Par_1);
        }
        if (numero == 2) {
            System.out.println("Los pares por la cantidad 2 es: "+Par_1+".."+Par_2);
        }
        if (numero == 3) {
            System.out.println("Los pares por la cantidad 3 es: "+Par_1+".."+Par_2+".."+Par_3);
        }
        if (numero == 4) {
            System.out.println("Los pares por la cantidad 4 es: "+Par_1+".."+Par_2+".."+Par_3+".."+Par_4);
        }
        if (numero == 5) {
            System.out.println("Los pares por la cantidad 5 es: "+Par_1+".."+Par_2+".."+Par_3+".."+Par_4+".."+Par_5);
        }
        if (numero == 6) {
            System.out.println("Error");
        }
    
        }
        }
        
    
    

