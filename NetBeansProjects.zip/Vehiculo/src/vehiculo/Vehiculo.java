package vehiculo;

import javax.swing.JOptionPane;

public class Vehiculo {

    public static void main(String[] args) {

        String[] años = {"2018", "2019", "2020", "2021", "2022"};
        int n = Integer.parseInt(JOptionPane.showInputDialog("Introduzca el número de vehículos"));
        int añoSeleccionado=0;
        String[][] vehiculo = new String[n][2];
        double[][] precio = new double[n][5];

        for (int i = 0; i < n; i++) {
            vehiculo[i][0] = JOptionPane.showInputDialog("Introduzca el nombre del vehículo " + (i + 1));
            for (int j = 0; j < 5; j++) {
                precio[i][j] = Long.parseLong(JOptionPane.showInputDialog("Introduzca el precio del " + vehiculo[i][0] + " en " + años[j]));
                while (precio[i][j] <= 0) {
                    JOptionPane.showMessageDialog(null, "Solo se permiten valores positivos");
                    precio[i][j] = Long.parseLong(JOptionPane.showInputDialog("Introduzca el precio del " + vehiculo[i][0] + " en " + años[j]));

                }
            }
        }
        ListaVehiculoPrecio(vehiculo, precio, años); //crear metodo para almacenar los datos digitados y poderlos editar
        VehiculoBarato(vehiculo, precio, años);
        Promedio(vehiculo, precio);
    }

    private static void ListaVehiculoPrecio(String[][] vehiculo, double[][] precio, String[] años) {
        String lista = "Lista de vehiculos y precios por año:\n\n";
        for (int i = 0; i < vehiculo.length; i++) {
            lista += vehiculo[i][0] + ":\n";    //ubica los vehiculos
            for (int j = 0; j < 5; j++) {
                lista += años[j] + "----- " + precio[i][j] + " Millones de pesos \n";  //le agrega el año y precio a la lista  
            }                                                                          //precio[i][j]: en la i recorre el vehiculo y en j el año

            lista += "\n";  //el += es para concatenar los strings e ir acomodando los vehiculos con sus precios
        }
        JOptionPane.showMessageDialog(null, lista);
    }

    private static void VehiculoBarato(String[][] vehiculo, double[][] precio, String[] años) {
        String resultado = "Vehiculo más barato por año:\n\n";
        for (int j = 0; j < 5; j++) {
            double precioMinimo = Long.MAX_VALUE;//El max value es para poder evaluar cualquier precio que el usuario digite sin necesitad de poner un maximo como 5000000000000000 por ejemplo
            int carroMasBarato = -1;  //es un minimo para saber el carro más barato y poderlo evaluar con los demas precios
            for (int i = 0; i < precio.length; i++) {
                if (precio[i][j] < precioMinimo) {
                    precioMinimo = precio[i][j];
                    carroMasBarato = i;
                }
            }
            resultado += años[j] + ": " + vehiculo[carroMasBarato][0] + " - Con un valor de (" + precioMinimo + ") millones de pesos \n";
        }
        JOptionPane.showMessageDialog(null, resultado);

    }

private static double Promedio(String[][] vehiculo, double[][] precio) {
  int año = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un año entre 2018-2022 para calcular el promedio:"));
  double suma = 0;
  int contador = 0;
  switch (año) {
    case 2018:
      for (int i = 0; i < vehiculo.length; i++) {
        if (precio[i][0] >= 30 && precio[i][0] <= 50) {
          suma += precio[i][0];
          contador++;
        }
      }
      break;
    case 2019:
      for (int i = 0; i < vehiculo.length; i++) {
        if (precio[i][1] >= 30 && precio[i][1] <= 50) {
          suma += precio[i][1];
          contador++;
        }
      }
      break;
    case 2020:
      for (int i = 0; i < vehiculo.length; i++) {
        if (precio[i][2] >= 30 && precio[i][2] <= 50) {
          suma += precio[i][2];
          contador++;
        }
      }
      break;
    case 2021:
      for (int i = 0; i < vehiculo.length; i++) {
        if (precio[i][3] >= 30 && precio[i][3] <= 50) {
          suma += precio[i][3];
          contador++;
        }
      }
      break;
    case 2022:
      for (int i = 0; i < vehiculo.length; i++) {
        if (precio[i][4] >= 30 && precio[i][4] <= 50) {
          suma += precio[i][4];
          contador++;
        }
      }
      break;
    default:
      JOptionPane.showMessageDialog(null, "Año no disponible");
      return 0;
  }
  if (contador > 0) {
    double prom= suma / contador;
    JOptionPane.showMessageDialog(null, "El promedio es el siguiente: ("+prom+") Millones de pesos");  
    return prom;
  } else {
    JOptionPane.showMessageDialog(null, "No hay autos que cuesten entre 30 y 50 millones para el año seleccionado.");
    return 0;
  }
}
}