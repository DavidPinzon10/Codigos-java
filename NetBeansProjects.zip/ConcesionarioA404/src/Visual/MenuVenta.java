
package Visual;

import concesionarioa404.DataVehiculo;
import concesionarioa404.Fabrica;
import concesionarioa404.IControladorVehiculos;
import concesionarioa404.DataVehiculo;
import concesionarioa404.IControladorCliente;
import javax.swing.JOptionPane;

public class MenuVenta extends javax.swing.JInternalFrame {
    private IControladorVehiculos ICU;
    private IControladorCliente ICC;

    
    public MenuVenta() {
        initComponents();
        this.setSize(270, 420);
        
        //Inicialización
        Fabrica fabrica = Fabrica.getInstance();
        ICU = fabrica.getIControladorVehiculos();
        ICC = fabrica.getIControladorCliente();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        TextFieldVenCod = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        LabelMarca = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        LabelNombre = new javax.swing.JLabel();
        LabelTipo = new javax.swing.JLabel();
        LabelPrecio = new javax.swing.JLabel();
        TxtVenNom = new javax.swing.JTextField();
        TxtVenApe = new javax.swing.JTextField();
        TxtVenCC = new javax.swing.JTextField();
        TxtVenTar = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        TxtVenTel = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();

        setTitle("Menú de Ventas");
        setToolTipText("");

        jLabel1.setText("Código del Vehiculo:");

        jButton1.setText("Verificar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Marca:");

        LabelMarca.setText("_ _ _ _ _ _ _ _ _ _");

        jLabel5.setText("Nombre:");

        jLabel7.setText("Tipo:");

        jLabel8.setText("Precio:");

        jLabel4.setText("Nombre:");

        jLabel6.setText("Apellido:");

        jLabel9.setText("C.C.");

        jLabel10.setText("Tarjeta C.");

        LabelNombre.setText("_ _ _ _ _ _ _ _ _ _");

        LabelTipo.setText("_ _ _ _ _ _ _ _ _ _");

        LabelPrecio.setText("_ _ _ _ _ _ _ _ _ _");

        TxtVenCC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtVenCCActionPerformed(evt);
            }
        });

        jLabel11.setText("No. Tel:");

        jButton2.setText("Comprar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldVenCod))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4)
                            .addComponent(jLabel11))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TxtVenTel)
                            .addComponent(TxtVenNom)
                            .addComponent(TxtVenApe)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LabelNombre)
                                    .addComponent(LabelTipo)
                                    .addComponent(LabelPrecio)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(18, 18, 18)
                                .addComponent(LabelMarca))
                            .addComponent(jLabel3))
                        .addGap(0, 175, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TxtVenTar)
                            .addComponent(TxtVenCC)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(TextFieldVenCod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(LabelMarca))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(LabelNombre))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(LabelTipo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(LabelPrecio))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(TxtVenNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(TxtVenApe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(TxtVenTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(jLabel9))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TxtVenCC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(TxtVenTar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (this.TextFieldVenCod.getText().equals("")){
            this.TextFieldVenCod.setText("Ingresar Codigo");
        }
        else{
            DataVehiculo dv = ICU.verInfoVehiculo(this.TextFieldVenCod.getText());
            this.LabelMarca.setText(dv.getMarca());
            this.LabelNombre.setText(dv.getNombre());
            this.LabelTipo.setText(dv.getTipo());
            this.LabelPrecio.setText(dv.getPrecio());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TxtVenCCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtVenCCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtVenCCActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // Datos vehiculo
        String CodigoV = this.TextFieldVenCod.getText();
        String MarcaV = this.LabelMarca.getText();
        String NombreV = this.LabelNombre.getText();
        String TipoV = this.LabelTipo.getText();
        String PrecioV = this.LabelPrecio.getText();
        
        // Obtenemos los datos escritos por el usuario
        String NombreC = this.TxtVenNom.getText();
        String ApellidoC = this.TxtVenApe.getText();
        String NumeroC = this.TxtVenTel.getText();
        String CedulaC = this.TxtVenCC.getText();
        String TarjetaC = this.TxtVenTar.getText();
        
        // Guardo los datos
        ICC.registrarCliente(NombreC, ApellidoC, NumeroC, CedulaC, TarjetaC);                        
        
        //Ver en la consola
        System.out.println(NombreC+" --- "+ApellidoC+" --- "+NumeroC+" --- "+CedulaC+" --- "+TarjetaC);
        
        // Limpiamos 
        this.TxtVenNom.setText("");
        this.TxtVenApe.setText("");
        this.TxtVenTel.setText("");
        this.TxtVenCC.setText("");
        this.TxtVenTar.setText("");
        this.setVisible(false);
        
        //Muestro éxito de la operación        
        JOptionPane.showMessageDialog(this, "La compra se a realizado exitosamente"
                                       + "\n***************************************"
                                       + "\n El vehiculo "+NombreV+" ("+TipoV+") "
                                       + "\n De la marca "+MarcaV
                                       + "\n Codigo: "+CodigoV
                                       + "\n A sido comprado por "+NombreC
                                       + "\n***************************************"
                                       + "\n Con el precio "+PrecioV);
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelMarca;
    private javax.swing.JLabel LabelNombre;
    private javax.swing.JLabel LabelPrecio;
    private javax.swing.JLabel LabelTipo;
    private javax.swing.JTextField TextFieldVenCod;
    private javax.swing.JTextField TxtVenApe;
    private javax.swing.JTextField TxtVenCC;
    private javax.swing.JTextField TxtVenNom;
    private javax.swing.JTextField TxtVenTar;
    private javax.swing.JTextField TxtVenTel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
