package figuras;

import javax.swing.*;
import java.awt.*;

import static java.awt.Font.PLAIN;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class dibujoC extends JFrame {

    JPanel panel;

    public dibujoC(){

        initPanel();
        initPantalla();
    }
    void initPanel(){
        panel = new JPanel();
        add(panel); //Añado el panel al JFrame
        panel.setPreferredSize(new Dimension(80,80)); //Dimensiones del panel
    }
    @Override
    public void paint(Graphics g){
        super.paint(g);
        //Para poder modificar más propiedades con Graphics 2d
        Graphics2D g2d = (Graphics2D) g;

        //CUADRADO
        int [] cuadrado_x1111 = {600, 300, 300, 1200};
        int [] cuadrado_y1111 = {800, 500, 200, 800} ;
        g2d.setColor(Color.BLUE);
      
        g2d.fillPolygon (cuadrado_x1111, cuadrado_y1111, 4);
        g2d.setColor(Color.BLACK);
        g2d.drawPolygon (cuadrado_x1111, cuadrado_y1111, 4);
    }
    private void initPantalla(){
        setTitle("Cuadrado");
        setSize(80,80);
        setResizable(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new dibujoC();
    }
}