 
package universidadpoo;
import java.util.Scanner;

public class EstudiantesPOO {
    Scanner leer = new Scanner(System.in);
    
    private String nombre;
    private String apellido;
    private int edad;
    private double nota;
    private double Ndocumento;

    //valor cero para definir después-
    public EstudiantesPOO (){
        this.nombre = "";
        this.apellido = "";
        this.Ndocumento = 0;
        this.edad = 0;
        this.nota = 0;
    }
    
    //constructor definiendo la variable
    public EstudiantesPOO(String nombre, String apellido, int edad, double nota, double Ndocumento) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.nota = nota;
        this.Ndocumento = Ndocumento;
    }

    public String getNombre() {
        String nombre1, nombre2, nombre3, nombre4, nombre5;
        System.out.println("Digiten su nombre en orden por favor :");
        nombre1 = leer.nextLine(); nombre2 = leer.nextLine();
        nombre3 = leer.nextLine(); nombre4 = leer.nextLine();
        nombre5 = leer.nextLine();
        
        System.out.println(nombre1+"  ");
        System.out.println(nombre2+"  ");
        System.out.println(nombre3+"  ");
        System.out.println(nombre4+"  ");
        System.out.println(nombre5+"  ");
        
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        String ape1, ape2, ape3, ape4, ape5;
        System.out.println("Digiten su apellido en orden por favor :");
        ape1 = leer.nextLine(); ape2 = leer.nextLine();
        ape3 = leer.nextLine(); ape4 = leer.nextLine();
        ape5 = leer.nextLine();
        
        System.out.println(ape1+"  ");
        System.out.println(ape2+"  ");
        System.out.println(ape3+"  ");
        System.out.println(ape4+"  ");
        System.out.println(ape5+"  ");
        
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        int edad1, edad2, edad3, edad4, edad5;
        
        System.out.println("Digite su edad en orden por favor :");
        edad1 = leer.nextInt(); edad2 = leer.nextInt();
        edad3 = leer.nextInt(); edad4 = leer.nextInt();
        edad5 = leer.nextInt();
        
        System.out.println(edad1+"  ");
        System.out.println(edad2+"  ");
        System.out.println(edad3+"  ");
        System.out.println(edad4+"  ");
        System.out.println(edad5+"  ");
        
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public double getNdocumento() {
        double doc1, doc2, doc3, doc4, doc5;
        
        System.out.println("Digite el numero de documento en orden :");
        doc1 = leer.nextDouble(); doc2 = leer.nextDouble();
        doc3 = leer.nextDouble(); doc4 = leer.nextDouble();
        doc5 = leer.nextDouble();
        
        System.out.println(doc1+"");
        System.out.println(doc2+"");
        System.out.println(doc3+"");
        System.out.println(doc4+"");
        System.out.println(doc5+"");
      
        return Ndocumento;
    }

    public void setNdocumento(double Ndocumento) {
        this.Ndocumento = Ndocumento;
    }
    
    
    
}
