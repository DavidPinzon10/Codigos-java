import java.util.Scanner;
/**
 * @author David Pinzon
 */
public class Ejercicio5M {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        double mediaP = 0, mediaN = 0;
        int pos = 0, neg = 0;
        int n1 = 0, n2 = 0, n3 = 0, n4 = 0, n5 = 0, n6 = 0, n7 = 0,
            n8 = 0, n9 = 0;
        int Matriz[][] = new int [3][3];
        
        for (int i = 0; i < Matriz.length; i++) {
        for (int j = 0; j < Matriz.length; j++) {
        
        System.out.println("Digite los elementos [" + i + "," + j + "]");
        Matriz[i][j] = leer.nextInt(); 
} 
}
        for (int i = 0; i < Matriz.length; i++) {
        for (int j = 0; j < Matriz.length; j++) {
               
        System.out.print(" "+Matriz[i][j]);   
} 
        System.out.println("");
}
        System.out.println("¿Cuántos numeros positivos hay?");
        pos = leer.nextInt();
        System.out.println("¿Cuántos numeros negativos hay?");
        neg = leer.nextInt();
        System.out.println("-------------------------------------");
        System.out.println("Cantidad positivos = "+pos);
        System.out.println("Cantidad negativos = "+neg);
        System.out.println("-------------------------------------");
        System.out.println("¿Cuáles son los #Positivos?");
        n1 = leer.nextInt(); n2 = leer.nextInt(); n3 = leer.nextInt();
        n4 = leer.nextInt(); n5 = leer.nextInt(); n6 = leer.nextInt();
        System.out.println("¿Cuáles son los #Negativos?");
        n7 = leer.nextInt(); n8 = leer.nextInt(); n9 = leer.nextInt();
        
        System.out.println("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
        mediaP = (n1+n2+n3+n4+n5+n6)/6;
        mediaN = (n7+n8+n9)/3;
        
        System.out.println("La media de los positivos es = "+mediaP);
        System.out.println("La media de los negativos es = "+mediaN);
}
}