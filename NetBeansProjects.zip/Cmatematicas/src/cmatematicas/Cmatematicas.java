package cmatematicas;
import java.util.Scanner;
/**
 * @author David pinzon
 */
public class Cmatematicas {
Scanner leer = new Scanner(System.in);

double corte1, corte2, corte3, definitivaT;
double definitiva1, definitiva2, definitiva3;

double corte11, corte22, corte33, definitivaT2;
double definitiva11, definitiva22, definitiva33;

public void Notas (){
    System.out.println("INGRESE SUS NOTAS");
    System.out.println("------------------------------------------------");
    System.out.println("NOTA CORTE 1");
    corte1 = leer.nextDouble();
    System.out.println("NOTA CORTE 2");
    corte2 = leer.nextDouble();
    System.out.println("NOTA CORTE 3");
    corte3 = leer.nextDouble();
}
public void porcentajes (){
    definitiva1 = corte1 * 0.3;
    definitiva2 = corte2 * 0.3;
    definitiva3 = corte3 * 0.4;
    definitivaT = definitiva1 + definitiva2 + definitiva3;
    
}
public void resultado (){
    System.out.println("Corte 1 = "+corte1);    
    System.out.println("Corte 2 = "+corte2);
    System.out.println("Corte 3 = "+corte3);
    System.out.println("Definitiva 1 = "+definitiva1);
    System.out.println("Definitiva 2 = "+definitiva2);
    System.out.println("Definitiva 3 = "+definitiva3);
    System.out.println("----------------------------------------------");
    System.out.println("Definitiva = "+definitivaT);
}
public void apruebaOno (){
    if (definitivaT >= 3 && definitivaT <= 5) {
        System.out.println("Aprobó, felicidades.");
    }
    else{
        if (definitivaT > 0 && definitivaT < 3) {
            definitivaT = (definitiva1 + definitiva2 + definitiva3)*0.1; 
        } else {
            if (definitivaT > 0 && definitivaT < 3) {
            System.out.println("Perdió, siga intentando");
            }
        else
            System.out.println("Error en sus notas, vuelva a ingresar");
        } 
    }
}
public void Notas2 (){
    System.out.println("INGRESE SUS NOTAS");
    System.out.println("------------------------------------------------");
    System.out.println("NOTA CORTE 1");
    corte11 = leer.nextDouble();
    System.out.println("NOTA CORTE 2");
    corte22 = leer.nextDouble();
    System.out.println("NOTA CORTE 3");
    corte33 = leer.nextDouble();
}
public void porcentajes2 (){
    definitiva11 = corte11 * 0.3;
    definitiva22 = corte22 * 0.3;
    definitiva33 = corte33 * 0.4;
    definitivaT2 = definitiva11 + definitiva22 + definitiva33;
    
}
public void resultado2 (){
    System.out.println("Corte 1 = "+corte11);    
    System.out.println("Corte 2 = "+corte22);
    System.out.println("Corte 3 = "+corte33);
    System.out.println("Definitiva 1 = "+definitiva11);
    System.out.println("Definitiva 2 = "+definitiva22);
    System.out.println("Definitiva 3 = "+definitiva33);
    System.out.println("----------------------------------------------");
    System.out.println("Definitiva = "+definitivaT2);
}
public void apruebaOnoo (){
    if (definitivaT2 >= 3 && definitivaT2 <= 5) {
        System.out.println("Aprobó, felicidades.");
    }
    else{
        if (definitivaT2 > 0 && definitivaT2 < 3) {
            definitivaT2 = (definitiva11 + definitiva22 + definitiva33)*0.1; 
        } else {
            if (definitivaT2 > 0 && definitivaT2 < 3) {
            System.out.println("Perdió, siga intentando");
            }
        else
            System.out.println("Error en sus notas, vuelva a ingresar");
        } 
    }
}
public void promedio (){
    if (definitivaT >= 3 && definitivaT2 >= 3) {
        System.out.println("Promedio de aprobacion es 100%");
        System.out.println("TODOS APROBARON");
    }else{
        if (definitivaT >= 3 && definitivaT2 < 3) {
            System.out.println("El promedio de aprobacion es 50%");
            System.out.println("LA MITAD APROBO");
        } else{
            if (definitivaT < 3 && definitivaT2 < 3) {
                System.out.println("El promedio de aprobacion es 0%");
                System.out.println("NADIE APROBÓ");
            }
        }
    }
    
}   

    public static void main(String[] args) {
     Cmatematicas notasD = new Cmatematicas (); 
     notasD.Notas();
     notasD.porcentajes();
     notasD.resultado();
     System.out.println("---------------------------------");
     notasD.apruebaOno();
     System.out.println("---------------------------------");
     notasD.Notas2();
     notasD.porcentajes2();
     notasD.resultado2();
     notasD.apruebaOnoo();
     System.out.println("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
     notasD.promedio();
    }
}
