
package concesionarioa404;

public class Cliente {
    private String nombre;
    private String apellido;
    private String numero;
    private String cedula;
    private String tarjeta;
    
    public Cliente(String nom, String ape, String num, String ced, String tar) {
        this.nombre = nom;
        this.apellido = ape;
        this.numero = num;
        this.cedula = ced;
        this.tarjeta = tar;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNumero() {
        return numero;
    }
    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCedula() {
        return cedula;
    }
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getTarjeta() {
        return tarjeta;
    }
    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }
    
    
}
