
package clima;

import javax.swing.JOptionPane;


public class Clima {

    public Clima() {
        int n = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el número de días a conocer:"));
        String[] dias = new String[n];
        int[] temperaturasMax = new int[n];
        int[] temperaturasMin = new int[n];

        for (int i = 0; i < n; i++) {
            dias[i] = JOptionPane.showInputDialog(null, "Ingrese el nombre del día " + (i + 1) + ":");
            temperaturasMax[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la temperatura máxima del día " + dias[i] + ":"));
            while (temperaturasMax[i] < -40 || temperaturasMax[i] > 40) {
                temperaturasMax[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese una temperatura válida (-40 a 40 grados) para la máxima del día " + dias[i] + ":"));
            }
            temperaturasMin[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la temperatura mínima del día " + dias[i] + ":"));
            while (temperaturasMin[i] < -40 || temperaturasMin[i] > 40) {
                temperaturasMin[i] = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese una temperatura válida (-40 a 40 grados) para la mínima del día " + dias[i] + ":"));
            }
        }

        JOptionPane.showMessageDialog(null, "Días con temperatura máxima entre 15 y 20 grados:");
        for (int i = 0; i < n; i++) {
            if (temperaturasMax[i] >= 15 && temperaturasMax[i] <= 20) {
                JOptionPane.showMessageDialog(null, dias[i] + ": " + temperaturasMax[i] + " grados (máxima)");
            }
        }

        JOptionPane.showMessageDialog(null, "Días con temperatura mínima por debajo de 0 grados:");
        for (int i = 0; i < n; i++) {
            if (temperaturasMin[i] < 0) {
                JOptionPane.showMessageDialog(null, dias[i] + ": " + temperaturasMin[i] + " grados (mínima)");
            }
        }

        double mediaMax = calcularMedia(temperaturasMax);
        double mediaMin = calcularMedia(temperaturasMin);
        JOptionPane.showMessageDialog(null, "Media de temperaturas máximas: " + mediaMax);
        JOptionPane.showMessageDialog(null, "Media de temperaturas mínimas: " + mediaMin);

        JOptionPane.showMessageDialog(null, "Listado de temperaturas:");
        for (int i = 0; i < n; i++) {
            JOptionPane.showMessageDialog(null, dias[i] + ": " + temperaturasMax[i] + " grados (máxima) / " + temperaturasMin[i] + " grados (mínima)");
        }
    }
    public static double calcularMedia(int[] temperaturas) {
        int suma = 0;
        for (int i = 0; i < temperaturas.length; i++) {
            suma += temperaturas[i];
        }
        return (double) suma / temperaturas.length;
    }
    
    public static void main(String[] args) {
    Clima estacion = new Clima();
        
    }
    
}

