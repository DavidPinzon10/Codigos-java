import java.util.Scanner;
/*
 * @author David Pinzon
 */
public class MatrizMxN {
    public static void main(String[] args) {
    Scanner leer = new Scanner(System.in);
    
        int num1 = 0, num2 = 0, num3 = 0;
        int fila = 0;
        int producto = 0;

        int Matriz[][] = new int[3][3];
        System.out.println("Filas   Matriz");
        String filas[] ={"1...  ",
                         "2...  ",
                         "3...  "};
        
        for (int i = 0; i < Matriz.length; i++) {
            for (int j = 0; j < Matriz[0].length; j++) {
               
                Matriz[i][j] = (int) (Math.random()*10);
            }
        }
        for (int i = 0; i < Matriz.length; i++) {
            System.out.print(filas[i]+" ");
            for (int j = 0; j < Matriz[0].length; j++) {
              
                //Print sin ln para que no haya salto linea
                System.out.print(" " + Matriz[i][j]);
            }
            System.out.println("");
        }
        System.out.println("Seleccione una fila");
        fila = leer.nextInt();

        System.out.println("Digite los numeros de esa fila ");
        num1 = leer.nextInt();
        num2 = leer.nextInt();
        num3 = leer.nextInt();
         
        producto = num1*num2*num3;
        
        System.out.println("El producto es = "+producto);

    }
}
