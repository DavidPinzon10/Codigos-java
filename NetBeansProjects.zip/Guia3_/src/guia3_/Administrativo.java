/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia3_;

import javax.swing.JOptionPane;

/**
 *
 * @author userr
 */
public class Administrativo extends Persona {
    protected int salario;
    private Administrativo[] lista;
    
    public Administrativo(int numID,  String nombres, String apellidos, int edad,  String direccion, int salario, String nombreU, String direccionU) {
        super(numID, nombres, apellidos, edad, direccion, nombreU, direccionU);
        this.salario = salario;
    }

    
    public Administrativo(){
        this.salario = 0;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }


    public void InsertarDatos() {
      lista = new Administrativo[1];
      
      for (int i = 0; i < 1; i++) {
        
       numID = Integer.parseInt(JOptionPane.showInputDialog("Digite el numero de documento del coordinador: "));
       getNumID();
       nombres = JOptionPane.showInputDialog("Digite los nombres del coordinador: ");
       getNombres();
       apellidos = JOptionPane.showInputDialog("Digite los apellidos del coordinador: ");
       getApellidos();
       edad = Integer.parseInt(JOptionPane.showInputDialog("Digite la edad del coordinador: "));
       getEdad();
       direccion = JOptionPane.showInputDialog("Digite la dirección del coordinador: ");
       getDireccionU();
       salario = Integer.parseInt(JOptionPane.showInputDialog("Digite el salario del coordinador: "));
       getSalario();
       nombreU = JOptionPane.showInputDialog("Digite la universidad de la que es el coordinador: ");
       getNombreU();
       direccionU = JOptionPane.showInputDialog("Digite la direccion de la universidad del coordinador: ");
       getDireccionU();
               
                       
      
       lista[i] = new Administrativo(numID, nombres, apellidos, edad, direccion, salario, nombreU, direccionU); 
      
      }
      }
    @Override
    public void mostrarDatos(){
        String registrados;
        registrados = "-Nro.Documento    - Nombres    - Apellidos    - Edad    - Direccion Coordinador -    Salario -   Universidad -   Dirección Universidad\n";
        for (int i = 0; i < 1; i++) {
        registrados = registrados + lista[i].getNumID()+"  -  "+lista[i].getNombres()+"  -  "+lista[i].getApellidos()+"  -  "+lista[i].getEdad()+"  -  "+lista[i].getDireccion()+"  -  "+
                     lista[i].getSalario()+ "  -  " +lista[i].getNombreU()+"  -  "+lista[i].getDireccionU()+"\n";      
       }
    JOptionPane.showMessageDialog(null, registrados,
            "Coordinadores Registrados", JOptionPane.INFORMATION_MESSAGE);  
       }
    
}
