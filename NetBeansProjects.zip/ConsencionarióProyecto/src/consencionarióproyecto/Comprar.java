package consencionarióproyecto;
 import java.util.Scanner;

public class Comprar {
    
    protected String nombreComp;
    protected String correoElec;
    protected double nroCelular;
    protected String pago;
    protected int vehiculo;
    
    public Comprar(){
        Scanner Csc = new Scanner(System.in);
        this.nombreComp = "";
        this.correoElec = "";
        this.nroCelular = 0;
        this.pago = "";
        this.vehiculo = 0;
    }
    public Comprar(String nombreComp, String correoElec, double nroCelular, String pago, int vehiculo){
        Scanner Csc = new Scanner(System.in);
        this.nombreComp = nombreComp;
        this.correoElec = correoElec;
        this.nroCelular = nroCelular;
        this.pago = pago;
        this.vehiculo = vehiculo;
    }

    public String getNombreComp() {
        Scanner Csc = new Scanner(System.in);
        return nombreComp;
    }

    public void setNombreComp(String nombreComp) {
        Scanner Csc = new Scanner(System.in);
        this.nombreComp = nombreComp;
    }

    public String getCorreoElec() {
        Scanner Csc = new Scanner(System.in);
        return correoElec;
    }

    public void setCorreoElec(String correoElec) {
        Scanner Csc = new Scanner(System.in);
        this.correoElec = correoElec;
    }

    public double getNroCelular() {
        Scanner Csc = new Scanner(System.in);
        return nroCelular;
    }

    public void setNroCelular(double nroCelular) {
        Scanner Csc = new Scanner(System.in);
        this.nroCelular = nroCelular;
    }
    
    public String getPago() {
        Scanner Csc = new Scanner(System.in);
        return pago;
    }

    public void setPago(String pago) {
        Scanner Csc = new Scanner(System.in);
        this.pago = pago;
    }

    public int getVehiculo() {
        Scanner Csc = new Scanner(System.in);
        return vehiculo;
    }

    public void setVehiculo(int vehiculo) {
        Scanner Csc = new Scanner(System.in);
        this.vehiculo = vehiculo;
    }
    
    public void pedirDatos() {
        System.out.println("Pidiendo los datos");
    }
    public void MostrarDatos(){
        System.out.println("Mostrando los datos");
    }
}
