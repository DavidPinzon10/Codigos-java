
package escuela;
public class estudiantes {
    public static void main(String[] args) {

  String horario;
  String trasp;
    private String horario;

public void estudiantes(  int id, String nombre, int edad, String direción, int telefono){
    System.out.println("\nID: "+id);
    System.out.println("Nombre: "+nombre);
    System.out.println("Edad: "+edad);
    System.out.println("Direccion: "+direción);
    System.out.println("Telefono: "+telefono);

}
public String Horario(int a,String horario){
        
     this.horario=horario+"\tUsuario: Estudiante";
     return horario;
    }
public String Trasporte (int a,String trasp ){ 
        this.trasp=trasp+"\tUsuario: tEstudiante";
        return this.trasp;
    }   

    void Imprimir(int i, String jose_Daniel_Benjumea_Arzuaga, int i0, String ak_7_46, int i1, int i2, String $1000000) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
