
/**
 * @author David Pinzón
 */
public class Pares_Impares {

    public static void main(String[] args) {

        int numeros_Pares = 0;
        int numeros_Impares = 1;

        System.out.println("Numeros pares entre 1 y 10");
        System.out.println("--------------------------------------------------------");

        while (numeros_Pares <= 10) {
            System.out.println("El numero par es: " + numeros_Pares);
            numeros_Pares = numeros_Pares + 2;

            System.out.println("--------------------------------------------------------");

            while (numeros_Impares <= 10) {
                System.out.println("El numero impar es: " + numeros_Impares);
                numeros_Impares = numeros_Impares + 2;
                break;

            }

        }
    }

}
