
package guia3_;


import java.util.Hashtable;

/**
 *
 * @author userr
 */
public class Persona extends Universidad{
   
    protected int numID;

    protected String nombres;

    protected String apellidos;
    
    protected int edad;

    protected String direccion;
    
    private Persona[] lista;

    
    public Persona(int numID, String nombres, String apellidos, int edad, String direccion, String nombreU, String direccionU) {
        super(nombreU, direccionU);
        this.numID = numID;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
        this.direccion = direccion;

    }

    public Persona() {
        this.numID = 0;
        this.nombres = "";
        this.apellidos = "";
        this.edad = 0;
        this.direccion = "";
    }

    public int getNumID() {
        return numID;
    }

    public String getNombres() {
        return nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setNumID(int numID) {
        this.numID = numID;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public void mostrarDatos() {
       lista = new Persona[1];
        for (int i = 0; i < 3; i++) {               
            System.out.println(lista[i].getNumID()+""+lista[i].getNombres()+""+lista[i].getApellidos()+""+lista[i].getEdad()+""+lista[i].getDireccion());
    }
}
}