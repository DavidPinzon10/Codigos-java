package buseta;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Buseta {

    public Buseta() {
       
        String buses = JOptionPane.showInputDialog("Ingrese la cantidad de busetas:");
        int cantidadBusetas = Integer.parseInt(buses);

        // matriz para almacenar las ventas de cada buseta por día de la semana
        int[][] ventasBusetas = new int[cantidadBusetas][7];


        for (int i = 0; i < cantidadBusetas; i++) {
            for (int j = 0; j < 7; j++) {
                buses = JOptionPane.showInputDialog("Ingrese las ventas de la buseta " + (i + 1) + " para el día " + (j + 1) + ":");
                int cantidadVentas = Integer.parseInt(buses);
                ventasBusetas[i][j] = cantidadVentas;
            }
        }

        // Mostrar las ventas de cada buseta por día de la semana
        String mensaje = "";
        for (int i = 0; i < cantidadBusetas; i++) {
            mensaje += "Buseta " + (i + 1) + ": ";
            for (int j = 0; j < 7; j++) {
                mensaje += ventasBusetas[i][j] + " ";
            }
            mensaje += "\n";
        }
        JOptionPane.showMessageDialog(null, mensaje);
    }

    public static void main(String[] args) {
     Buseta bus = new Buseta();
    }
}
