package EjPolimorfo;
import java.util.Scanner;

public class Estudiante extends Persona {

    int codigo;
    float NotaFinal;
    int edad;
    private Estudiante[] matriz;
   
    @Override
    public void consultarInfoPersonal() {
    }
    
    public Estudiante(String nombres, String apellidos, int NroID, int tipoID, String direccion, float NotaFinal) {
        super(NroID, tipoID, nombres, apellidos, direccion);
        this.codigo = codigo;
        this.NotaFinal = NotaFinal;
        this.edad = edad;
    }
        public Estudiante() {
        this.codigo = 0;
        this.NotaFinal = 0;
        this.edad = 0;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
   

    public float getNotaFinal(){
       return NotaFinal;
    }

    public void setNotaFinal(float NotaFinal) {
        this.NotaFinal = NotaFinal;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    
    public void InsertarDatos(){
        Scanner leer = new Scanner(System.in);
        int Nestud = 0;
        System.out.println("Cuantos estudiantes desea ingresar");
        Nestud = leer.nextInt();
        
        matriz = new Estudiante [Nestud];
        
        for (int i = 0; i < Nestud; i++) {
            
        System.out.println("Digite su nombre");
        this.setNombres(nombres);
        System.out.println("Digite su apellido");
        this.setApellidos(apellidos);
        System.out.println("Digite su edad");
        this.setEdad(edad);
        System.out.println("Digite su codigo");
        this.setCodigo(codigo);
        System.out.println("Digite su direccion");
        this.setDireccion(direccion);
        System.out.println("Digite su nota final");
        this.setNotaFinal(NotaFinal);
        System.out.println("---------------------------------------");
        
        matriz[i] =new Estudiante (nombres, apellidos, edad, codigo, direccion, NotaFinal);
        }
    }
    
    public void MostrarDatos(){
        Scanner leer = new Scanner(System.in);
        int Nestud = 0;
        System.out.println("Cuantos estudiantes fueron ingresados:");
        Nestud = leer.nextInt();
        for (int i = 0; i < Nestud; i++) {
            
        System.out.println("Nombre:      "+matriz[i].getNombres());
        System.out.println("Apellido:    "+matriz[i].getApellidos());
        System.out.println("Edad:        "+matriz[i].getEdad());
        System.out.println("Codigo :     "+matriz[i].getCodigo());
        System.out.println("Dirección:   "+matriz[i].getDireccion());
        System.out.println("Nota Final:  "+matriz[i].getNotaFinal());
        System.out.println("-------------");
        }
    }
}
