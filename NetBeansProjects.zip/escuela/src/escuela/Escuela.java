package escuela;
/**
 * @author David Pinzon
 */
public class Escuela {

     public static void main2(String[] args) {    
         
    estudiantes es1 = new estudiantes (); 
         es1.Imprimir(12345678,"Jose Daniel Benjumea Arzuaga", 17, "AK 7- 46",318289347,3,"$1´000.000");
         System.out.println("Horario es: "+es1.Horario(1,"Lunes a viernes de 9:am - 4:pm"));
         System.out.println("Traspote es: "+es1.Trasporte(1,"Bus escolar"));
         
    estudiantes es2 = new estudiantes ();   
         es2.Imprimir(18291283,"Alfonso Hernandez Hernadez", 15, "cl 7- 26",323828,3,"$500.000");
         System.out.println("Horario es: "+es2.Horario(1,"Lunes a viernes de 9:am - 4:pm"));
         System.out.println("Traspote es: "+es2.Trasporte(1,"Carro particular")); 
         
    estudiantes es3 = new estudiantes ();   
         es2.Imprimir(3902112,"Santago Jose Hernandez Rodrigez", 18, "av 6- 102",318289347,3,"$1´000.000");
         System.out.println("Horario es: "+es3.Horario(1,"Lunes a viernes de 9:am - 4:pm"));
         System.out.println("Traspote es: "+es3.Trasporte(1,"Bus escolar"));  
         
    estudiantes es4 = new estudiantes ();   
         es4.Imprimir(1293237,"Juan Estrada Campo", 16, "AK 10- 89",34984092,3,"$1´000.000");
         System.out.println("Horario es: "+es4.Horario(1,"Lunes a viernes de 9:am - 4:pm"));
         System.out.println("Traspote es: "+es4.Trasporte(1,"Bus escolar"));
         
    estudiantes es5 = new estudiantes ();  
         es5.Imprimir(83912831,"Samuel Andres Perz Rodrigez ", 17, "cr 68-cl 90-12",318289347,3,"$1´000.000");
         System.out.println("Horario es: "+es5.Horario(1,"Lunes a viernes de 9:am - 4:pm"));
         System.out.println("Traspote es: "+es5.Trasporte(1,"Bus esclar"));   
         
    administracion ad1=new administracion();
         ad1.Imprimir(19129081, "Hector Rodrigez Peña", 33, "Av 32- cl 22#12", 3212991, "Cuepo docente", "Indefinido");
         System.out.println("Horaio es: "+ad1.Horario(2,"Lunes a sabado 7:00-5:00"));
         System.out.println("Trasporte es:"+ad1.Trasporte(2,"Carro particular"));
         
    administracion ad2=new administracion();
         ad1.Imprimir(2137947,"Tatiana Sofia Arevalo Sanchez",19,"Av 32- cl 22#12", 3212991, "Equipo de aseo","Indefinido");
         System.out.println("Horaio es: "+ad2.Horario(2,"Lunes a sabado 8:00-7:00"));
         System.out.println("Trasporte es:"+ad2.Trasporte(2,"Bus escolar"));
    }

    private void Imprimir(int i, String jose_Daniel_Benjumea_Arzuaga, int i0, String ak_7_46, int i1, int i2, String $1000000) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private String Horario(int i, String lunes_a_viernes_de_9am__4pm) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    private String Trasporte(int i, String bus_escolar) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private void Imprimir(int i, String hector_Rodrigez_Peña, int i0, String av_32_cl_2212, int i1, String cuepo_docente, String indefinido) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
