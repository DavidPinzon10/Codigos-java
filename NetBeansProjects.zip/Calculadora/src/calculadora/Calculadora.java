
package calculadora;
import java.util.Scanner;

public class Calculadora {
Scanner leer = new Scanner(System.in);

private double x, y;

public Calculadora(){
    
    System.out.println("Digite el primer numero");
    x = leer.nextInt();
    System.out.println("Digite el segundo numero");
    y = leer.nextInt();
    System.out.println("-------------------------------------");
    System.out.println("Suma            = "+this.suma(x, y));
    System.out.println("Resta           = "+this.resta(x, y));
    System.out.println("Multiplicación  = "+this.multip(x, y));
    System.out.println("Division        = "+this.divi(x, y));
    System.out.println("Potencia        = "+this.exp(x, y));
}
private double suma(double x, double y){
    return  x + y;
}    
private double resta(double x, double y){
    return x - y;
}   
private double multip(double x, double y){
    return x * y;
}   
private double divi(double x, double y){
    return x / y;
}   
private double exp(double x, double y){
    return Math.pow(x, y);
}   

    public static void main(String[] args) {
Calculadora principal = new Calculadora();


    }
    
}
