package Modelo;

import javax.swing.JOptionPane;

public class Estudiante {

    private String codigoEstudiante;
    private String nombres;
    private String apellidos;
    private Long numeroIdentificacion;
    private String direccion;
    private Long telefono;

    public Estudiante(String codigoEstudiante, String nombres, String apellidos, Long numeroIdentificacion) {
        this.codigoEstudiante = codigoEstudiante;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public Estudiante(String codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
        this.setApellidos(JOptionPane.showInputDialog(null, "Digite Apellidos:",
                "Digite los Apellidos del estudiante", JOptionPane.QUESTION_MESSAGE));
        this.setNombres(JOptionPane.showInputDialog(null, "Digite Nombres:",
                "Digite los Apellidos del estudiante", JOptionPane.QUESTION_MESSAGE));
        this.setNumeroIdentificacion(Long.parseLong(JOptionPane.showInputDialog(null, "Digite Identificacion:",
                "Digite el Número de Identificación", JOptionPane.QUESTION_MESSAGE)));
        this.setDireccion(JOptionPane.showInputDialog(null, "Digite Direccion:",
                "Digite la Dirección del estudiante", JOptionPane.QUESTION_MESSAGE));
        this.setTelefono(Long.parseLong(JOptionPane.showInputDialog(null, "Digite Teléfono:",
                "Digite el Teléfono del estudiante", JOptionPane.QUESTION_MESSAGE)));
    }
    public String getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(String codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Long getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(Long numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Long getTelefono() {
        return telefono;
    }

    public void setTelefono(Long telefono) {
        this.telefono = telefono;
    }

    
}
