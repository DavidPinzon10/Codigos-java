import java.util.Scanner;

/*
 * @author David Pinzón
 */
public class Menu {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        //precio produto
        int Precio_Pizza = 32_000;
        int Precio_Hotdog = 6_000;
        int Precio_Hamburguesa = 8_000;
        int Precio_Salchipapa = 5_000;
        int Precio_Gaseosa = 2_000;
        float IVA = 0.19f; //la f en el 0.19 es de float para que valga el decimal
        
        //variables, solicitudes del cliente
        int Cantidad_Pizza = 0;
        int Cantidad_Hotdog = 0;
        int Cantidad_Hamburguesa = 0;
        int Cantidad_Salchipapa = 0;
        int Cantidad_Gaseosa = 0;
        
        float Total_pagar = 0, Subtotal = 0;
        byte opcion, cantidad;
        
        int Subtotal_Pizza = 0;
        int Subtotal_Hotdog = 0;
        int Subtotal_Hamburguesa = 0;
        int Subtotal_Salchipapa = 0;
        int Subtotal_Gaseosa = 0;
        
        while (true) {
            System.out.println("I ======================= I ");
            System.out.println("I Comidas rápidas perriño I ");
            System.out.println("I ======================= I ");
     
            System.out.println("I ======================= I ");
            System.out.println("1. Pizza = 32.000");
            System.out.println("2. Hotdog = 6.000");
            System.out.println("3. Hamburguesa = 8.000");
            System.out.println("4. Salchipapa = 5.000");
            System.out.println("5. Gaseosa = 2.000");
            System.out.println("6. Terminar pedido");
            System.out.println("7. Salir de la aplicación");
            System.out.println("I ======================= I ");
            
            opcion = leer.nextByte();
            
            switch (opcion) {
                case 1:
                    System.out.println("Cantidad de pizza a pedir");
                    cantidad = leer.nextByte();
                    Cantidad_Pizza = Cantidad_Pizza + cantidad;
                    break;
                case 2:
                    System.out.println("Cantidad de Hotdog a pedir");
                    cantidad = leer.nextByte();
                    Cantidad_Hotdog = Cantidad_Hotdog + cantidad;
                    break;
                case 3:
                    System.out.println("Cantidad de hamburguesa a pedir");
                    cantidad = leer.nextByte();
                    Cantidad_Hamburguesa = Cantidad_Hamburguesa + cantidad;
                    break;
                case 4:
                    System.out.println("Cantidad de salchipapa a pedir");
                    cantidad = leer.nextByte();
                    Cantidad_Salchipapa = Cantidad_Salchipapa + cantidad;
                    break;
                case 5:
                    System.out.println("Cantidad de gaseosa a pedir");
                    cantidad = leer.nextByte();
                    Cantidad_Gaseosa = Cantidad_Gaseosa + cantidad;
                    break;
                case 6:
                    System.out.println("Comidas rápidas perriño");
                    
                    if (Cantidad_Pizza>0) {
                        Subtotal_Pizza = Cantidad_Pizza*Precio_Pizza;
                        System.out.println("Pizza.......... "+Cantidad_Pizza+"$"+Subtotal_Pizza);
                    }
                    if (Cantidad_Hotdog>0) {
                        Subtotal_Hotdog = Cantidad_Hotdog*Precio_Hotdog;
                        System.out.println("Hot dog........ "+Cantidad_Hotdog+"$"+Subtotal_Hotdog);
                    }
                    if (Cantidad_Hamburguesa>0) {
                        Subtotal_Hamburguesa = Cantidad_Hamburguesa*Precio_Hamburguesa;
                        System.out.println("Hamburguesa.... "+Cantidad_Hamburguesa+"$"+Subtotal_Hamburguesa);
                    }
                    if (Cantidad_Salchipapa>0) {
                        Subtotal_Salchipapa = Cantidad_Salchipapa*Precio_Salchipapa;
                        System.out.println("Salchipapa..... "+Cantidad_Salchipapa+"$"+Subtotal_Salchipapa);
                    }
                    if (Cantidad_Gaseosa>0) {
                        Subtotal_Gaseosa = Cantidad_Gaseosa*Precio_Gaseosa;
                        System.out.println("Gaseosa........ "+Cantidad_Gaseosa+"$"+Subtotal_Gaseosa);
                    }
                    Subtotal = Subtotal_Pizza+Subtotal_Hotdog+Subtotal_Hamburguesa+Subtotal_Salchipapa+Subtotal_Gaseosa;
                    System.out.println("l ========================================================== l");
                    System.out.println("                                  Subtotal = "+Subtotal);
                    System.out.println("                                       IVA = "+(Subtotal*IVA));
                float TotalPagar = Subtotal + (Subtotal*IVA);
                    System.out.println("                             Total a pagar = "+TotalPagar);
                    System.out.println("l ========================================================== l");
                    System.out.println("Presione un numero para otros clientes");
                    opcion = leer.nextByte();
                    
        Cantidad_Pizza = 0;
        Cantidad_Hotdog = 0;
        Cantidad_Hamburguesa = 0;
        Cantidad_Salchipapa = 0;
        Cantidad_Gaseosa = 0;
        
        Total_pagar = 0;
        Subtotal = 0;
        opcion = 0;
        cantidad = 0;
                    break;

                case 7:
                    
                    break;
                   
                default:
                    System.out.println("La opcion no esta en el menu");
                    
            }
            if (opcion == 7) {
                System.out.println("Gracias por usar el programa");
                break;
            }
        }
        
    }
    
}