
import java.util.Scanner;

/**
 * @author David
 */
public class MenuGuía4 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        byte opcion;

        while (true) {
            System.out.println("---------------------------------------------------------------------------------");
            System.out.println("                              Menú con 5 Programas");
            System.out.println("---------------------------------------------------------------------------------");
            System.out.println("1. Multiplos");
            System.out.println("2. Pares e impares");
            System.out.println("3. Factorial");
            System.out.println("4. Aleatorios y baloto");
            System.out.println("5. Recepcion de numero e impresion de pares");
            System.out.println("6. Menu restaurante");
            System.out.println("7. LLamadas telefonicas");
            System.out.println("8. Gracias y hasta luego");
            opcion = leer.nextByte();

            switch (opcion) {
                case 1:
                    int multiplo_1,
                     multiplo_2,
                     multiplo_3,
                     multiplo_4,
                     multiplo_5;

                    System.out.println("I---------------------------------------I");
                    System.out.println("I  Bienvenido al programa de multiplos  I");
                    System.out.println("I---------------------------------------I");

                    while (true) {
                        System.out.println("-------------------------------------------------------");
                        System.out.println("Digite el numero el cual desea hallar los 5 primeros multiplos");
                        System.out.println("1. Uno");
                        System.out.println("2. Dos");
                        System.out.println("3. Tres");
                        System.out.println("4. Cuatro");
                        System.out.println("5. Cinco");
                        System.out.println("-------------------------------------------------------");
                        opcion = leer.nextByte();
                        break;
                    }
                    switch (opcion) {
                        case 1:
                            multiplo_1 = 1 * 1;
                            multiplo_2 = 1 * 2;
                            multiplo_3 = 1 * 3;
                            multiplo_4 = 1 * 4;
                            multiplo_5 = 1 * 5;
                            System.out.println("Los multiplos de Uno son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
                            break;
                        case 2:
                            multiplo_1 = 2 * 1;
                            multiplo_2 = 2 * 2;
                            multiplo_3 = 2 * 3;
                            multiplo_4 = 2 * 4;
                            multiplo_5 = 2 * 5;
                            System.out.println("Los múltiplos de Dos son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
                            break;
                        case 3:
                            multiplo_1 = 3 * 1;
                            multiplo_2 = 3 * 2;
                            multiplo_3 = 3 * 3;
                            multiplo_4 = 3 * 4;
                            multiplo_5 = 3 * 5;
                            System.out.println("Los múltiplos de Tres son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
                            break;
                        case 4:
                            multiplo_1 = 4 * 1;
                            multiplo_2 = 4 * 2;
                            multiplo_3 = 4 * 3;
                            multiplo_4 = 4 * 4;
                            multiplo_5 = 4 * 5;
                            System.out.println("Los múltiplos de Cuatro son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
                            break;
                        case 5:
                            multiplo_1 = 5 * 1;
                            multiplo_2 = 5 * 2;
                            multiplo_3 = 5 * 3;
                            multiplo_4 = 5 * 4;
                            multiplo_5 = 5 * 5;
                            System.out.println("Los múltiplos de Cinco son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
                            break;
                        default:
                            System.out.println("Error");
                    }
                    break;

                case 2:
                    int numeros_Pares = 0;
                    int numeros_Impares = 1;

                    System.out.println("Numeros pares entre 1 y 10");
                    System.out.println("--------------------------------------------------------");

                    while (numeros_Pares <= 10) {
                        System.out.println("El numero par es: " + numeros_Pares);
                        numeros_Pares = numeros_Pares + 2;

                        System.out.println("--------------------------------------------------------");

                        while (numeros_Impares <= 10) {
                            System.out.println("El numero impar es: " + numeros_Impares);
                            numeros_Impares = numeros_Impares + 2;
                            break;
                        }
                    }
                case 3:
                    int Factorial = 1;//Porque al multiplicar hasta cero no se cumple el factorial
                    int Numero = 0;

                    System.out.println("Ingrese el número el cual desea hallar su factorial");
                    Numero = leer.nextInt();
                    System.out.println("---------------------------------------------------");
                    int Numero_Digitado = Numero;

                    while (Numero != 0) { //Diferente a 0 para qque no lo multiplique
                        Factorial = Factorial * Numero;
                        Numero--;  //Tiene que descender, "Decrementar" 7,6,5,4.. etc 

                    }
                    System.out.println("El factorial del numero " + Numero_Digitado + " es = " + Factorial);
                    break;

                case 4:
                    int num1 = 0,
                     num2 = 0,
                     num3 = 0,
                     num4 = 0,
                     num5 = 0,
                     num6 = 0;

                    System.out.println("Numeros de la suerte");
                    System.out.println("------------------------------------------------------");

                    System.out.println(Math.random() * 7);
                    System.out.println(Math.random() * 7);
                    System.out.println(Math.random() * 7);
                    System.out.println(Math.random() * 7);
                    System.out.println(Math.random() * 7);
                    System.out.println(Math.random() * 7);
                    System.out.println(Math.random() * 7);

                    System.out.println("------------------------------------------------------");
                    System.out.println("Digite el primer numero que salió en el baloto" + num1);
                    num1 = leer.nextInt();
                    System.out.println("Digite el segundo numero que salió en el baloto" + num2);
                    num2 = leer.nextInt();
                    System.out.println("Digite el tercer numero que salió en el baloto" + num3);
                    num3 = leer.nextInt();
                    System.out.println("Digite el cuarto numero que salió en el baloto" + num4);
                    num4 = leer.nextInt();
                    System.out.println("Digite el quinto numero que salió en el baloto" + num5);
                    num5 = leer.nextInt();
                    System.out.println("Digite el sexto numero que salió en el baloto" + num6);
                    num6 = leer.nextInt();
                    System.out.println("------------------------------------------------------");
                    System.out.println("------------------------------------------------------");
                    System.out.println("                    COMPARACION");
                    System.out.println("------------------------------------------------------");
                    System.out.println("------------------------------------------------------");
                    System.out.println("Primer numero baloto y aleatorio: La comparacion es... " + num1 + "..>=<.." + Math.random() * 7);
                    System.out.println("Segundo numero baloto y aleatorio: La comparacion es... " + num2 + "..>=<.." + Math.random() * 7);
                    System.out.println("Tercer numero baloto y aleatorio: La comparacion es... " + num3 + "..>=<.." + Math.random() * 7);
                    System.out.println("Cuarto numero baloto y aleatorio: La comparacion es... " + num4 + "..>=<.." + Math.random() * 7);
                    System.out.println("Quinto numero baloto y aleatorio: La comparacion es... " + num5 + "..>=<.." + Math.random() * 7);
                    System.out.println("Sexto numero baloto y aleatorio: La comparacion es... " + num6 + "..>=<.." + Math.random() * 7);
                    break;

                case 5:
                    int numero = 0;
                    int Par_1 = 2 * 1,
                     Par_2 = 2 * 2,
                     Par_3 = 2 * 3,
                     Par_4 = 2 * 4,
                     Par_5 = 2 * 5;

                    System.out.println("---------------------------------------------------------");
                    System.out.println("-              Digite un numero del 1 al 5              -");
                    System.out.println("---------------------------------------------------------");
                    numero = leer.nextInt();

                    if (numero == 1) {
                        System.out.println("El numero par por la cantidad 1 es: " + Par_1);
                    }
                    if (numero == 2) {
                        System.out.println("Los pares por la cantidad 2 es: " + Par_1 + ".." + Par_2);
                    }
                    if (numero == 3) {
                        System.out.println("Los pares por la cantidad 3 es: " + Par_1 + ".." + Par_2 + ".." + Par_3);
                    }
                    if (numero == 4) {
                        System.out.println("Los pares por la cantidad 4 es: " + Par_1 + ".." + Par_2 + ".." + Par_3 + ".." + Par_4);
                    }
                    if (numero == 5) {
                        System.out.println("Los pares por la cantidad 5 es: " + Par_1 + ".." + Par_2 + ".." + Par_3 + ".." + Par_4 + ".." + Par_5);
                    }
                    if (numero == 6) {
                        System.out.println("Error");
                    }
                    break;
                case 6:
                    int Precio_Pizza = 32_000;
                    int Precio_Hotdog = 6_000;
                    int Precio_Hamburguesa = 8_000;
                    int Precio_Salchipapa = 5_000;
                    int Precio_Gaseosa = 2_000;
                    float IVA = 0.19f; //la f en el 0.19 es de float para que valga el decimal

                    //variables, solicitudes del cliente
                    int Cantidad_Pizza = 0;
                    int Cantidad_Hotdog = 0;
                    int Cantidad_Hamburguesa = 0;
                    int Cantidad_Salchipapa = 0;
                    int Cantidad_Gaseosa = 0;

                    float Total_pagar = 0,
                     Subtotal = 0;
                    byte cantidad;

                    int Subtotal_Pizza = 0;
                    int Subtotal_Hotdog = 0;
                    int Subtotal_Hamburguesa = 0;
                    int Subtotal_Salchipapa = 0;
                    int Subtotal_Gaseosa = 0;

                    while (true) {
                        System.out.println("I ======================= I ");
                        System.out.println("I Comidas rápidas perriño I ");
                        System.out.println("I ======================= I ");

                        System.out.println("I ======================= I ");
                        System.out.println("1. Pizza = 32.000");
                        System.out.println("2. Hotdog = 6.000");
                        System.out.println("3. Hamburguesa = 8.000");
                        System.out.println("4. Salchipapa = 5.000");
                        System.out.println("5. Gaseosa = 2.000");
                        System.out.println("6. Terminar pedido");
                        System.out.println("7. Salir de la aplicación");
                        System.out.println("I ======================= I ");

                        opcion = leer.nextByte();

                        switch (opcion) {
                            case 1:
                                System.out.println("Cantidad de pizza a pedir");
                                cantidad = leer.nextByte();
                                Cantidad_Pizza = Cantidad_Pizza + cantidad;
                                break;
                            case 2:
                                System.out.println("Cantidad de Hotdog a pedir");
                                cantidad = leer.nextByte();
                                Cantidad_Hotdog = Cantidad_Hotdog + cantidad;
                                break;
                            case 3:
                                System.out.println("Cantidad de hamburguesa a pedir");
                                cantidad = leer.nextByte();
                                Cantidad_Hamburguesa = Cantidad_Hamburguesa + cantidad;
                                break;
                            case 4:
                                System.out.println("Cantidad de salchipapa a pedir");
                                cantidad = leer.nextByte();
                                Cantidad_Salchipapa = Cantidad_Salchipapa + cantidad;
                                break;
                            case 5:
                                System.out.println("Cantidad de gaseosa a pedir");
                                cantidad = leer.nextByte();
                                Cantidad_Gaseosa = Cantidad_Gaseosa + cantidad;
                                break;
                            case 6:
                                System.out.println("Comidas rápidas perriño");

                                if (Cantidad_Pizza > 0) {
                                    Subtotal_Pizza = Cantidad_Pizza * Precio_Pizza;
                                    System.out.println("Pizza.......... " + Cantidad_Pizza + "$" + Subtotal_Pizza);
                                }
                                if (Cantidad_Hotdog > 0) {
                                    Subtotal_Hotdog = Cantidad_Hotdog * Precio_Hotdog;
                                    System.out.println("Hot dog........ " + Cantidad_Hotdog + "$" + Subtotal_Hotdog);
                                }
                                if (Cantidad_Hamburguesa > 0) {
                                    Subtotal_Hamburguesa = Cantidad_Hamburguesa * Precio_Hamburguesa;
                                    System.out.println("Hamburguesa.... " + Cantidad_Hamburguesa + "$" + Subtotal_Hamburguesa);
                                }
                                if (Cantidad_Salchipapa > 0) {
                                    Subtotal_Salchipapa = Cantidad_Salchipapa * Precio_Salchipapa;
                                    System.out.println("Salchipapa..... " + Cantidad_Salchipapa + "$" + Subtotal_Salchipapa);
                                }
                                if (Cantidad_Gaseosa > 0) {
                                    Subtotal_Gaseosa = Cantidad_Gaseosa * Precio_Gaseosa;
                                    System.out.println("Gaseosa........ " + Cantidad_Gaseosa + "$" + Subtotal_Gaseosa);
                                }
                                Subtotal = Subtotal_Pizza + Subtotal_Hotdog + Subtotal_Hamburguesa + Subtotal_Salchipapa + Subtotal_Gaseosa;
                                System.out.println("l ========================================================== l");
                                System.out.println("                                  Subtotal = " + Subtotal);
                                System.out.println("                                       IVA = " + (Subtotal * IVA));
                                float TotalPagar = Subtotal + (Subtotal * IVA);
                                System.out.println("                             Total a pagar = " + TotalPagar);
                                System.out.println("l ========================================================== l");
                                System.out.println("Presione un numero para otros clientes");
                                opcion = leer.nextByte();

                                Cantidad_Pizza = 0;
                                Cantidad_Hotdog = 0;
                                Cantidad_Hamburguesa = 0;
                                Cantidad_Salchipapa = 0;
                                Cantidad_Gaseosa = 0;

                                Total_pagar = 0;
                                Subtotal = 0;
                                opcion = 0;
                                cantidad = 0;
                                break;

                            case 7:

                                break;

                            default:
                                System.out.println("La opcion no esta en el menu");

                        }
                        if (opcion == 7) {
                            System.out.println("Gracias por usar el programa");
                            break;
                        }
                    }
                    break;

                case 7:
                    float Costo = 0;
                    float Cuenta = 0;
                    char Tipo = ' ';
                    int Duracion = 0;
                    int CL = 0;

                    System.out.println("l-----------------------------------------------l");
                    System.out.println("      Bienvenido a - LLAMADAS DON ANTONIO -      ");
                    System.out.println("l-----------------------------------------------l");

                    while (Tipo != 'x' && Duracion != -1) {
                        System.out.println("Digite el tipo de llamada");
                        System.out.println("I. Internacional");
                        System.out.println("N. Nacional");
                        System.out.println("L. Local");
                        System.out.println("Para salir ponga X en tipo y -1 en duración");
                        System.out.println("-------------------------------------------------");
                        System.out.println("Tipo : ");
                        Tipo = leer.next().charAt(0);

                        System.out.println("Digite la duración");
                        Duracion = leer.nextInt();

                        switch (Tipo) {
                            case 'I','i':
                                if (Duracion <= 3) {
                                    Costo = 7;
                                } else {
                                    Costo = (7 + (Duracion - 3) * 3.03F);
                                }
                                Cuenta = Cuenta + Costo;
                                System.out.println("I" + Costo + " " + Cuenta);
                                break;

                            case 'N','n':
                                if (Duracion <= 3) {
                                    Costo = 1.20F;
                                } else {
                                    Costo = (1.20F + (Duracion - 3) * 0.84F);
                                }
                                Cuenta = Cuenta + Costo;
                                System.out.println("N" + Costo + " " + Cuenta);
                                break;

                            case 'L','l':
                                CL++; //CL = CL+1
                                if (Duracion > 5) {
                                    Costo = 0.60F;
                                } else //Se puede sin corchetes ya que solo hay una instrucción
                                {
                                    Costo = 0;
                                }

                                Cuenta = Cuenta + Costo;
                                System.out.println("L" + Costo + "" + Cuenta);
                                break;

                            default:
                                System.out.println("Error");
                        }
                    }
                    break;

                case 8:
                    break;
                default:
                    System.out.println("Gracias por usar el programa, hasta luego");
            }
            if (opcion == 8) {

                System.out.println("Gracias por usar el programa, hasta luego");
                break;
            }
        }
    }
}
