package TuNominaYa;
// Programa de prueba de la jerarqu�a Empleado.
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public abstract class PruebaSistemaNomina extends Empleado {

   public static void main( String[] args )    {
       
       
       // Datos MenúOpción, NúmeroEmpleados y TipoEmpleado
       int MOpc, NEmple=0, TEmple;
       
       // Datos del empleado
       String nombre, apellido, NSocial;
       double salario, ventasT, tasaC, salarioB, tasa, sueldoH, horas;
       
        // Limita la cantidad de decimales a 2 
        DecimalFormat dosDigitos = new DecimalFormat( "0.00" );

        //Menú del usuario empleador
        JOptionPane.showMessageDialog(null,"Bienvenido a TuNominaYA");
        NEmple = Integer.parseInt(JOptionPane.showInputDialog("Cuantos empleados tienes"));
                    
            Empleado empleados[] = new Empleado[NEmple];
        while (true){
            // Menú principal de TuNominaYa            
                    
            MOpc = Integer.parseInt(JOptionPane.showInputDialog("Que vas a realizar:\n 1.Agregar\n 2.Consultar\n 3.Editar \n 4.Eliminar\n 5.Salir"));
            switch(MOpc){
                case 1:
                    // Menú de agregación                                     
                    for(int i=0; i<empleados.length ; i++){
                        TEmple = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tipo de empleado:\n 1.Asalariado\n 2.Por comisión\n 3.Base mas comuisión\n 4.Por horas"));
                        switch(TEmple){
                            case 1:
                                // Empleado asalariado
                                nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                                apellido = JOptionPane.showInputDialog("Dime el apellido");
                                NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                                salario = Double.parseDouble(JOptionPane.showInputDialog("Dime el salario mensual"));
                                
                                empleados[ i ] = new EmpleadoAsalariado( nombre, apellido, NSocial, salario);
                                break;
                            case 2:
                                // Empleado por comisión
                                nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                                apellido = JOptionPane.showInputDialog("Dime el apellido");
                                NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                                ventasT = Double.parseDouble(JOptionPane.showInputDialog("Dime las ventas totales"));
                                // No se si la tasa tiene que ser constante
                                tasaC = Double.parseDouble(JOptionPane.showInputDialog("Dime la tasa por comision"));
                                
                                empleados[ i ] = new EmpleadoPorComision( nombre, apellido, NSocial, ventasT, tasaC);
                                break;
                            case 3:
                                // Empleado base mas comisión
                                nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                                apellido = JOptionPane.showInputDialog("Dime el apellido");
                                NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                                ventasT = Double.parseDouble(JOptionPane.showInputDialog("Dime las ventas totales"));
                                // No se si la tasa tiene que ser constante
                                tasa = Double.parseDouble(JOptionPane.showInputDialog("Dime la tasa"));
                                salarioB = Double.parseDouble(JOptionPane.showInputDialog("Dime el salario base"));
                                
                                empleados[ i ] = new EmpleadoBaseMasComision( nombre, apellido, NSocial, ventasT, tasa, salarioB);
                                break;
                            case 4:
                                // Empleado por horas
                                nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                                apellido = JOptionPane.showInputDialog("Dime el apellido");
                                NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                                sueldoH = Double.parseDouble(JOptionPane.showInputDialog("Dime el sueldo por hora"));
                                horas = Double.parseDouble(JOptionPane.showInputDialog("Dime las horas trabajadas"));
                                
                                empleados[ i ] = new EmpleadoPorHoras( nombre, apellido, NSocial, sueldoH, horas);
                                break;
                            default:
                                JOptionPane.showMessageDialog(null,"Esa opción no es válida");
                                break;
                        }
                    }
                    break;
                case 2:
                    // Menú de consultar                                     
                    JOptionPane.showMessageDialog(null,"Los empleados son:");
                    
                    String salida = "";
                    for(int j=0; j<empleados.length; j++){                        
                        salida += empleados[ j ].toString();
                        if ( empleados[ j ] instanceof EmpleadoBaseMasComision ) {

                            // conversi�n descendente de referencia a Empleado a 
                            // referencia a EmpleadoBaseMasComision
                            EmpleadoBaseMasComision empleadoActual = ( EmpleadoBaseMasComision ) empleados[ j ];

                            double salarioBaseAnterior = empleadoActual.obtenerSalarioBase();
                            salida += "\nsalario base anterior: $" + salarioBaseAnterior;      

                            empleadoActual.establecerSalarioBase( 1.10 * salarioBaseAnterior );
                            salida += "\nel nuevo salario base con aumento del 10% es: $" +
                               empleadoActual.obtenerSalarioBase();

                        }else if ( empleados[ j ] instanceof EmpleadoPorHoras ) {

                            // conversi�n descendente de referencia a Empleado a 
                            // referencia a EmpleadoBaseMasComision
                            EmpleadoPorHoras empleadoActual = ( EmpleadoPorHoras ) empleados[ j ];

                            double salarioBaseAnterior = empleadoActual.ingresos();
                            salida += "\nsalario base anterior: $" + salarioBaseAnterior;      

                            empleadoActual.establecerHoras( 1.10 * salarioBaseAnterior );
                            salida += "\nel nuevo salario base con aumento del 10% es: $" +
                               empleadoActual.obtenerHoras();
                        }
                        
                        salida += "\ngano: $" + empleados[ j ].ingresos() + "\n";
                    }
                    
                    for ( int j = 0; j < empleados.length; j++ ) {
                        salida += "\nEl empleado " + (j+1) + " es un " +empleados[ j ].getClass().getName(); 
                    }                      
                    JOptionPane.showMessageDialog( null, salida );              
                    break;
                case 3:
                    // Menú de actualizar
                    int W=0;
                    String salidas = "";
                    while(W != 3){                                                
                        for(int j=0; j<empleados.length; j++){                        
                            salidas +=(j+1)+ empleados[ j ].toString();                            
                        }
                        JOptionPane.showMessageDialog( null, salidas );
                        
                        int editar = Integer.parseInt(JOptionPane.showInputDialog("Cual es el empleado que deseas editar"));
                        editar--;
                        if(empleados[ editar ] instanceof EmpleadoAsalariado){
                            // Empleado asalariado
                            nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                            apellido = JOptionPane.showInputDialog("Dime el apellido");
                            NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                            salario = Double.parseDouble(JOptionPane.showInputDialog("Dime el salario mensual"));
                            
                            empleados[ editar ] = new EmpleadoAsalariado( nombre, apellido, NSocial, salario);
                        }else if(empleados[ editar ] instanceof EmpleadoPorComision){
                            // Empleado por comisión
                            nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                            apellido = JOptionPane.showInputDialog("Dime el apellido");
                            NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                            ventasT = Double.parseDouble(JOptionPane.showInputDialog("Dime las ventas totales"));
                            // No se si la tasa tiene que ser constante
                            tasaC = Double.parseDouble(JOptionPane.showInputDialog("Dime la tasa por comision"));

                            empleados[ editar ] = new EmpleadoPorComision( nombre, apellido, NSocial, ventasT, tasaC);
                        }else if(empleados[ editar ] instanceof EmpleadoBaseMasComision){
                            // Empleado base mas comisión
                            nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                            apellido = JOptionPane.showInputDialog("Dime el apellido");
                            NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                            ventasT = Double.parseDouble(JOptionPane.showInputDialog("Dime las ventas totales"));
                            // No se si la tasa tiene que ser constante
                            tasa = Double.parseDouble(JOptionPane.showInputDialog("Dime la tasa"));
                            salarioB = Double.parseDouble(JOptionPane.showInputDialog("Dime el salario base"));

                            empleados[ editar ] = new EmpleadoBaseMasComision( nombre, apellido, NSocial, ventasT, tasa, salarioB);
                        }else if(empleados[ editar ] instanceof EmpleadoPorHoras){
                            // Empleado por horas
                            nombre = JOptionPane.showInputDialog("Dime el primer nombre");
                            apellido = JOptionPane.showInputDialog("Dime el apellido");
                            NSocial = JOptionPane.showInputDialog("Dime el núemero social");
                            sueldoH = Double.parseDouble(JOptionPane.showInputDialog("Dime el sueldo por hora"));
                            horas = Double.parseDouble(JOptionPane.showInputDialog("Dime las horas trabajadas"));

                            empleados[ editar ] = new EmpleadoPorHoras( nombre, apellido, NSocial, sueldoH, horas);
                        }
                        W = Integer.parseInt(JOptionPane.showInputDialog("Si ya termino de editar pulse 3"));
                    }
                    break;
                case 4:
                    // Menú de eliminar
                    int E=0;
                    String exit = "";
                    while(E != 3){                                                
                        for(int j=0; j<empleados.length; j++){                        
                            exit +=(j+1)+ empleados[ j ].toString();                            
                        }
                        JOptionPane.showMessageDialog( null, exit );
                        
                        int editar = Integer.parseInt(JOptionPane.showInputDialog("Cual es el empleado que deseas eliminar"));
                        editar--;
                        if(empleados[ editar ] instanceof EmpleadoAsalariado){
                            // Empleado asalariado
                            String vacio="----";
                            double nada=0.00;
                            
                            empleados[ editar ] = new EmpleadoAsalariado( vacio, vacio, vacio, nada);
                        }else if(empleados[ editar ] instanceof EmpleadoPorComision){
                            // Empleado por comisión
                            String vacio="----";
                            double nada=0.0;
                            
                            empleados[ editar ] = new EmpleadoPorComision( vacio, vacio, vacio, nada, nada);
                        }else if(empleados[ editar ] instanceof EmpleadoBaseMasComision){
                            // Empleado base mas comisión
                            String vacio="----";
                            double nada=0.0;
                            
                            empleados[ editar ] = new EmpleadoBaseMasComision( vacio, vacio, vacio, nada, nada, nada);
                        }else if(empleados[ editar ] instanceof EmpleadoPorHoras){
                            // Empleado por horas
                            String vacio="----";
                            double nada=0.0;
                            
                            empleados[ editar ] = new EmpleadoPorHoras( vacio, vacio, vacio, nada, nada);
                        }
                        E = Integer.parseInt(JOptionPane.showInputDialog("Si ya termino de eliminar pulse 3"));
                    }
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null,"Que tengas un gran día");
                    System.exit( 0 );
                    break;
                default:
                    JOptionPane.showMessageDialog(null,"Esa opcion no es valida");
                    break;
            } // Fin del switch   
        } // Fin del while

   } // fin de main

} // fin de la clase PruebaSistemaNomina
