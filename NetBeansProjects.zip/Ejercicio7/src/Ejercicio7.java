/**
 * @author David Pinzón
 */
public class Ejercicio7 {
    public static void main(String[] args) {
        
        int numerosA [] = new int [21];
        int nMayor;
        int nMenor;
        int posicion, posicionM;   
        
        for (int i = 0; i < 21; i++) {
            numerosA[i] = (int)(Math.random()*500+1 );
            System.out.println(" Posicion "+i+" = "+numerosA[i]);
        posicion = i;
        posicionM = i;
        }
        nMayor = nMenor = numerosA[0];
       
        for (int i = 0; i < 21; i++) {
            if (numerosA[i] > nMayor) {
                nMayor = numerosA[i];
            }
            if (numerosA[i] < nMenor) {
                nMenor = numerosA[i];
            }    
        }
        System.out.println("----------------------------------------------------------");
        System.out.println("El número mayor es = "+nMayor+", su posicion esta al lado ");
        System.out.println("El número menor es = "+nMenor+", su posicion esta al lado ");
        System.out.println("----------------------------------------------------------");
         
    }
}
