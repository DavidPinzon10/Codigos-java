
package Visual;
import concesionarioa404.Vehiculo;
import concesionarioa404.DataVehiculo;
import concesionarioa404.Fabrica;
import concesionarioa404.IControladorVehiculos;
import javax.swing.JOptionPane;


public class Eliminar extends javax.swing.JInternalFrame {
    private IControladorVehiculos ICU;
    
    public Eliminar() {
        initComponents();
        this.setSize(270, 130);
        
        //Inicialización
        Fabrica fabrica = Fabrica.getInstance();
        ICU = fabrica.getIControladorVehiculos();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LabelElCo = new javax.swing.JLabel();
        TextFieldElCo = new javax.swing.JTextField();
        ButtonElCa = new javax.swing.JButton();
        ButtonElEl = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Eliminar");

        LabelElCo.setText("Codigo:");

        ButtonElCa.setText("Cancelar");

        ButtonElEl.setText("Eliminar");
        ButtonElEl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonElElActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LabelElCo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldElCo))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ButtonElCa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                        .addComponent(ButtonElEl)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelElCo)
                    .addComponent(TextFieldElCo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonElCa)
                    .addComponent(ButtonElEl))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonElElActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonElElActionPerformed
        // Obtenemos los datos escritos por el usuario
        String codigoV = this.TextFieldElCo.getText();        
        
        // Guardo los datos
        ICU.eliminarVehiculo(codigoV);
        
        // Limpiamos 
        this.TextFieldElCo.setText("");       
        this.setVisible(false);
        
        //Muestro éxito de la operación
        System.out.println("El vehiculo se a eliminado exitosamente");
        JOptionPane.showMessageDialog(this, "El vehiculo se a eliminado exitosamente");
    }//GEN-LAST:event_ButtonElElActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonElCa;
    private javax.swing.JButton ButtonElEl;
    private javax.swing.JLabel LabelElCo;
    private javax.swing.JTextField TextFieldElCo;
    // End of variables declaration//GEN-END:variables
}
