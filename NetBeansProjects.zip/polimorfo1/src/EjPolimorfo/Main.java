package EjPolimorfo;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Estudiante estud = new Estudiante();
        Docente docente = new Docente();
        Administrativo administrador = new Administrativo();
        Scanner leer = new Scanner(System.in);

        byte opcion;

        while (true) {
            System.out.println("-------------------------------");
            System.out.println("I    U N I V E R S I D A D    I");
            System.out.println("-------------------------------");
            System.out.println("1. Ingresar  Estudiante");
            System.out.println("2. Consultar Estudiante");
            System.out.println("3. Ingresar  Docente");
            System.out.println("4. Consultar Docente");
            System.out.println("5. Ingresar  Administrativo");
            System.out.println("6. Consultar Administrativo");
            System.out.println("7. Salir");
            System.out.println("-------------------------------");

            opcion = leer.nextByte();

            switch (opcion) {
                case 1:
                    estud.InsertarDatos();
                    break;
                case 2:
                    estud.MostrarDatos();
                    break;
                case 3:
                    docente.InsertarDatosDoc();
                    break;
                case 4:
                    docente.MostrarDatosDoc();
                    break;
                case 5:
                    administrador.InsertarDatosAdm();
                    break;
                case 6:
                    administrador.MostrarDatosAdm();
                    System.out.println("--------------------------------");
                    System.out.println("      Listado de estudiantes    ");
                    System.out.println("--------------------------------");
                    administrador.generarListadoEstudiantes();
                    break;
                case 7:
                    break;
            }
            if (opcion == 7) {
                System.out.println("-------------------------------------");
                System.out.println("I  Gracias por su tiempo, buen día  I");
                System.out.println("-------------------------------------");
                break;
            }
        }
    }
}
