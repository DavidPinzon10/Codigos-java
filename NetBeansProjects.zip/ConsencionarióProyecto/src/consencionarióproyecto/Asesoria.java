package consencionarióproyecto;
import java.util.Scanner;

public class Asesoria {
    byte opAse;
    String nombre;
    String nroContacto;
    String ventas;
    String preventas;
  
    public Asesoria(){
        this.nombre = "";
        this.nroContacto = "";
        this.ventas = "";
        this.preventas = "";
    }
    public Asesoria(String nombre, String nroContacto, String ventas, String preventas){
        this.nombre = nombre;
        this.nroContacto = nroContacto;
        this.ventas = ventas;
        this.preventas = preventas;
    }
    
    public void Asesorias(){
        Asesoria ase = new Asesoria();
        Scanner Asc = new Scanner(System.in);
        //Menu de asesoria
        System.out.println("");
        System.out.println("---------------------------");
        System.out.println("I        Asesorías        I");
        System.out.println("---------------------------");
        System.out.println(" 1. Consultar asesores     ");
        System.out.println(" 2. Preguntas frecuentes   ");
        System.out.println(" 3. Salir                  ");
        System.out.println("---------------------------");
        opAse = Asc.nextByte();
            
        switch(opAse){
            case 1:
                ase.Asesores();
                break;
            case 2:
                ase.Preguntas();
                break;
            case 3:
                break;
            default:
                System.out.println("Esa opción no es valida \nIntente Nuevamente");
                break;
        }        
    }
    public void Asesores(){   
        Asesoria asesores[] = new Asesoria[3];
        asesores[0] = new Asesoria("David Alejandro Pinzon Benites", "+57 317 688 4299", "9 ventas", "2 Pre-ventas");
        asesores[1] = new Asesoria("Wilder Julian Lis Ramierez    ", "+57 315 208 2908", "6 ventas", "5 Pre-ventas");
        asesores[2] = new Asesoria("Samuel Dias Tibata            ", "+57 319 566 0274", "8 ventas", "4 Pre-ventas");
        
        // Menú de asesores
        System.out.println("");
        System.out.println("-----------------------------------------------");
        System.out.println("I                  Asesores                   I");
        System.out.println("-----------------------------------------------");
        for(int i=0; i> asesores.length;i++){
            int n = i + 1;
            System.out.println(""+asesores[i].getNombre());
            System.out.println(""+asesores[i].getNroContacto());
            System.out.println(""+asesores[i].getVentas());
            System.out.println(""+asesores[i].getPreventas());
        }               
        System.out.println("-----------------------------------------------");       
    }
    public void Preguntas(){
        Scanner Asc = new Scanner(System.in);
        
        System.out.println("-------------------------------------------------");
        System.out.println("I             PREGUNTAS FRECUENTES              I");
        System.out.println("-------------------------------------------------");
        System.out.println("1. ¿Como realizo una compra?                     ");
        System.out.println("2. ¿Cuanto tiempo de garantia hay por compra?    ");
        System.out.println("3. ¿Qué métodos o formas de pago hay disponibles ");
        System.out.println("4. salir");
        System.out.println("-------------------------------------------------");
        opAse = Asc.nextByte();
            switch (opAse) {
                case 1:
                    System.out.println("////////////////////////////////////////////////////");
                    System.out.println("Para realizar la compra debe entrar al sistema, luego"
                            + "\nen la opcion de comprar le saldrá venta o pre venta, usted debe"
                            + "\nllenar los datos y asi mismo se le mostrará los diferentes"
                            + "\nvehículos con sus caracteristicas principales. Escoge su forma"
                            + "\nde pago y se le entregará dicho material.");
                    break;
                case 2:
                    System.out.println("////////////////////////////////////////////////////");
                    System.out.println("El tiempo de garantía por carro o compra es de"
                            + "\nexactamente 3 años, luego ya no se cubrirán daños.");
                    break;
                case 3:
                    System.out.println("////////////////////////////////////////////////////");
                    System.out.println("Se encuentra disponible la forma en efectivo y"
                            + "\ntambién por tarjeta, se definiran unas cuotas para esta"
                            + "\ny se realizara el tramite.");
                    break;
                case 4:
                    break;
        }

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNroContacto() {
        return nroContacto;
    }

    public void setNroContacto(String nroContacto) {
        this.nroContacto = nroContacto;
    }

    public String getVentas() {
        return ventas;
    }

    public void setVentas(String ventas) {
        this.ventas = ventas;
    }

    public String getPreventas() {
        return preventas;
    }

    public void setPreventas(String preventas) {
        this.preventas = preventas;
    }
    
    
}
