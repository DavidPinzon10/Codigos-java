
package guia3_;
import java.util.Scanner;

public class Guia3_ {

    private static Scanner teclado = new Scanner(System.in);
    int opcion = 0;
    public static void main(String[] args) {
        Estudiante estudiante = new Estudiante();
        Profesor profesor = new Profesor();
        Administrativo administrativo = new Administrativo();
	Universidad universidad = new Universidad();
        
        universidad.InsertarDatos();
        int opcion = 0;

    do {
                System.out.println("\n\t\tMENU UNIVERSIDAD");
                System.out.println("\t\t---- -----------\n");
                System.out.println("[1] -- Registrar nuevos Estudiantes");
                System.out.println("[2] -- Estduiantes registrados");
                System.out.println("[3] -- Registrar nuevos docentes");
                System.out.println("[4] -- Docentes registrados");
                System.out.println("[5] -- Registrar nuevos coordinadores");
                System.out.println("[6] -- Coordinadores registradis");
                System.out.println("[9] -- TERMINAR PROGRAMA");
                System.out.print("Opcion: ");
                opcion = Integer.parseInt(teclado.nextLine());
                switch(opcion) {
                    case 1:
                        estudiante.InsertarDatos();
                        break;
                        
                    case 2:
                        estudiante.mostrarDatos();
                        break;
                    case 3:
                        profesor.InsertarDatos();
                        break;
                    case 4:
                        profesor.mostrarDatos();
                        break;
                    case 5:
                        administrativo.InsertarDatos();
                        break;                    
                    case 6:
                        administrativo.mostrarDatos();
                        break;                                                            
                    case 9:
                        System.out.println("\n\t\tFIN DE PROGRAMA");
                        break;
                    default:
                        System.out.println("Opción equivocada");
                    }
        } while(opcion != 9);  
    
    }
    
}
