
package concesionarioa404;

import java.util.*;
import java.io.*;

public class ArchivosVehiculos {
    
    
    public static void CrearFichero(String cod, String mar, String nom, String tip, String pre){
        FileWriter fw =null;
        try {
            fw = new FileWriter("vehiculos.txt",true);
            PrintWriter pw =new PrintWriter(fw);
            escribirFichero(pw, cod, mar, nom, tip, pre);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        finally {
            try {
                if (fw !=null){
                fw.close();
                }
            }
            catch (Exception e){System.out.println(e.getMessage());
            }
        }
    }
    
    public static void escribirFichero(PrintWriter pw, String cod, String mar, String nom, String tip, String pre)throws Exception{        
        pw.println(cod);
        pw.println(mar);
        pw.println(nom);
        pw.println(tip);
        pw.println(pre);
    }
    
    public static String leerFichero(BufferedReader br)throws Exception {
        String linea;
        linea = br.readLine();
        while (linea !=null){            
            System.out.println(linea);
            linea = br.readLine();
            return linea;

        }
        return "";
    }
    
    public static String mostrarFichero(){
        FileReader fr = null;
        try {
            File fichero = new File("vehiculos.txt");
            fr = new FileReader(fichero);
            BufferedReader br = new BufferedReader(fr);
            String line = leerFichero(br);
            return line;
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        finally {
            try {
                if (fr !=null)
            {
            fr.close();
            }
            }
            catch (Exception e){
                System.out.println(e.getMessage());
            }            
        }
        return "";
    }
}
