
package Visual;
import javax.swing.JOptionPane;

public class Principal extends javax.swing.JFrame {

    /**
     * Creates new form Principal
     */
    public Principal() {
        initComponents();
        this.setSize(1000, 600);
        this.InternalFrameConAdm.setVisible(false);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DesktopPanePrin = new javax.swing.JDesktopPane();
        InternalFrameConAdm = new javax.swing.JInternalFrame();
        LabelConAdmCod = new javax.swing.JLabel();
        TextFieldConAdmCod = new javax.swing.JTextField();
        ButtonConAdmVer = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        MenúTipUsu = new javax.swing.JMenu();
        MenuItemCli = new javax.swing.JMenuItem();
        MenuItemAdm = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Concesionario");
        setFocusable(false);

        InternalFrameConAdm.setTitle("ConfirmarAdministrador");
        InternalFrameConAdm.setVisible(true);

        LabelConAdmCod.setText("Codigo:");

        TextFieldConAdmCod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldConAdmCodActionPerformed(evt);
            }
        });

        ButtonConAdmVer.setText("Verificar");
        ButtonConAdmVer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonConAdmVerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout InternalFrameConAdmLayout = new javax.swing.GroupLayout(InternalFrameConAdm.getContentPane());
        InternalFrameConAdm.getContentPane().setLayout(InternalFrameConAdmLayout);
        InternalFrameConAdmLayout.setHorizontalGroup(
            InternalFrameConAdmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InternalFrameConAdmLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(InternalFrameConAdmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(InternalFrameConAdmLayout.createSequentialGroup()
                        .addComponent(LabelConAdmCod)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldConAdmCod, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InternalFrameConAdmLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(ButtonConAdmVer)))
                .addContainerGap())
        );
        InternalFrameConAdmLayout.setVerticalGroup(
            InternalFrameConAdmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InternalFrameConAdmLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(InternalFrameConAdmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelConAdmCod)
                    .addComponent(TextFieldConAdmCod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonConAdmVer)
                .addContainerGap())
        );

        DesktopPanePrin.setLayer(InternalFrameConAdm, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout DesktopPanePrinLayout = new javax.swing.GroupLayout(DesktopPanePrin);
        DesktopPanePrin.setLayout(DesktopPanePrinLayout);
        DesktopPanePrinLayout.setHorizontalGroup(
            DesktopPanePrinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DesktopPanePrinLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(InternalFrameConAdm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(364, Short.MAX_VALUE))
        );
        DesktopPanePrinLayout.setVerticalGroup(
            DesktopPanePrinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DesktopPanePrinLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(InternalFrameConAdm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(241, Short.MAX_VALUE))
        );

        jMenu1.setText("Bienvenid@");
        jMenuBar1.add(jMenu1);

        MenúTipUsu.setText("¿Qué tipo de usuario eres?");

        MenuItemCli.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        MenuItemCli.setText("Cliente");
        MenuItemCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuItemCliActionPerformed(evt);
            }
        });
        MenúTipUsu.add(MenuItemCli);

        MenuItemAdm.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        MenuItemAdm.setText("Admnistrador");
        MenuItemAdm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuItemAdmActionPerformed(evt);
            }
        });
        MenúTipUsu.add(MenuItemAdm);

        jMenuBar1.add(MenúTipUsu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DesktopPanePrin)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DesktopPanePrin)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuItemCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemCliActionPerformed
        MenuCliente windowMenCli = new MenuCliente();
        DesktopPanePrin.add(windowMenCli);
        windowMenCli.show();
    }//GEN-LAST:event_MenuItemCliActionPerformed

    private void MenuItemAdmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemAdmActionPerformed
        this.InternalFrameConAdm.setVisible(true);
    }//GEN-LAST:event_MenuItemAdmActionPerformed

    private void TextFieldConAdmCodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldConAdmCodActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldConAdmCodActionPerformed

    private void ButtonConAdmVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonConAdmVerActionPerformed
        // Traemos el dato
        String codigoAd = this.TextFieldConAdmCod.getText();
        
        if(codigoAd.equals("1234")){
            MenuAdministrador windowMenAdm = new MenuAdministrador();
            DesktopPanePrin.add(windowMenAdm);
            this.InternalFrameConAdm.setVisible(false);
            windowMenAdm.show();           
        }
        else{
            this.InternalFrameConAdm.setVisible(false);
            JOptionPane.showMessageDialog(null,"No se pudo verificar su validez");
        }
        
        // LImpiamos 
        this.TextFieldConAdmCod.setText("");
                
    }//GEN-LAST:event_ButtonConAdmVerActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonConAdmVer;
    private javax.swing.JDesktopPane DesktopPanePrin;
    private javax.swing.JInternalFrame InternalFrameConAdm;
    private javax.swing.JLabel LabelConAdmCod;
    private javax.swing.JMenuItem MenuItemAdm;
    private javax.swing.JMenuItem MenuItemCli;
    private javax.swing.JMenu MenúTipUsu;
    private javax.swing.JTextField TextFieldConAdmCod;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    // End of variables declaration//GEN-END:variables
}
