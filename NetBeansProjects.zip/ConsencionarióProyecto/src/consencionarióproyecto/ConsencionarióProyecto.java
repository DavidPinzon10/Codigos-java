package consencionarióproyecto;
import java.util.Scanner;

public class ConsencionarióProyecto {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Venta vent = new Venta();
        Pre_venta pre = new Pre_venta();
        Consultar cons = new Consultar();
        Asesoria ase = new Asesoria();
        
        // Variables que se utilizaran en los switch
        byte opMenu;
        byte opCompra;
        
        while(true){
            //Menú principal
            System.out.println("");
            System.out.println("-------------------");
            System.out.println("I  CONCENSIONARIO I");
            System.out.println("-------------------");
            System.out.println(" 1. Comprar        ");
            System.out.println(" 2. Consultar      ");
            System.out.println(" 3. Pedir Asesoría ");
            System.out.println(" 4. Salir          ");
            System.out.println("-------------------");            
            
            opMenu = sc.nextByte();
            
            switch(opMenu){
                case 1:     
                    //Menú de tipo de compra
                    System.out.println("");
                    System.out.println("-------------------");
                    System.out.println("I     COMPRAR     I");
                    System.out.println("-------------------");
                    System.out.println(" 1. Venta          ");
                    System.out.println(" 2. Pre-Venta      ");
                    System.out.println(" 3. Salir          ");
                    System.out.println("-------------------");                    
                    
                    opCompra = sc.nextByte();
                    
                    switch(opCompra){
                        case 1:
                            vent.pedirDatos();
                            break;
                        case 2:
                            pre.pedirDatos();
                            pre.MetodoPago();
                            break;
                        case 3:
                            break;
                    }
                    break;
                case 2: 
                    cons.Consulta(0);
                    break;
                case 3:
                    ase.Asesorias();
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Es opcion no es valida \nIntente nuevamuente");
                    break;
            }
            if (opMenu == 4)
                break;
        }
    }
    
}
