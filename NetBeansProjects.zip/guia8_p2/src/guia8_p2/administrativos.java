package guia8_p2;
public class administrativos {
//Atributos//
  String datos;
  String horario;
  String trasp;
//Metodo//
public void Imprimir(  int id, String nombre, int edad, String direción, int telefono, String areat, String tipoC){
    
    System.out.println("\nID: "+id);
    System.out.println("Nombre: "+nombre);
    System.out.println("Edad: "+edad);
    System.out.println("Direccion: "+direción);
    System.out.println("Telefono: "+telefono);
    System.out.println("Año escolar: "+areat);
    System.out.println("Pago de pension: "+tipoC); 
}
public String Horario(int a,String horario){
        
    this.horario=horario+"\tUsuario: Administrativo";
     return this.horario;
        
    }
public String Trasporte (int a,String trasp ){
 
        this.trasp=trasp+"\tUsuario: Administrativo";
        return this.trasp;
    }
}
