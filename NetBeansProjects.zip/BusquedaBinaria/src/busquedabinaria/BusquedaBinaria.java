
package busquedabinaria;

import javax.swing.JOptionPane;
import java.util.Arrays;

public class BusquedaBinaria {

    public static void main(String[] args) {
        // Crear el arreglo con 100 números aleatorios
        int[] numeros = new int[100];
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = (int) (Math.random() * 100000);
        }

        // Ordenar el arreglo utilizando QuickSort y medir el tiempo
        long tiempoInicio = System.currentTimeMillis();
        Arrays.sort(numeros);
        

        // Realizar la búsqueda binaria
        int valorBuscado = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor que desea buscar:"));
        int indice = busquedaBinaria(numeros, valorBuscado);

        // Mostrar resultados en pantalla
        String mensaje = "Arreglo ordenado: " + Arrays.toString(numeros) + "\n\n";
        mensaje += "Tiempo de ordenamiento: " + tiempoInicio + "ms\n\n";
        if (indice == -1) {
            mensaje += "El valor " + valorBuscado + " no se encuentra en el arreglo.";
        } else {
            mensaje += "El valor " + valorBuscado + " se encuentra en el índice " + indice + " del arreglo.";
        }
        JOptionPane.showMessageDialog(null, mensaje);
    }

    public static int busquedaBinaria(int[] arreglo, int valor) {
        int izquierda = 0;
        int derecha = arreglo.length - 1;

        while (izquierda <= derecha) {
            int medio = (izquierda + derecha) / 2;

            if (arreglo[medio] == valor) {
                return medio;
            } else if (arreglo[medio] > valor) {
                derecha = medio - 1;
            } else {
                izquierda = medio + 1;
            }
        }

        return -1;
    }
}