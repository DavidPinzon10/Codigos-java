package figuras;

import java.util.Scanner;

public class Principal {
    Figura listado[];
    public Principal() {
        listado = new Figura[2];
        listado[0]= new Triangulo();
        listado[1]= new Cuadrilatero();
        for(int pos=0;pos<1;pos++){
            listado[pos].calcularArea();
            listado[pos].calcularPerimetro();     
        }
    }
    
    public static void main(String[] args) {
               
                //Ejemplo19 dibujo = new Ejemplo19();
                Scanner leer = new Scanner (System.in);
                
                byte opcion;
                int opC=0, opT=0;
                
                while (true) {
                    System.out.println("   M E N U       F I G U R A S");
                    System.out.println("---------------------------------");
                    System.out.println("1. Triángulo");
                    System.out.println("2. Cuadrilátero");
                    System.out.println("3. Salir");
                    
                    opcion = leer.nextByte();
                    switch (opcion) {
                        case 1:
                            System.out.println("1. Rectangulo");
                            System.out.println("2. Isosceles");
                            System.out.println("3. Escaleno");
                            System.out.println("--------------------------");
                            System.out.println("Seleccione el tipo");
                            opT = leer.nextInt();
                            
                            if (opT == 1) {
                               Principal solucion= new Principal();
                            }
                            if (opT == 2) {
                               Principal solucion= new Principal();
                            }
                            if (opT == 3) {
                               Principal solucion= new Principal();
                            }
                            break;
                        case 2:
                            System.out.println("1. Cuadrado");
                            System.out.println("2. Trapecio");
                            System.out.println("--------------------------");
                            System.out.println("Seleccione el tipo");
                            opC = leer.nextInt();
                        case 3:
                            break;
                    }
                    if (opcion == 3) {
                        System.out.println("Hasta nunca");
                        break;
                    }
        }
    }
}
                