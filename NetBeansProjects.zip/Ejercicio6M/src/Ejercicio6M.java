import java.util.Scanner;
//  @author David Pinzon
public class Ejercicio6M {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        int año = 0,año2 = 0, año3 = 0, año4 = 0;
        int Pbarato = 0,Pbarato2 = 0,Pbarato3 = 0,Pbarato4 = 0;
        int Matriz[][] = new int[4][4];
        String vehiculos[] = {"Mazda     ",
                              "Toyota    ",
                              "BMW       ",
                              "Ford      "};

        for (int i = 0; i < vehiculos.length; i++) {
            for (int j = 0; j < vehiculos.length; j++) {

                System.out.println("Digite el precio [" + i + "," + j + "]");
                Matriz[i][j] = leer.nextInt();

                if (Matriz[i][j] > 0) {
                } else {
                    System.out.println("Error");
                }
            }
        }
        System.out.println("----------------------------------------------------------------");
        System.out.println("MARCA CARRO    P.2016    P.2017    P.2018    P.2019    P.2020");
        System.out.println("----------------------------------------------------------------");
        for (int i = 0; i < vehiculos.length; i++) {
            System.out.print(vehiculos[i] + "");
            for (int j = 0; j < vehiculos.length; j++) {

                System.out.print("   /  " + Matriz[i][j]);
            }
            System.out.println("");
        }
        System.out.println("----------------------------------------------------------------");
        System.out.println("Digite el menor precio y año en orden");
        Pbarato = leer.nextInt();  año = leer.nextInt();
        Pbarato2 = leer.nextInt(); año2 = leer.nextInt();
        Pbarato3 = leer.nextInt(); año3 = leer.nextInt();
        Pbarato4 = leer.nextInt(); año4 = leer.nextInt();
        System.out.println("----------------------------------------------------------------");
        System.out.println("MARCA       PRECIO       AÑO");
        System.out.println("Mazda  :  "+Pbarato+"  "+año);
        System.out.println("Toyota :  "+Pbarato2+" "+año2);
        System.out.println("BMW    :  "+Pbarato3+" "+año3);
        System.out.println("Ford   :  "+Pbarato4+" "+año4);
    }
}
