
package Visual;
import concesionarioa404.Vehiculo;
import concesionarioa404.DataVehiculo;
import concesionarioa404.Fabrica;
import concesionarioa404.IControladorVehiculos;
import javax.swing.JOptionPane;

public class Editar extends javax.swing.JInternalFrame {
    private IControladorVehiculos ICU;
    
    public Editar() {
        initComponents();
        this.setSize(270, 280);
        
        //Inicialización
        Fabrica fabrica = Fabrica.getInstance();
        ICU = fabrica.getIControladorVehiculos();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LabelEdCo = new javax.swing.JLabel();
        TextFieldEdCo = new javax.swing.JTextField();
        LabelEdNuNo = new javax.swing.JLabel();
        TextFieldEdiMar = new javax.swing.JTextField();
        ButtonEdEd = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        TextFieldEdiNom = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        TextFieldEdiTip = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        TextFieldEdiPre = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Editar");

        LabelEdCo.setText("Codigo:");

        LabelEdNuNo.setText("Nueva Marca:");

        TextFieldEdiMar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldEdiMarActionPerformed(evt);
            }
        });

        ButtonEdEd.setText("Editar");
        ButtonEdEd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonEdEdActionPerformed(evt);
            }
        });

        jLabel1.setText("Nuevo Nombre:");

        jLabel2.setText("Nuevo Tipo:");

        jLabel3.setText("Nuevo Precio:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LabelEdCo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldEdCo, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE))
                    .addComponent(TextFieldEdiMar)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(ButtonEdEd))
                    .addComponent(TextFieldEdiNom)
                    .addComponent(TextFieldEdiTip)
                    .addComponent(TextFieldEdiPre)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelEdNuNo)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelEdCo)
                    .addComponent(TextFieldEdCo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(LabelEdNuNo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldEdiMar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldEdiNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldEdiTip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldEdiPre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addComponent(ButtonEdEd)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TextFieldEdiMarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldEdiMarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldEdiMarActionPerformed

    private void ButtonEdEdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonEdEdActionPerformed
        // Obtenemos los datos escritos por el usuario
        String codigoV = this.TextFieldEdCo.getText();
        String MarcaV = this.TextFieldEdiMar.getText();
        String NombreV = this.TextFieldEdiTip.getText();
        String TipoV = this.TextFieldEdiNom.getText();
        String PrecioV = this.TextFieldEdiPre.getText();
        
        // Guardo los datos
        ICU.registrarVehiculo(codigoV, MarcaV, NombreV, TipoV, PrecioV);
        
        // LImpiamos 
        this.TextFieldEdCo.setText("");
        this.TextFieldEdiMar.setText("");
        this.TextFieldEdiTip.setText("");
        this.TextFieldEdiNom.setText("");        
        this.TextFieldEdiPre.setText("");
        this.setVisible(false);
        
        //Muestro éxito de la operación
        System.out.println("El vehiculo se a editado exitosamente");
        JOptionPane.showMessageDialog(this, "El vehiculo se a editado exitosamente");
    }//GEN-LAST:event_ButtonEdEdActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonEdEd;
    private javax.swing.JLabel LabelEdCo;
    private javax.swing.JLabel LabelEdNuNo;
    private javax.swing.JTextField TextFieldEdCo;
    private javax.swing.JTextField TextFieldEdiMar;
    private javax.swing.JTextField TextFieldEdiNom;
    private javax.swing.JTextField TextFieldEdiPre;
    private javax.swing.JTextField TextFieldEdiTip;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
