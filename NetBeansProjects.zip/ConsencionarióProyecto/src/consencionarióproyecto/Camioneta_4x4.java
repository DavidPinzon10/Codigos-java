package consencionarióproyecto;

public class Camioneta_4x4 extends Vehiculos{
    String numero;
    String carga;
    String [] F = new String[6];
    Camioneta_4x4 FV[] = new Camioneta_4x4[4];
    Camioneta_4x4 FP[] = new Camioneta_4x4[4];
    
    public Camioneta_4x4(){  
        this.numero = "";
        this.carga = "";
    }
    public Camioneta_4x4(String numero, String nombre, String asientos, String motor, String color, String carga, String precio){
        super(nombre, asientos, motor, color,precio);
        this.numero = numero;
        this.carga = carga;
    }
    public void Ford_ventaC(){                                
        // Atributos
        F[0] = " Nro. |";
        F[1] = " Nombre                        |";
        F[2] = " Asientos 1";                 
        F[3] = " Motor              1";                 
        F[4] = " Color          ";                 
        F[5] = " Precio(Dolares)"; 
        // Inicializando el objeto
        FV[0] = new Camioneta_4x4("  1.  !"," Maverick XL         |"," 5        |"," 2.5L  |"," Negro, Amarillo, Azul |",""," $20,995");
        FV[1] = new Camioneta_4x4("  2.  !"," Ranger XL           |"," 5        |"," 2.3L  |"," Rojo, Azul, Blanco    |",""," $25,980");
        FV[2] = new Camioneta_4x4("  3.  !"," F-150 XL            |"," 6        |"," 3.3L  |"," Blanco                |",""," $31,520");
        FV[3] = new Camioneta_4x4("  4.  !"," Super Duty F-250 XL |"," 6        |"," 6.2L  |"," Blanco                |",""," $39,445");
        
        System.out.println("");  
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println("I                                           Camionetas VENTA                                             I");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println(F[0]+F[1]+F[2]+F[3]+F[4]+F[5]);
        System.out.println(FV[0].getNumero()+FV[0].getNombre()+FV[0].getAsientos()+FV[0].getMotor()+FV[0].getColor()+" #"+FV[0].getPrecio());
        System.out.println(FV[1].getNumero()+FV[1].getNombre()+FV[1].getAsientos()+FV[1].getMotor()+FV[1].getColor()+" #"+FV[1].getPrecio());
        System.out.println(FV[2].getNumero()+FV[2].getNombre()+FV[2].getAsientos()+FV[2].getMotor()+FV[2].getColor()+" #"+FV[2].getPrecio());
        System.out.println(FV[3].getNumero()+FV[3].getNombre()+FV[3].getAsientos()+FV[3].getMotor()+FV[3].getColor()+" #"+FV[3].getPrecio());
        System.out.println("----------------------------------------------------------------------------------------------------------");
    }
    public void Ford_preventaC(){                                                       
        // Atributos
        F[0] = " Nro. |";
        F[1] = " Nombre                        |";
        F[2] = " Asientos 1";                 
        F[3] = " Motor              1";                 
        F[4] = " Color          ";                 
        F[5] = " Precio(Dolares)"; 
        // Inicializando el objeto
        FP[0] = new Camioneta_4x4("  1.  !"," Maverick XLT        |"," 5        |"," 2.5L  |"," Azul, Rojo            |","","23360");
        FP[1] = new Camioneta_4x4("  2.  !"," Ranger XLT          |"," 5        |"," 2.3L  |"," Azul, Negro           |","","30030");
        FP[2] = new Camioneta_4x4("  3.  !"," F-150 XLT           |"," 6        |"," 3.3L  |"," Negro, Rojo           |","","39165");
        FP[3] = new Camioneta_4x4("  4.  !"," Super Duty F-350 XL |"," 6        |"," 7.3L  |"," Blanco, Rojo          |","","40960");
        
        System.out.println("");  
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println("I                                          Camionetas Pre-VENTA                                          I");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println(F[0]+F[1]+F[2]+F[3]+F[4]+F[5]);
        System.out.println(FP[0].getNumero()+FP[0].getNombre()+FP[0].getAsientos()+FP[0].getMotor()+FP[0].getColor()+" $"+FP[0].getPrecio());
        System.out.println(FP[1].getNumero()+FP[1].getNombre()+FP[1].getAsientos()+FP[1].getMotor()+FP[1].getColor()+" $"+FP[1].getPrecio());
        System.out.println(FP[2].getNumero()+FP[2].getNombre()+FP[2].getAsientos()+FP[2].getMotor()+FP[2].getColor()+" $"+FP[2].getPrecio());
        System.out.println(FP[3].getNumero()+FP[3].getNombre()+FP[3].getAsientos()+FP[3].getMotor()+FP[3].getColor()+" $"+FP[3].getPrecio());
        System.out.println("----------------------------------------------------------------------------------------------------------");
    }
    
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCarga() {
        return carga;
    }

    public void setCarga(String carga) {
        this.carga = carga;
    }
    
}
