package guia8_p2;

public class estudiantes {
//Atributos//
  String horario;
  String trasp;
//Metodo//
public void Imprimir(  int id, String nombre, int edad, String direción, int telefono, int año, String valorP){
    System.out.println("\nID: "+id);
    System.out.println("Nombre: "+nombre);
    System.out.println("Edad: "+edad);
    System.out.println("Direccion: "+direción);
    System.out.println("Telefono: "+telefono);
    System.out.println("Año escolar: "+año);
    System.out.println("Pago de pension: "+valorP);
}
public String Horario(int a,String horario){
        
     this.horario=horario+"\tUsuario: Estudiante";
     return horario;
    }
public String Trasporte (int a,String trasp ){ 
        this.trasp=trasp+"\tUsuario: tEstudiante";
        return this.trasp;
    }
}
