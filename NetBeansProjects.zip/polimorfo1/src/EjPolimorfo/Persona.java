package EjPolimorfo;
import java.util.Hashtable;
import java.util.Scanner;

public class Persona {

    protected int NroID;
    protected int tipoID;
    protected String nombres;
    protected String apellidos;
    protected String direccion;
    private Persona[] matriz;

    public void consultarInfoPersonal() {
    }
public Persona(){
    this.NroID = 0;
    this.tipoID = 0;
    this.nombres = "";
    this.apellidos = "";
    this.direccion = "";
}
    
    public Persona(int NroID, int tipoID, String nombres, String apellidos, String direccion) {
        this.NroID = NroID;
        this.tipoID = tipoID;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
    }

    public int getNroID() {
        return NroID;
    }

    public void setNroID(int NroID) {
        this.NroID = NroID;
    }

    public int getTipoID() {
        return tipoID;
    }

    public void setTipoID(int tipoID) {
        this.tipoID = tipoID;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
     public void mostrarDatos() {
       Scanner leer = new Scanner(System.in);
       int Nestud=0;
       Nestud = leer.nextInt();
       matriz = new Persona[Nestud];
        for (int i = 0; i < Nestud; i++) {               
            System.out.println(matriz[i].getNombres()+""+matriz[i].getApellidos()+""+matriz[i].getDireccion());
    }
}
     public void MostrarDatosDoc(){
    }
     public void InsertarDatosDoc(){
    }
     public void MostrarDatosAdm(){
    }
}
