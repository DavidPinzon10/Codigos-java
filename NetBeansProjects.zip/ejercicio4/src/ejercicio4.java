import java.util.Scanner;
/**
 * @author David Pinzon
 */
public class ejercicio4 {

    public static void main(String[] args) {
      Scanner leer = new Scanner(System.in);
      
        int numeros = 0;      
        int i;
        boolean Repetidos = true;
        
        System.out.println("Por favor digite los 20 numeros que desee ");
        for (i = 0; i <= 19; i++) {
            numeros = leer.nextInt();
            System.out.println("- ");
            
            if (numeros > 0) {
                Repetidos = true;             
            }
        }
        
        if (Repetidos == false) {
            System.out.println("Hay numeros repetidos 1 o más veces");
           
        }
        else {
            System.out.println("No hay repetidos");
        }
    }
}
