package estacionc;

import java.util.Scanner;

/**
 * @author David pinzon
 */
public class EstacionC {
    Scanner leer = new Scanner(System.in);
   
    int t1, t2, t3, t4, t5, t6, t7;
    int Tmaxima, Tminima, media, totalm, totalmin;
    String d1, d2, d3, d4, d5, d6, d7;
    
public void dias (){
    System.out.println("DIGITE EL NOMBRE DE LOS DIAS DE LA SEMANA");
d1 = leer.nextLine();
d2 = leer.nextLine();
d3 = leer.nextLine();
d4 = leer.nextLine();
d5 = leer.nextLine();
d6 = leer.nextLine();
d7 = leer.nextLine();
System.out.println("---------------------------------------------------------");

}    
public void temp () {
    System.out.println("DIGITE LA TEMPERATURA DE CADA DIA EN ORDEN");
    t1 = leer.nextInt();
    t2 = leer.nextInt();
    t3 = leer.nextInt();
    t4 = leer.nextInt();
    t5 = leer.nextInt();
    t6 = leer.nextInt();
    t7 = leer.nextInt();
    
    if (t1< -30 &&t2< -30 &&t3< -30 &&t4< -30 &&t5< -30 &&t6< -30 &&t7< -30) {
        System.out.println("Error, vuelva a digitar la temperaura");
    }
    if (t1> 30 &&t2> 30 &&t3> 30 &&t4> 30 &&t5> 30 &&t6> 30 &&t7> 30) {
        System.out.println("Error, vuelva a digitar la temperaura");
    }
}
public void mediaT (){
    System.out.println("Escriba la temperatura minima");
    Tminima = leer.nextInt();
    System.out.println("Escriba la temperatura maxima");
    Tmaxima = leer.nextInt();
    
    media = (Tmaxima + Tminima)/2;
    
}   
public void aumento (){
    totalmin = (int) (Tminima * 0.1);
    totalm = (int) (Tmaxima * 0.1);
}
public void listado (){
    System.out.println("-------------------------------------------------------------");
    System.out.println(d1+" "+d2+" "+d3+" "+d4+" "+d5+" "+d6+" "+d7);
    System.out.println(t1+"      "+t2+"    "
            + "     "+t3+"       "+t4+"    "
                    + "   "+t5+"       "+t6+"      "+t7);
    System.out.println("-------------------------------------------------------------");
    System.out.println("Temperatura maxima................... = "+Tmaxima);
    System.out.println("Temperatura minima................... = "+Tminima);
    System.out.println("Temperatura media.................... = "+media);
    System.out.println("Temperatura maxima con 10%........... = "+totalm);
    System.out.println("Temperatura minima con 10%........... = "+totalmin);
}

    public static void main(String[] args) {
    EstacionC clima = new EstacionC ();
    
clima.dias();
clima.temp();
clima.mediaT();
clima.aumento();
clima.listado();


    }
    
}
