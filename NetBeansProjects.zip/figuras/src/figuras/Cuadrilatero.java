package figuras;
import javax.swing.JOptionPane;
public class Cuadrilatero extends Figura{
    protected Punto2D vertices[];
    protected int aux, px,py;
    String titulo;
    public Cuadrilatero(){
        vertices = new Punto2D[4];
        for(int conta=0;conta<4;conta++){
            aux =conta+1;
            px = Integer.parseInt(JOptionPane.showInputDialog("Cuadrilatero - Digite coordenada X del vertice "+aux));
            py = Integer.parseInt(JOptionPane.showInputDialog("Cuadrilatero - Digite coordenada Y del vertice "+aux));
            vertices[conta]= new Punto2D(px,py);
        }
    }
    @Override
    public int calcularArea() {
      double area, A,B,C,D,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))
               +(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))
               +(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))
               +(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       D= (float) Math.sqrt((Math.pow((vertices[3].getX()-vertices[2].getX()),2))
               +(Math.pow((vertices[3].getY()-vertices[2].getY()),2)));
       S=(A+B+C+D)/2;
       area=Math.sqrt(S*(S-A)*(S-B)*(S-C)*(S-D));
        System.out.println(""+A+"," +B+"," +C+"," +D);
       System.out.println("Area ="+area);
       return (int)area;
    }
    
    @Override
    public int calcularPerimetro() {
    double perimetro, A,B,C,D,S; 
       A= (float) Math.sqrt((Math.pow((vertices[1].getX()-vertices[0].getX()),2))
               +(Math.pow((vertices[1].getY()-vertices[0].getY()),2)));
       B= (float) Math.sqrt((Math.pow((vertices[2].getX()-vertices[1].getX()),2))
               +(Math.pow((vertices[2].getY()-vertices[1].getY()),2)));
       C= (float) Math.sqrt((Math.pow((vertices[0].getX()-vertices[2].getX()),2))
               +(Math.pow((vertices[0].getY()-vertices[2].getY()),2)));
       D= (float) Math.sqrt((Math.pow((vertices[3].getX()-vertices[2].getX()),2))
               +(Math.pow((vertices[3].getY()-vertices[2].getY()),2)));
       S=(A+B+C+D);
       System.out.println("Perimetro ="+S);
       return (int)S;
    }
    public void setColor(int idColor){
        // implementación de mi código 
    }

    @Override
    public void reDibujar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
