package sistemaecuaciones;

/**
 *
 * @author David
 */
import javax.swing.JOptionPane;

public class SistemaEcuaciones {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Resolveremos un sistema de ecuaciones 2 por 2");
        String inputA1 = JOptionPane.showInputDialog("Ingrese el coeficiente de {x} en la primera ecuación");
        String inputB1 = JOptionPane.showInputDialog("Ingrese el coeficiente de {y} en la primera ecuación");
        String inputC1 = JOptionPane.showInputDialog("Ingrese el término independiente de la primera ecuación");
        String inputA2 = JOptionPane.showInputDialog("Ingrese el coeficiente de {x} en la segunda ecuación");
        String inputB2 = JOptionPane.showInputDialog("Ingrese el coeficiente de {y} en la segunda ecuación");
        String inputC2 = JOptionPane.showInputDialog("Ingrese el término independiente de la segunda ecuación");

        double a1 = Double.parseDouble(inputA1);
        double b1 = Double.parseDouble(inputB1);
        double c1 = Double.parseDouble(inputC1);
        double a2 = Double.parseDouble(inputA2);
        double b2 = Double.parseDouble(inputB2);
        double c2 = Double.parseDouble(inputC2);

        Ecuacion ecuacion1 = new Ecuacion(a1, b1, c1);
        Ecuacion ecuacion2 = new Ecuacion(a2, b2, c2);

        double x = ecuacion1.resolverX(ecuacion2);
        double y = ecuacion1.resolverY(ecuacion2);

        JOptionPane.showMessageDialog(null, "x = " + x + "\ny = " + y);
    }
}
