package consencionarióproyecto;

public class Automovil extends Vehiculos {
    String numero;
    String [] F = new String[6];
    Automovil FV[] = new Automovil[1];
    Automovil FP[] = new Automovil[1];
    
    public Automovil(){  
        this.numero = "";
    }
    public Automovil(String numero, String nombre, String asientos, String motor, String color, String precio){
        super(nombre, asientos, motor, color,precio);
        this.numero = numero;
    }
    public void Ford_ventaA(){        
        // Atributos
        F[0] = " Nro. |";
        F[1] = " Nombre                |";
        F[2] = " Asientos 1";                 
        F[3] = " Motor              1";                 
        F[4] = " Color          |";      
        F[5] = " Precio(Dolares)";               
        // Inicializando el objeto
        FV[0] = new Automovil("  1.  !"," Mustang GT Fastback   |"," 4        1"," Ti-VCT V8 de 5.0L  1"," Verde, Naranja 1"," $38,045");
        
        System.out.println("");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println("I                                            Automoviles Ford                                            I");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println(F[0]+F[1]+F[2]+F[3]+F[4]+F[5]);
        System.out.println(FV[0].getNumero()+FV[0].getNombre()+FV[0].getAsientos()+FV[0].getMotor()+FV[0].getColor()+FV[0].getPrecio());        
        System.out.println("----------------------------------------------------------------------------------------------------------");       
    }
    public void Ford_preventaA(){        
        // Atributos
        F[0] = " Nro. |";        
        F[1] = " Nombre                        |";
        F[2] = " Asientos 1";                 
        F[3] = " Motor              1";                 
        F[4] = " Color          ";                 
        F[5] = " Precio(Dolares)"; 
        // Inicializando el objeto
        FP[0] = new Automovil("  1.  !"," Mustang GT Premiun Fastback   |"," 4        |"," 5.0L  |"," Morado, Anarillo |"," $38,045");
        
        System.out.println("");  
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println("I                                          AUTOMOVILES Pre-VENTA                                         I");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println(F[0]+F[1]+F[2]+F[3]+F[4]+F[5]);
        System.out.println(FP[0].getNumero()+FP[0].getNombre()+FP[0].getAsientos()+FP[0].getMotor()+FP[0].getColor()+FP[0].getPrecio());        
        System.out.println("----------------------------------------------------------------------------------------------------------");                              
    }
    
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }        
}
