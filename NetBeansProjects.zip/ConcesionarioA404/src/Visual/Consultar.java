
package Visual;
import concesionarioa404.Vehiculo;
import concesionarioa404.DataVehiculo;
import concesionarioa404.Fabrica;
import concesionarioa404.IControladorVehiculos;

public class Consultar extends javax.swing.JInternalFrame {
    private IControladorVehiculos ICU;
     
    public Consultar() {
        initComponents();
        this.setSize(270,340);
        
        //Inicialización
        Fabrica fabrica = Fabrica.getInstance();
        ICU = fabrica.getIControladorVehiculos();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LabelCoCo = new javax.swing.JLabel();
        TextFieldCodCod = new javax.swing.JTextField();
        ButtonConBus = new javax.swing.JButton();
        LabelCoNo = new javax.swing.JLabel();
        TextFieldConMar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        TextFieldConNom = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        TextFieldConTip = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        TextFieldConPre = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Consultar");

        LabelCoCo.setText("Codigo:");

        ButtonConBus.setText("Buscar");
        ButtonConBus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonConBusActionPerformed(evt);
            }
        });

        LabelCoNo.setText("Marca:");

        jLabel1.setText("Nombre:");

        jLabel2.setText("Tipo:");

        jLabel3.setText("Precio:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextFieldConMar)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LabelCoCo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldCodCod, javax.swing.GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE))
                    .addComponent(TextFieldConNom)
                    .addComponent(TextFieldConTip)
                    .addComponent(TextFieldConPre)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelCoNo)
                            .addComponent(ButtonConBus)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelCoCo)
                    .addComponent(TextFieldCodCod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ButtonConBus)
                .addGap(18, 18, 18)
                .addComponent(LabelCoNo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldConMar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldConNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldConTip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldConPre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonConBusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonConBusActionPerformed
        // TODO add your handling code here:
        if (this.TextFieldCodCod.getText().equals("")){
            this.TextFieldCodCod.setText("Ingresar Codigo");
        }
        else{
            DataVehiculo dv = ICU.verInfoVehiculo(this.TextFieldCodCod.getText());
            this.TextFieldConMar.setText(dv.getMarca());
            this.TextFieldConNom.setText(dv.getNombre());
            this.TextFieldConTip.setText(dv.getTipo());
            this.TextFieldConPre.setText(dv.getPrecio());
        }               
    }//GEN-LAST:event_ButtonConBusActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonConBus;
    private javax.swing.JLabel LabelCoCo;
    private javax.swing.JLabel LabelCoNo;
    private javax.swing.JTextField TextFieldCodCod;
    private javax.swing.JTextField TextFieldConMar;
    private javax.swing.JTextField TextFieldConNom;
    private javax.swing.JTextField TextFieldConPre;
    private javax.swing.JTextField TextFieldConTip;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
