
package sunrise;

/**
 * @author David Pinzon
 */
public class Sunrise {

    public static void main(String[] args) {
     servicios referencia = new servicios();
  
     referencia.getCodigo();
     referencia.getTotal();
     System.out.println("<--------------------------------------------------------------------------------->");
        System.out.println("");
        System.out.println("");
     System.out.println("<------------------------------------------------------------------------------------------------------------------------------------------------------>");
     System.out.println("<                                                     T  A  B  L  A  2 :   I  N  V  E  N  T  A  R  I  O                                                >");
     System.out.println("<------------------------------------------------------------------------------------------------------------------------------------------------------>"); 
     System.out.println("CLIENTE   |  CODIGO    |     DESCRIPCION       | CANTIDAD |  COSTO   |  SUBTOTAL   |    DESCUENTO   |      IVA     |    TOTAL     |   FRECUENCIA  | ");
     System.out.println("<------------------------------------------------------------------------------------------------------------------------------------------------------>");    
     referencia.tabla2();
     System.out.println("<------------------------------------------------------------------------------------------------------------------------------------------------------>");
    }
    
}
