package Modelo;

import java.util.Date;

public class Prestamo {
    private int idPrestamo;
    private int idLibro;
    private String nombreLibro;
    private String codigoEstudiante;    
    private String fechaPrestamo;
    private String fechaDevolucion;

    public Prestamo(int idPrestamo, int idLibro, String codigoEstudiante, String fechaPrestamo, String fechaDevolucion, String nombreLibro) {
        this.idPrestamo = idPrestamo;
        this.idLibro = idLibro;
        this.codigoEstudiante = codigoEstudiante;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
        this.nombreLibro = nombreLibro;
    }

    public void setIdPrestamo(int idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public void setCodigoEstudiante(String codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public void setFechaPrestamo(String fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public void setFechaDevolucion(String fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }
   
    public void setNombreLibro(String nombreLibro) {
        this.nombreLibro = nombreLibro;
    }
    
    public String getNombreLibro() {
        return nombreLibro;
    }

    public int getIdPrestamo() {
        return idPrestamo;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public String getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public String getFechaPrestamo() {
        return fechaPrestamo;
    }

    public String getFechaDevolucion() {
        return fechaDevolucion;
    }
}
