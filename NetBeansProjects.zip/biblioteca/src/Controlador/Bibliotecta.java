package Controlador;
import Modelo.Libro;
import Modelo.Estudiante;
import Modelo.Prestamo;
import java.util.Scanner;
import java.util.Hashtable;
import javax.swing.JOptionPane;

public class Bibliotecta {
    private int nroEjemplares=0;
    private int cantEstudiantes=0;
    private int cantPrestamos = 0;
    private String nombreColegio; 
    private String Direccion, isbn, tit, aut;
    private Hashtable estanteria;
    private Hashtable estudiantes;
    private Hashtable prestamos;
    private Scanner lector;
    private int contadorEstudiantes=0;
    
    public Bibliotecta() {
        estudiantes= new Hashtable();
        lector = new Scanner(System.in);
        estanteria= new Hashtable();
        try{
            for(nroEjemplares=0; nroEjemplares<3;nroEjemplares++){
                estanteria.put(nroEjemplares, new Libro(nroEjemplares));
            }
        }catch(ArrayIndexOutOfBoundsException ex){
            System.out.println("Error en adición de libro");
        }
    }
    
    
    public Estudiante crearEstudiante( String cantEstudiantes){
        lector = new Scanner(System.in);
        Estudiante estudiante = new Estudiante(cantEstudiantes);
        try{
            estudiantes.put(contadorEstudiantes, estudiante);
            contadorEstudiantes = contadorEstudiantes+1;
        }catch(ArrayIndexOutOfBoundsException ex){
            System.out.println("Error creando estudiantes");
        }
        return estudiante;
    }
    
    
    public void crearPrestamo(){
        Libro presLibro;
        Estudiante estudiante;
        lector = new Scanner(System.in);
        prestamos = new Hashtable();
        try{
            for(cantPrestamos=0; cantPrestamos<3; cantPrestamos++){
                presLibro = (Libro)estanteria.get(cantPrestamos);
                int idLibro = presLibro.getIdLibro();
                JOptionPane.showMessageDialog(null, "Prestando libro " + presLibro.getTitulo());
                JOptionPane.showMessageDialog(null, "A continuación ingresará los datos del estudiante.","ATENCION",JOptionPane.WARNING_MESSAGE);
                estudiante = crearEstudiante(String.valueOf(cantPrestamos));
                String codigoEstudiante = estudiante.getCodigoEstudiante();
                String nombreLibro = presLibro.getTitulo();
                JOptionPane.showMessageDialog(null, "A continuación ingresará los datos de préstamo del libro.","ATENCION",JOptionPane.WARNING_MESSAGE);
                String fechaPrestamo = JOptionPane.showInputDialog(null, "Fecha de préstamo:", "Digite la fecha de préstamo del libro", JOptionPane.QUESTION_MESSAGE);
                String fechaDevolucion = JOptionPane.showInputDialog(null, "Fecha de devolución:", "Digite la fecha de devolución del libro", JOptionPane.QUESTION_MESSAGE);
                prestamos.put(cantPrestamos, new Prestamo(cantPrestamos, idLibro, codigoEstudiante, fechaPrestamo, fechaDevolucion, nombreLibro));
            }
        }catch(ArrayIndexOutOfBoundsException ex){
            System.out.println("Error creando estudiantes");
        }
    }
    
    public void generarReporte(){
        Libro tempoLibro;
        String Aux=" ";
        for(int posicion=0; posicion<3;posicion++){
            tempoLibro = (Libro) estanteria.get(posicion);
            Aux= Aux+tempoLibro.getIdLibro()+" - "+ tempoLibro.getISBN()+" -  "+
                 tempoLibro.getAutor()+" - "+tempoLibro.getTitulo()+"\n";
        }
        JOptionPane.showMessageDialog(null, Aux,
                "Libros existentes en los estantes.", JOptionPane.INFORMATION_MESSAGE);     
    }
    
    public void generarReportePrestamo(){
        Prestamo presReportePrestamo;
        String Aux="ID_LIBRO    - TITULO_LIBRO             - FECHA_PRESTAMO       - FECHA_DEVOLUCION \n";
        for(int posicion=0; posicion<3;posicion++){
            presReportePrestamo = (Prestamo) prestamos.get(posicion);
            Aux= Aux+presReportePrestamo.getIdLibro()+"                      - "+presReportePrestamo.getNombreLibro()+" -                       - "+
                 presReportePrestamo.getFechaPrestamo()+" -                     - "+presReportePrestamo.getFechaDevolucion()+"\n";
        }
        JOptionPane.showMessageDialog(null, Aux,
                "Informe de préstamos.", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        Bibliotecta solucion = new Bibliotecta();
        String devolucion; 
    
        byte opcion;
        
        while (true) {
            System.out.println("-----------------------------------------------");
            System.out.println("I                   M E N U                   I");
            System.out.println("-----------------------------------------------");
            System.out.println("1. Libros que hay en la estantería");
            System.out.println("2. Crear prestamo");
            System.out.println("3. Reporte de prestamo");
            System.out.println("4. Consultar fechas disponibilidad y devolucion");
            System.out.println("5. Devolver libro");
            System.out.println("6. Salir");
            System.out.println("-----------------------------------------------");
       
        opcion = leer.nextByte();
        
        switch (opcion) {
            case 1:
                solucion.generarReporte();
                break;
            case 2:
                System.out.println("Registro de préstamo");
                solucion.crearPrestamo();
                break;
            case 3:
                System.out.println("Este es el reporte de lo que hay");
                solucion.generarReportePrestamo();
                break;
            case 4:
                System.out.println("Por favor seleccione la opcion 3 para consultar fechas");
                break;
            case 5:
                devolucion = leer.nextLine();                
                System.out.println("Libro devuelto");
                System.out.println("Gracias");
                break;
            case 6:
                break;   
        }
            if (opcion == 6) {
                System.out.println("-------------------------------------");
                System.out.println("I  Gracias por su tiempo, buen día  I");
                System.out.println("-------------------------------------");
                break;
            }
        }
}   
}
