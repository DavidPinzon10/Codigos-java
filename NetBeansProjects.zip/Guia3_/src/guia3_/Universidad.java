
package guia3_;

import javax.swing.JOptionPane;


public class Universidad {
    protected String nombreU;
    protected String direccionU;
    
    public Universidad(String nombre, String direccion) {
        this.nombreU = nombre;
        this.direccionU = direccion;
    }
    
    public Universidad() {
        this.nombreU = "";
        this.direccionU = "";
    }
    
    
    public String getNombreU() {
        return nombreU;
    }

    public String getDireccionU() {
        return direccionU;
    }

    public void setNombreU(String nombreU) {
        this.nombreU = nombreU;
    }

    public void setDireccionU(String direccionU) {
        this.direccionU = direccionU;
    }

    public void InsertarDatos() {
    nombreU = JOptionPane.showInputDialog("Nombre de la universidad ");
    getNombreU();
    }
}