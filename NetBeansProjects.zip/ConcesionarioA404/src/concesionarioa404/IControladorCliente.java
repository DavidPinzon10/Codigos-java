
package concesionarioa404;

public interface IControladorCliente {
    
    public abstract void registrarCliente(String nom, String ape, String num, String ced, String  tar);
    public abstract DataCliente verInfoCliente(String nom);
    public abstract void eliminarCliente(String nom);
}
