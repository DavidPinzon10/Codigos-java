package figuras;

import javax.swing.*;
import java.awt.*;

import static java.awt.Font.PLAIN;

public class dibujo extends JFrame {

    JPanel panel;

    public dibujo(){

        initPanel();
        initPantalla();
    }
    void initPanel(){
        panel = new JPanel();
        add(panel); //Añado el panel al JFrame
        panel.setPreferredSize(new Dimension(80,80)); //Dimensiones del panel
    }
    @Override
    public void paint(Graphics g){
        super.paint(g);

        //Para poder modificar más propiedades con Graphics 2d
        Graphics2D g2d = (Graphics2D) g;

       
//Triangulo (3 lados)
        int [] triangulo_x1 = {800, 300, 1300};
        int [] triangulo_y1 = {800, 200, 200};
       
        g2d.setColor(Color.GREEN);
        g2d.fillPolygon (triangulo_x1, triangulo_y1, 3);
        g2d.setColor(Color.BLACK);
        g2d.drawPolygon (triangulo_x1, triangulo_y1, 3);
    }

    private void initPantalla(){

        setTitle("Triangulo");
        setSize(80,80);
        setResizable(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

    }
    public static void main(String[] args) {
        new dibujo();
    }
}