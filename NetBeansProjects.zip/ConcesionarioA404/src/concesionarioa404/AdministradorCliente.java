
package concesionarioa404;
import java.util.HashMap;
import java.util.Map;

public class AdministradorCliente {
    private Map<String, Cliente> clienteCOD = new HashMap<String, Cliente>();
    private static AdministradorCliente instancia=null;
    
    private AdministradorCliente(){
        clienteCOD = new HashMap();
    }
    
    public static AdministradorCliente getinstance(){
        if (instancia==null)
            instancia = new AdministradorCliente();
        return instancia;
    }
    
    public void addCliente(Cliente cli){
        String cod = cli.getNombre();
        clienteCOD.put(cod,cli);
    }
    
    public void eliminarCliente(String cli){       
        clienteCOD.remove(cli);
    }
    
    public Cliente obtenerCliente(String nom){
        return ((Cliente) clienteCOD.get(nom));
    }
}
