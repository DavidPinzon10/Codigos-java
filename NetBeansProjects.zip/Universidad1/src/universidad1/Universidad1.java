
package universidad1;
import java.util.Scanner;

public class Universidad1 {
Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {
       
    Estudiantes alumno = new Estudiantes () ;
    Estudiantes alumno1 = new Estudiantes () ;
    Estudiantes alumno2 = new Estudiantes () ;
    Estudiantes alumno3 = new Estudiantes () ;
    Estudiantes alumno4 = new Estudiantes () ;
    Estudiantes administrador = new Estudiantes () ;
         
     alumno.getEstudiante1();
     System.out.println("-------------------------------------------------------------");
     System.out.println("-------------------------------------------------------------");
     System.out.println("");
     alumno1.getEstudiante2();
     System.out.println("-------------------------------------------------------------");
     System.out.println("-------------------------------------------------------------");
     System.out.println("");
     alumno2.getEstudiante3();
     System.out.println("-------------------------------------------------------------");
     System.out.println("-------------------------------------------------------------");
     System.out.println("");
     alumno3.getEstudiante4();
     System.out.println("-------------------------------------------------------------");
     System.out.println("-------------------------------------------------------------");
     System.out.println("");
     alumno4.getEstudiante5();
     System.out.println("-------------------------------------------------------------");
     System.out.println("-------------------------------------------------------------");
     System.out.println("");
     administrador.getAdmin();
    }
   
}