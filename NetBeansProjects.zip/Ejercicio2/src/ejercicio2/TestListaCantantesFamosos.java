
package ejercicio2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class TestListaCantantesFamosos extends ListaCantantesFamosos {
    public static void main(String[] args) {
        
ListaCantantesFamosos lista = new ListaCantantesFamosos();

        // añadir dos cantantes famosos
        CantanteFamoso cf1 = new CantanteFamoso("Michael Jackson", "Thriller");
        CantanteFamoso cf2 = new CantanteFamoso("Madonna", "Like a Virgin");
        lista.addCantanteFamoso(cf1);
         lista.addCantanteFamoso(cf2);

    Scanner scanner = new Scanner(System.in);

    while (true) {
        System.out.println("\n1. Añadir cantante famoso");
        System.out.println("2. Eliminar cantante famoso");
        System.out.println("3. Modificar nombre del cantante famoso");
        System.out.println("4. Modificar disco con más ventas del cantante famoso");
        System.out.println("5. Mostrar lista de cantantes famosos");
        System.out.println("6. Generar lista ordenada de cantantes famosos por discos vendidos");
        System.out.println("0. Salir");

        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1:
                System.out.println("Introduce el nombre del cantante famoso:");
                String nombre = scanner.next();
                System.out.println("Introduce el disco con más ventas del cantante famoso:");
                String discoConMasVentas = scanner.next();
                CantanteFamoso cantanteFamoso = new CantanteFamoso(nombre, discoConMasVentas);
                lista.addCantanteFamoso(cantanteFamoso);
                break;
            case 2:
                System.out.println("Introduce el nombre del cantante famoso que quieres eliminar:");
                nombre = scanner.next();
                Iterator<CantanteFamoso> iterator = lista.iterator();
                while (iterator.hasNext()) {
                    CantanteFamoso cf = iterator.next();
                    if (cf.getNombre().equals(nombre)) {
                        lista.removeCantanteFamoso(cf);
                        break;
                    }
                }
                break;
            case 3:
                System.out.println("Introduce el nombre del cantante famoso que quieres modificar:");
                nombre = scanner.next();
                System.out.println("Introduce el nuevo nombre del cantante famoso:");
                String nuevoNombre = scanner.next();
                lista.modifyCantanteFamoso(nombre, nuevoNombre);
                break;
            case 4:
                System.out.println("Introduce el nombre del cantante famoso que quieres modificar:");
                nombre = scanner.next();
                System.out.println("Introduce el nuevo disco con más ventas del cantante famoso:");
                discoConMasVentas = scanner.next();
                lista.modifyCantanteFamoso(nombre, discoConMasVentas);
                break;
            case 5:
                lista.printListaCantantesFamosos();
                break;
            case 6:
                lista.sortCantantesFamosos();
                lista.printListaCantantesFamosos();
                break;
            case 0:
                return;
            default:
                System.out.println("Opción inválida.");
        }
    }
}
}