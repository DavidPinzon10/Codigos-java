import java.util.Scanner;
/**
 * @author David Pinzón
 */
public class multiplos {

    public static void main(String[] args) {
        Scanner String = new Scanner(System.in);

        int multiplo_1, multiplo_2, multiplo_3, multiplo_4, multiplo_5;
        byte opcion;

        System.out.println("I---------------------------------------I");
        System.out.println("I  Bienvenido al programa de multiplos  I");
        System.out.println("I---------------------------------------I");

        while (true) {
            System.out.println("-------------------------------------------------------");
            System.out.println("Digite el numero el cual desea hallar los 5 primeros multiplos");
            System.out.println("1. Uno");
            System.out.println("2. Dos");
            System.out.println("3. Tres");
            System.out.println("4. Cuatro");
            System.out.println("5. Cinco");
            System.out.println("-------------------------------------------------------");
            opcion = String.nextByte();
            break;
        }
        switch (opcion) {
            case 1:
                multiplo_1 = 1 * 1;
                multiplo_2 = 1 * 2;
                multiplo_3 = 1 * 3;
                multiplo_4 = 1 * 4;
                multiplo_5 = 1 * 5;
System.out.println("Los multiplos de Uno son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
                break;
            case 2:
                multiplo_1 = 2 * 1;
                multiplo_2 = 2 * 2;
                multiplo_3 = 2 * 3;
                multiplo_4 = 2 * 4;
                multiplo_5 = 2 * 5;
System.out.println("Los múltiplos de Dos son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
break;
            case 3:
                multiplo_1 = 3 * 1;
                multiplo_2 = 3 * 2;
                multiplo_3 = 3 * 3;
                multiplo_4 = 3 * 4;
                multiplo_5 = 3 * 5;
System.out.println("Los múltiplos de Tres son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
break;
            case 4:
                multiplo_1 = 4 * 1;
                multiplo_2 = 4 * 2;
                multiplo_3 = 4 * 3;
                multiplo_4 = 4 * 4;
                multiplo_5 = 4 * 5;
System.out.println("Los múltiplos de Cuatro son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
break;
            case 5:
                multiplo_1 = 5 * 1;
                multiplo_2 = 5 * 2;
                multiplo_3 = 5 * 3;
                multiplo_4 = 5 * 4;
                multiplo_5 = 5 * 5;
System.out.println("Los múltiplos de Cinco son = " + multiplo_1 + ".." + multiplo_2 + ".." + multiplo_3 + ".." + multiplo_4 + ".." + multiplo_5);
break;
            default:
System.out.println("Error");
        }

    }

}
