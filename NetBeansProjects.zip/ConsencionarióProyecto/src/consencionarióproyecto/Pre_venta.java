package consencionarióproyecto;

import java.util.Scanner;

public class Pre_venta extends Comprar {

    int valorCuota;
    String metodoPago;
    byte opMP;
    float precioVehiculo;

    public Pre_venta() {
        this.valorCuota = 0;
    }

    public Pre_venta(String nombreComp, String correoElec, int nroCelular, String pago, int vehiculo, int valorCuota) {
        super(nombreComp, correoElec, nroCelular, pago, vehiculo);
        this.valorCuota = valorCuota;
    }

    public int getValorCuota() {
        return valorCuota;
    }

    public void setValorCuota(int valorCuota) {
        this.valorCuota = valorCuota;
    }

    @Override
    public void pedirDatos() {
        Consultar consP = new Consultar();
        Pre_venta pre = new Pre_venta();
        Scanner Vsc = new Scanner(System.in);
        Scanner Str1 = new Scanner(System.in);
        Scanner Str2 = new Scanner(System.in);
        Scanner Str3 = new Scanner(System.in);
        Scanner Str4 = new Scanner(System.in);

        System.out.println("---------------------");
        System.out.println("I  DATOS PERSONALES  I");
        System.out.println("---------------------");
        System.out.println(" Nombre Completo     ");
        nombreComp = Str1.nextLine();
        System.out.println(" Correo Electonico   ");
        correoElec = Str2.nextLine();
        System.out.println(" Número de Celular   ");
        nroCelular = Vsc.nextInt();
        System.out.println(" Vehiculo            ");
        consP.Consulta(1);
        vehiculo = Vsc.nextInt();
        System.out.println(" Precio del vehiculo ");
        precioVehiculo = Vsc.nextFloat();

    }
    public void generarRecibo(){
        
    }
    
    public int MetodoPago() {
        Scanner Vsc = new Scanner(System.in);
        double efectivo=0;
        // Menú del metodo de pago
        while (true) {
            System.out.println("");
            System.out.println("-----------------------");
            System.out.println("I    METODO DE PAGO    I");
            System.out.println("-----------------------");
            System.out.println(" 1. Efectivo           ");
            System.out.println(" 2. Tarjeta            ");
            System.out.println("-----------------------");
            opMP = Vsc.nextByte();
            switch (opMP) {
                case 1:
                    System.out.println("Pago a una cuota en efectivo");
                    System.out.println("----------------------------");
                    System.out.println("Por favor pague el monto :");
                    efectivo = Vsc.nextDouble();
                    break;
                case 2:
                    System.out.println("");
                    System.out.println("-----------------------");
                    System.out.println("I  COMO REALIZAR PAGO  I");
                    System.out.println("-----------------------");
                    System.out.println(" 1. 48 meses           ");
                    System.out.println(" 2. 24 meses           ");
                    System.out.println(" 3. 12 meses           ");
                    System.out.println(" 4. 6 meses            ");
                    System.out.println(" 5. 0 meses            ");
                    System.out.println(" 6. salir              ");
                    System.out.println("-----------------------");
                    opMP = Vsc.nextByte();

                    switch (opMP) {
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3:
                            break;
                        case 4:
                            break;
                        case 5:
                            break;
                        case 6:
                            break;
                    }
                    break;
                default:
                    System.out.println("Ese opcion no esta disponilbe");
            }
            return opMP;
        }
    }
}
