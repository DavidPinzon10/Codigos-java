
package sistemaecuaciones;

/**
 *
 * @author David
 */
public class Ecuacion {

    private double a;
    private double b;
    private double c;

    public Ecuacion(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double resolverX(Ecuacion otraEcuacion) {
        double a2 = otraEcuacion.getA();
        double b2 = otraEcuacion.getB();
        double c2 = otraEcuacion.getC();
        double denominador = a * b2 - b * a2;
        return (c * b2 - b * c2) / denominador;
    }

    public double resolverY(Ecuacion otraEcuacion) {
        double a2 = otraEcuacion.getA();
        double b2 = otraEcuacion.getB();
        double c2 = otraEcuacion.getC();
        double denominador = a * b2 - b * a2;
        return (a2 * c - c2 * a) / denominador;
    }

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }

}
