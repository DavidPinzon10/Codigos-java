
package concesionarioa404;

public class DataCliente {
    private String nombre;
    private String apellido;
    private String numero;
    private String cedula;
    private String tarjeta;
    
    public DataCliente() {
        this.nombre = "";
        this.apellido = "";
        this.numero = "";
        this.cedula = "";
        this.tarjeta = "";
    }
    
    public DataCliente(String nom, String ape, String num, String ced, String tar) {
        this.nombre = nom;
        this.apellido = ape;
        this.numero = num;
        this.cedula = ced;
        this.tarjeta = tar;
    }

    public String getNombre() {
        return nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public String getNumero() {
        return numero;
    }
    public String getCedula() {
        return cedula;
    }
    public String getTarjeta() {
        return tarjeta;
    }
    
    
}
