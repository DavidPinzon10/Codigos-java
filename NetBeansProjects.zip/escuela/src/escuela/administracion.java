
package escuela;
public class administracion {
    
 private String datos;
 private String horario;
 private String trasp;

public void Imprimir(  int id, String nombre, int edad, String direción, int telefono){
    
    System.out.println("\nID: "+id);
    System.out.println("Nombre: "+nombre);
    System.out.println("Edad: "+edad);
    System.out.println("Direccion: "+direción);
    System.out.println("Telefono: "+telefono);

}
public String Horario(int a,String horario){
        
    this.horario=horario+"\tUsuario: Administrativo";
     return this.horario;
        
    }
public String Trasporte (int a,String trasp ){
 
        this.trasp=trasp+"\tUsuario: Administrativo";
        return this.trasp;
    
}

    void Imprimir(int i, String tatiana_Sofia_Arevalo_Sanchez, int i0, String av_32_cl_2212, int i1, String equipo_de_aseo, String indefinido) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
