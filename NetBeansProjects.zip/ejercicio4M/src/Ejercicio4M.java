import java.util.Scanner;
/**
 * @author David Pinzón
 */
public class Ejercicio4M {
    public static void main(String[] args) {
       Scanner leer = new Scanner(System.in);
        
        int Matriz[][] = new int [3][3];
        int n1 = 0, n2 = 0, n3 = 0, n4 = 0, n5 = 0, n6 = 0;
        int diagonal1 = 0, diagonal2 = 0;
        
        for (int i = 0; i < Matriz.length; i++) {
        for (int j = 0; j < Matriz.length; j++) {
   
        
        System.out.println("Digite los elementos [" + i + "," + j + "]");
        Matriz[i][j] = leer.nextInt(); 
        
            if (Matriz[i][j] > 0) {      
}
            else{
               System.out.println("Error");         
}
} 
}
       
        for (int i = 0; i < Matriz.length; i++) {
        for (int j = 0; j < Matriz.length; j++) {
               
        System.out.print(" "+Matriz[i][j]);   
} 
        System.out.println("");
}
        System.out.println("Digite los numeros de la Diagonal 1");
        n1 = leer.nextInt(); n2 = leer.nextInt(); n3 = leer.nextInt();
        System.out.println("Digite los numeros de la Diagonal 2");
        n4 = leer.nextInt(); n5 = leer.nextInt(); n6 = leer.nextInt();
        
        diagonal1 = (n1+n2+n3) / 3;
        System.out.println("La media de la diagonal 1 es = "+diagonal1);
        diagonal2 = (n4+n5+n6) / 3;
        System.out.println("La media de la diagonal 2 es = "+diagonal2);
}    
}
