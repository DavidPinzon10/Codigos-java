package TuNominaYa;

// La clase EmpleadoAsalariado que extiende a Empleado.

public class EmpleadoAsalariado extends Empleado {
   private double salarioMensual;

   // constructor
   public EmpleadoAsalariado( String nombre, String apellido, String numeroSeguroSocial, double salario )   {
      super( nombre, apellido, numeroSeguroSocial ); 
      establecerSalarioMensual( salario );
   } 

   // establecer el salario del empleado asalariado
   public void establecerSalarioMensual( double salario )
   {
      salarioMensual = salario < 0.0 ? 0.0 : salario;
   } 

   // devolver el salario del empleado asalariado
   public double obtenerSalarioMensual()
   {
      return salarioMensual;
   } 

   // calcular el pago del empleado asalariado;
   // sobrescribir el m�todo abstracto ingresos en Empleado
   public double ingresos()
   {
      return obtenerSalarioMensual();
   } 

   // devolver la representaci�n String del objeto EmpleadoAsalariado
   public String toString()
   {
      return "\nEmpleado asalariado: " + super.toString();
   } 
   
} // fin de la clase EmpleadoAsalariado